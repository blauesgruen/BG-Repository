"""Resolve the service's one-shot local audio request through Kodi InputStream."""

import json
import hashlib
import re
import sys
from urllib.parse import parse_qs, urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from audio import kodi_music_item
from menu import show_menu


def resolve(handle, query):
    request = parse_qs(query.lstrip("?")).get("request", [""])[0]
    if not re.fullmatch(r"[0-9a-f]{32}", request):
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    window = xbmcgui.Window(10000)
    key = "service.soloist.native.stream." + request
    raw = window.getProperty(key)
    window.clearProperty(key)
    try:
        if not raw or len(raw.encode("utf-8")) > 262144:
            raise ValueError("Missing or oversized request")
        data = json.loads(raw)
        if (not isinstance(data, dict) or set(data) - {"url", "item", "artist_mbids"}
                or not isinstance(data.get("item"), dict)):
            raise ValueError("Invalid request schema")
        url = data["url"]
        if not isinstance(url, str) or not isinstance(data.get("artist_mbids", {}), dict):
            raise ValueError("Invalid request fields")
        source = urlsplit(url)
        if (source.scheme != "tcp" or source.hostname != "127.0.0.1"
                or source.username or source.password or not source.port
                or source.path not in ("", "/") or source.fragment
                or source.query != "timeout=5000000"):
            raise ValueError("Not the local Soloist stream")
        item = kodi_music_item(
            {"item": data["item"]}, url, xbmcgui.ListItem,
            artist_mbids_by_uri=data.get("artist_mbids") or {},
            diagnostic_logger=(lambda message: xbmc.log(
                "[service.soloist.native] " + message, xbmc.LOGINFO))
                if xbmcaddon.Addon().getSettingBool("audio_diagnostics") else None,
        )
        if item is None:
            raise ValueError("Missing track metadata")
        item.setProperty("inputstream", "inputstream.ffmpegdirect")
        item.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
        item.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        xbmc.log("[service.soloist.native] Streamauflösung: FFmpegDirect, "
                 "Live-PCM und Startmetadaten an Kodi übergeben; "
                 "kein Timeshift angefordert.", xbmc.LOGINFO)
        revision = hashlib.sha256(json.dumps(
            [data["item"], data.get("artist_mbids") or {}],
            sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")).hexdigest()
        window.setProperty(key + ".ready", revision)
        xbmcplugin.setResolvedUrl(handle, True, item)
    except (KeyError, TypeError, ValueError, RuntimeError) as error:
        window.clearProperty(key + ".ready")
        xbmc.log("[service.soloist.native] Streamauflösung fehlgeschlagen ({}).".format(
            type(error).__name__), xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


if __name__ == "__main__":
    handle = int(sys.argv[1])
    query = sys.argv[2] if len(sys.argv) > 2 else ""
    if not query:
        show_menu()
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    else:
        resolve(handle, query)
