"""Resolve the service's one-shot local audio request through Kodi InputStream."""

import json
import hashlib
import re
import sys
import time
import uuid
from urllib.parse import parse_qs, urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from audio import kodi_music_item
from menu import show_menu
from queue_bridge import (
    MAX_PAYLOAD_BYTES, PREFIX, REQUEST_PROPERTY, RESOLVE_TIMEOUT,
    TOKEN_PATTERN, registry_data, result_key,
)


class QueueResolutionError(ValueError):
    """Only fixed, non-sensitive queue failure reasons may reach the log."""


def _queue_data(parameters, window):
    """Wait only for our service; never make a Kodi RPC from this resolver."""
    if set(parameters) != {"queue", "session"}:
        raise ValueError("Invalid queue parameters")
    if any(len(values) != 1 or not TOKEN_PATTERN.fullmatch(values[0])
           for values in parameters.values()):
        raise ValueError("Invalid queue token")
    token, session = parameters["queue"][0], parameters["session"][0]
    grant = registry_data(window.getProperty(PREFIX + token))
    if grant["session"] != session:
        raise QueueResolutionError("Queue session expired")
    if window.getProperty(REQUEST_PROPERTY):
        raise QueueResolutionError("Queue navigation already pending")
    operation = uuid.uuid4().hex
    request = json.dumps({"operation": operation, "entry": token, "session": session,
                          "revision": grant["revision"]})
    key = result_key(operation)
    monitor = xbmc.Monitor()
    window.setProperty(REQUEST_PROPERTY, request)
    try:
        deadline = time.monotonic() + RESOLVE_TIMEOUT
        while time.monotonic() < deadline:
            raw = window.getProperty(key)
            if raw:
                if len(raw.encode("utf-8")) > MAX_PAYLOAD_BYTES:
                    raise ValueError("Queue result too large")
                data = json.loads(raw)
                if not isinstance(data, dict) or data.pop("ok", False) is not True:
                    raise QueueResolutionError("Queue target not confirmed")
                return data
            if monitor.waitForAbort(0.05):
                raise QueueResolutionError("Kodi cancelled queue resolution")
        raise QueueResolutionError("Queue resolution timed out")
    finally:
        if window.getProperty(REQUEST_PROPERTY) == request:
            window.clearProperty(REQUEST_PROPERTY)
        window.clearProperty(key)


def resolve(handle, query):
    window = xbmcgui.Window(10000)
    key = None
    try:
        parameters = parse_qs(query.lstrip("?"), keep_blank_values=True)
        if "queue" in parameters:
            data = _queue_data(parameters, window)
        else:
            request = parameters.get("request", [""])[0]
            if (set(parameters) != {"request"} or len(parameters["request"]) != 1
                    or not re.fullmatch(r"[0-9a-f]{32}", request)):
                raise ValueError("Invalid request token")
            key = "service.soloist.native.stream." + request
            raw = window.getProperty(key)
            window.clearProperty(key)
            if not raw and window.getProperty(PREFIX + request):
                grant = registry_data(window.getProperty(PREFIX + request))
                data = _queue_data({"queue": [request], "session": [grant["session"]]}, window)
                key = None  # adopted playlist slot, not a new one-shot open
            elif not raw or len(raw.encode("utf-8")) > MAX_PAYLOAD_BYTES:
                raise ValueError("Missing or oversized request")
            else:
                data = json.loads(raw)
        if (not isinstance(data, dict) or set(data) - {"url", "item", "artist_mbids"}
                or not isinstance(data.get("item"), dict)):
            raise ValueError("Invalid request schema")
        url = data["url"]
        if not isinstance(url, str) or not isinstance(data.get("artist_mbids", {}), dict):
            raise ValueError("Invalid request fields")
        source = urlsplit(url)
        if (source.scheme != "tcp" or source.hostname != "127.0.0.1"
                or source.username or source.password or not source.port
                or source.path not in ("", "/") or source.fragment
                or source.query != "timeout=5000000"):
            raise ValueError("Not the local Soloist stream")
        item = kodi_music_item(
            {"item": data["item"]}, url, xbmcgui.ListItem,
            artist_mbids_by_uri=data.get("artist_mbids") or {},
            diagnostic_logger=(lambda message: xbmc.log(
                "[service.soloist.native] " + message, xbmc.LOGINFO))
                if xbmcaddon.Addon().getSettingBool("audio_diagnostics") else None,
        )
        if item is None:
            raise ValueError("Missing track metadata")
        item.setProperty("inputstream", "inputstream.ffmpegdirect")
        # Native Previous calls PlayFile without an explicit player name. Kodi's
        # supported InputStream override avoids falling back to PAPlayer there.
        item.setProperty("inputstream-player", "videodefaultplayer")
        item.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
        item.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        xbmc.log("[service.soloist.native] Streamauflösung: FFmpegDirect, "
                 "Live-PCM und Startmetadaten an Kodi übergeben; "
                 "kein Timeshift angefordert.", xbmc.LOGINFO)
        revision = hashlib.sha256(json.dumps(
            [data["item"], data.get("artist_mbids") or {}],
            sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")).hexdigest()
        if key:
            window.setProperty(key + ".ready", revision)
        xbmcplugin.setResolvedUrl(handle, True, item)
    except (KeyError, TypeError, ValueError, RuntimeError) as error:
        if key:
            window.clearProperty(key + ".ready")
        xbmc.log("[service.soloist.native] Streamauflösung fehlgeschlagen ({}).".format(
            str(error) if isinstance(error, QueueResolutionError) else type(error).__name__),
            xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


if __name__ == "__main__":
    handle = int(sys.argv[1])
    query = sys.argv[2] if len(sys.argv) > 2 else ""
    if not query:
        show_menu()
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    else:
        resolve(handle, query)
