"""Private storage for the user's Spotify Soloist API key."""

import os
import tempfile


KEY_FILENAME = "api_key"


def key_path(data_dir):
    return os.path.join(data_dir, "credentials", KEY_FILENAME)


def save_api_key(data_dir, api_key):
    """Atomically save a non-empty key with owner-only permissions."""
    if not isinstance(api_key, str):
        raise ValueError("API-Schlüssel ist ungültig")
    api_key = api_key.strip()
    if not api_key or len(api_key) > 4096 or any(ord(char) < 32 for char in api_key):
        raise ValueError("API-Schlüssel ist ungültig")

    directory = os.path.join(data_dir, "credentials")
    os.makedirs(directory, mode=0o700, exist_ok=True)
    os.chmod(directory, 0o700)

    descriptor, temporary_path = tempfile.mkstemp(prefix=".api_key-", dir=directory)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as secret_file:
            secret_file.write(api_key)
            secret_file.flush()
            os.fsync(secret_file.fileno())
        os.replace(temporary_path, key_path(data_dir))
        os.chmod(key_path(data_dir), 0o600)
    except Exception:
        try:
            os.close(descriptor)
        except OSError:
            pass
        try:
            os.unlink(temporary_path)
        except OSError:
            pass
        raise


def load_api_key(data_dir):
    """Read the key without logging or exposing it to Kodi settings."""
    try:
        with open(key_path(data_dir), "r", encoding="utf-8") as secret_file:
            value = secret_file.read(4097)
    except FileNotFoundError:
        return None
    if not value or len(value) > 4096 or any(ord(char) < 32 for char in value):
        return None
    return value


def delete_api_key(data_dir):
    try:
        os.unlink(key_path(data_dir))
    except FileNotFoundError:
        return False
    return True
