"""Keep the Soloist binary current before Spotify's 90-day limit ends it."""

import threading
import time

from runtime import SoloistRuntimeError, install_soloist, refresh_state

RECHECK_SECONDS = 12 * 3600
RETRY_SECONDS = 24 * 3600


class SoloistUpdater:
    """Download a newer Soloist in the background and report the result once.

    The new binary replaces the old file atomically; a running Soloist keeps
    its old program until it is restarted.
    """

    def __init__(self, data_path, logger, installer=None, clock=None):
        self.data_path = data_path
        self.logger = logger
        self.installer = installer or install_soloist
        self.clock = clock or time.monotonic
        self.version = None
        self.platform = None
        self.thread = None
        self.result = None
        self.last_attempt = None
        self.last_check = None
        self.restart_pending = False

    def note_installed(self, version, platform):
        """Remember the version of the binary that is about to run."""
        self.version = version
        self.platform = platform
        self.last_check = self.clock()

    def state(self, today=None):
        return refresh_state(self.version, today) if self.version else "unknown"

    def busy(self):
        return self.thread is not None and self.thread.is_alive()

    def start(self, force=False):
        """Start a background download unless one runs or failed recently."""
        if self.busy() or self.platform is None:
            return False
        now = self.clock()
        if (not force and self.last_attempt is not None
                and now - self.last_attempt < RETRY_SECONDS):
            return False
        self.last_attempt = now
        self.result = None
        self.thread = threading.Thread(target=self._run, name="soloist-update", daemon=True)
        self.thread.start()
        return True

    def _run(self):
        try:
            _, version = self.installer(self.data_path, platform=self.platform)
        except SoloistRuntimeError as error:
            self.result = (False, str(error))
            return
        except Exception as error:  # never let the update thread die silently
            self.result = (False, type(error).__name__)
            return
        self.result = (True, version)

    def tick(self, today=None):
        """Recheck the known build date now and then; start an update when due."""
        now = self.clock()
        if self.last_check is not None and now - self.last_check < RECHECK_SECONDS:
            return False
        self.last_check = now
        if self.state(today) in ("due", "expired"):
            return self.start()
        return False

    def take_result(self):
        """(ok, version or reason) once after a finished download, else None."""
        if self.busy() or self.result is None:
            return None
        result, self.result = self.result, None
        ok, detail = result
        if ok:
            self.version = detail
            self.restart_pending = True
        return result
