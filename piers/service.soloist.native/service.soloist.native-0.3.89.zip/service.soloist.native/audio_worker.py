"""Standalone RTP-to-TCP audio worker for the Kodi service.

Stdout is a bounded JSON-lines control and telemetry channel. The worker imports
``audio`` only for its pure-Python relay implementation; it never imports Kodi
modules or owns PulseAudio modules.
"""

import json
import os
import select
import sys
import time
import fcntl


PROTOCOL_VERSION = 1
MAX_OUTPUT_RECORD = 65536
MAX_COMMAND_RECORD = 4096
MAX_READ_CHUNK = 4096
SNAPSHOT_INTERVAL = 0.25
_STDERR_NONBLOCKING = False


def _stderr_logger(message):
    """Best-effort, nonblocking diagnostics; a full stderr pipe drops the line."""
    if not _STDERR_NONBLOCKING:
        return
    try:
        text = str(message).replace("\r", " ").replace("\n", " ")
        encoded = text[:1900].encode("utf-8", "replace")[:2047] + b"\n"
        os.write(2, encoded)
    except (BlockingIOError, OSError, ValueError):
        pass


def _make_stderr_nonblocking():
    global _STDERR_NONBLOCKING
    try:
        flags = fcntl.fcntl(2, fcntl.F_GETFL)
        fcntl.fcntl(2, fcntl.F_SETFL, flags | os.O_NONBLOCK)
        _STDERR_NONBLOCKING = True
    except (OSError, AttributeError):
        pass


def _write_record(record):
    data = json.dumps(
        record, ensure_ascii=False, separators=(",", ":"), allow_nan=False
    ).encode("utf-8") + b"\n"
    if len(data) > MAX_OUTPUT_RECORD:
        raise ValueError("output_record_too_large")
    view = memoryview(data)
    while view:
        try:
            written = os.write(1, view)
        except InterruptedError:
            continue
        if written <= 0:
            raise BrokenPipeError("stdout_closed")
        view = view[written:]


def _reply(request_id, result=None, error=None):
    record = {"type": "reply", "id": request_id, "ok": error is None}
    if error is None:
        record["result"] = result
    else:
        record["error"] = error
    _write_record(record)


def _snapshot(owner):
    with owner._rtp_lock:
        stats = dict(owner._rtp_stats)
    # Timestamps in stats are monotonic process timestamps and remain useful
    # to the parent because the processes share the same kernel clock.
    return {
        "type": "snapshot",
        "at": time.monotonic(),
        "stats": stats,
        "buffer": owner.buffer_snapshot(),
        "recovery": owner.recovery_snapshot(),
    }


def _parse_command(raw):
    if len(raw) > MAX_COMMAND_RECORD:
        raise ValueError("command_too_large")
    try:
        command = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("invalid_json") from error
    if not isinstance(command, dict):
        raise ValueError("invalid_command")
    request_id = command.get("id")
    if isinstance(request_id, bool) or not isinstance(request_id, int) or request_id <= 0:
        raise ValueError("invalid_id")
    operation = command.get("op")
    if operation not in ("playback", "close", "shutdown"):
        raise ValueError("invalid_operation")
    enabled = command.get("enabled")
    if operation == "playback" and not isinstance(enabled, bool):
        raise ValueError("invalid_enabled")
    reason = command.get("reason", "")
    if not isinstance(reason, str) or len(reason) > 256:
        raise ValueError("invalid_reason")
    return request_id, operation, enabled, reason


def _run_commands(owner, rtp_port):
    _write_record({
        "type": "ready",
        "protocol": PROTOCOL_VERSION,
        "url": owner.playback_url,
        "pid": os.getpid(),
        "rtp_port": rtp_port,
    })

    input_fd = 0
    pending = bytearray()
    next_snapshot_at = time.monotonic() + SNAPSHOT_INTERVAL
    while True:
        timeout = max(0.0, next_snapshot_at - time.monotonic())
        readable, _, _ = select.select([input_fd], [], [], timeout)
        if readable:
            chunk = os.read(input_fd, MAX_READ_CHUNK)
            if not chunk:
                return
            pending.extend(chunk)
            if len(pending) > MAX_COMMAND_RECORD + 1 and b"\n" not in pending:
                raise ValueError("command_too_large")
            while b"\n" in pending:
                line, _, remaining = pending.partition(b"\n")
                pending = bytearray(remaining)
                if len(line) > MAX_COMMAND_RECORD:
                    raise ValueError("command_too_large")
                if not line:
                    raise ValueError("empty_command")
                request_id, operation, enabled, reason = _parse_command(line)
                if operation == "playback":
                    owner.set_playback_enabled(enabled)
                    _reply(request_id, {"enabled": enabled})
                elif operation == "close":
                    closed = owner.close_tcp_clients(reason or "Kodi-Player wird beendet")
                    _reply(request_id, {"closed": closed})
                else:
                    owner.cleanup()
                    _reply(request_id, {"stopped": True})
                    return
        now = time.monotonic()
        if now >= next_snapshot_at:
            if not owner._rtp_thread.is_alive() or not owner.tcp_thread.is_alive():
                _stderr_logger("Audioprozess: Empfangs- oder TCP-Serverthread ist beendet.")
                raise RuntimeError("audio_thread_stopped")
            _write_record(_snapshot(owner))
            next_snapshot_at = now + SNAPSHOT_INTERVAL


def _parse_port(argv):
    if len(argv) != 3 or argv[1] != "--rtp-port":
        raise ValueError("invalid_arguments")
    try:
        port = int(argv[2], 10)
    except (TypeError, ValueError) as error:
        raise ValueError("invalid_rtp_port") from error
    if not 1024 <= port <= 65534:
        raise ValueError("invalid_rtp_port")
    return port


def main(argv=None):
    owner = None
    _make_stderr_nonblocking()
    try:
        rtp_port = _parse_port(sys.argv if argv is None else argv)
        # -I deliberately removes script/CWD paths; restore only this trusted
        # add-on directory so the existing pure-stdlib relay can be imported.
        script_dir = os.path.dirname(os.path.realpath(__file__))
        sys.path.insert(0, script_dir)
        from audio import PulseRtpAudio

        owner = PulseRtpAudio("", _stderr_logger)
        owner.port = rtp_port
        owner._start_tcp_server()
        owner._start_rtp_relay()
        _run_commands(owner, rtp_port)
        return 0
    except Exception as error:
        _stderr_logger("Audioprozess beendet ({})".format(type(error).__name__))
        try:
            _write_record({"type": "fatal", "error": type(error).__name__})
        except Exception:
            pass
        return 1
    finally:
        if owner is not None:
            try:
                owner.cleanup()
            except Exception as cleanup_error:
                _stderr_logger(
                    "audio worker cleanup failed ({})".format(
                        type(cleanup_error).__name__
                    )
                )


if __name__ == "__main__":
    sys.exit(main())
