"""Kodi service entry point and owner of the Soloist child process."""

import json
import hashlib
import math
import os
import time
import traceback
import uuid

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from credentials import load_api_key
from audio import AudioSetupError
from audio_bridge import ProcessPulseRtpAudio
from runtime import install_soloist
from runtime import SoloistRuntimeError
from audio import kodi_music_item
from audio import playback_snapshot
from audio import estimated_position_ms as _estimated_soloist_position_ms
from audio import creator_artists
from musicbrainz import MusicBrainzResolver
from soloist_process import SoloistProcess
from soloist_websocket import SoloistWebSocket
from queue_bridge import SoloistQueueBridge


ADDON_ID = "service.soloist.native"
COMMAND_PROPERTY = "service.soloist.native.command"
RESULT_PROPERTY = "service.soloist.native.result"
UPDATE_READY_PROPERTY = "service.soloist.native.update_ready"
WINDOW_ID = 10000
POSITION_DIAGNOSTIC_INTERVAL = 15.0
AUDIO_FLOW_DIAGNOSTIC_INTERVAL = 5.0
STARTUP_DELAY_SECONDS = 5.0
CONNECTION_NOTICE_TIMEOUT = 15.0
COMMAND_CONFIRMATION_TIMEOUT = 8.0


def _safe_log(message, api_key=None, level=xbmc.LOGINFO):
    text = str(message)
    if api_key:
        text = text.replace(api_key, "[redacted]")
    xbmc.log("[{}] {}".format(ADDON_ID, text), level)


def _result(window, request_id, code):
    if request_id:
        window.setProperty(
            RESULT_PROPERTY,
            json.dumps({"request_id": request_id, "code": code}),
        )


def _notify(
    addon,
    message_id,
    icon=xbmcgui.NOTIFICATION_INFO,
    display_time=5000,
    sound=True,
):
    if addon.getSettingBool("show_startup_notification"):
        xbmcgui.Dialog().notification(
            addon.getLocalizedString(32000),
            addon.getLocalizedString(message_id),
            icon,
            display_time,
            sound,
        )
        return True
    return False


def _debug_log(addon, message, api_key=None):
    """Write selected, redacted diagnostics when add-on logging is enabled."""
    if addon.getSettingBool("audio_diagnostics"):
        _safe_log("[Diagnose] {}".format(message), api_key, xbmc.LOGINFO)


def _player_debug_log(player_state, message):
    logger = player_state.get("debug_log")
    if callable(logger):
        logger(message)


def _observe_player_call(player_state, operation, callback):
    """Measure native reads without changing their results or suppressing errors.

    Unlike executeJSONRPC, legacy Player getters need not release Python's
    GIL while acquiring native locks. Report slow reads individually; ordinary
    reads add no log traffic. A duration alone does not prove a GIL stall.
    """
    started = time.monotonic()
    completed = False
    try:
        result = callback()
        completed = True
        return result
    finally:
        elapsed_ms = (time.monotonic() - started) * 1000
        if elapsed_ms >= 100:
            _player_debug_log(
                player_state,
                "Langsame Kodi-Playerabfrage {}: {:.1f}ms, abgeschlossen={}, "
                "Beginn_monoton={:.6f}.".format(
                    operation, elapsed_ms, completed, started
                ),
            )


def _player_can_seek():
    """Return Kodi's seek capability for the music player, or None if unknown."""
    request = {
        "jsonrpc": "2.0",
        "method": "Player.GetProperties",
        "params": {"playerid": 0, "properties": ["canseek"]},
        "id": 1,
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception:
        return None
    if not isinstance(response, dict):
        return None
    result = response.get("result")
    if not isinstance(result, dict) or not isinstance(result.get("canseek"), bool):
        return None
    return result["canseek"]



def _log_position_diagnostic(event, player_state):
    """Log a rate-limited, read-only comparison of Soloist and Kodi clocks."""
    if event.get("type") != "position_sync" or not player_state.get("owned"):
        return
    enabled = player_state.get("debug_logging_enabled")
    if not callable(enabled) or not enabled():
        return
    now = time.monotonic()
    if (
        now - player_state.get("last_position_diagnostic", 0.0)
        < POSITION_DIAGNOSTIC_INTERVAL
    ):
        return
    player = player_state["player"]
    if not _observe_player_call(player_state, "isPlaying/Zeitprobe", player.isPlaying):
        return
    player_state["last_position_diagnostic"] = now
    position = event.get("position")
    if not isinstance(position, dict):
        position = {}
    anchor_ms = position.get("position_ms")
    soloist_speed = position.get("speed")
    estimated_position_ms = _estimated_soloist_position_ms(position)
    try:
        kodi_time = _observe_player_call(player_state, "getTime/Zeitprobe", player.getTime)
        kodi_total = _observe_player_call(
            player_state, "getTotalTime/Zeitprobe", player.getTotalTime
        )
        can_seek = _player_can_seek()
        _player_debug_log(
            player_state,
            "Player-Zeitprobe: Soloist-Anker={} ms, geschätzt={} ms (Tempo {}), "
            "Kodi={:.3f}/{:.3f} s, Kodi-suchbar={}".format(
                anchor_ms,
                estimated_position_ms,
                soloist_speed,
                kodi_time,
                kodi_total,
                "unbekannt" if can_seek is None else str(can_seek).lower(),
            )
        )
    except Exception as error:
        _player_debug_log(
            player_state,
            "Player-Zeitprobe fehlgeschlagen ({})".format(type(error).__name__),
        )


def _playback_attempted(event, state, previous_status, previous_active):
    """Identify a new Soloist play/track request without reacting to position ticks."""
    status = state.get("status")
    if status not in ("playing", "buffering") or not state.get("is_active"):
        return False
    if event.get("type") == "track_changed":
        return True
    if (
        event.get("type") in ("playback_changed", "playback_state")
        and previous_status not in ("playing", "buffering")
    ):
        return True
    return (
        event.get("type") == "device_changed"
        and previous_active is False
    )


def _flush_pending_info_tag(player_state):
    """Apply the latest tag only to the AV-confirmed stream, with bounded retries."""
    item = player_state.get("pending_info_tag")
    queue_bridge = player_state.get("queue_bridge")
    if queue_bridge and queue_bridge.metadata_busy():
        return
    if item is None or not player_state.get("owned") or not player_state.get("av_ready"):
        return
    attempts = player_state.get("info_tag_attempts", 0)
    if attempts >= 3 or time.monotonic() < player_state.get("info_tag_retry_at", 0):
        return
    player = player_state["player"]
    revision = player_state.get("info_tag_revision")
    operation_started = time.monotonic()
    generation = player_state.get("source_generation", 0)
    metadata_path = player_state.get("metadata_item_path")
    stage = "Quellenprüfung"
    try:
        if not player.isPlaying() or player.getPlayingFile() != player_state.get("playback_url"):
            return
        player_state["info_tag_attempts"] = attempts + 1
        # Kodi matches GUI_MSG_UPDATE_ITEM against GetPath/original_listitem_url,
        # while getPlayingFile() returns GetDynPath (the resolved TCP source).
        # SetPath on this fresh tag item does not replace the player's DynPath.
        path_started = time.monotonic()
        stage = "Pfadsetzen"
        item.setPath(player_state.get("metadata_item_path") or player_state["playback_url"])
        path_ms = (time.monotonic() - path_started) * 1000
        stage = "GUI-Update"
        _player_debug_log(player_state, "Kodi-InfoTag-Aufruf beginnt.")
        update_started = time.monotonic()
        player.updateInfoTag(item)
        _player_debug_log(player_state,
            "Kodi-Metadatenübergabe: Pfadsetzen={:.1f}ms GUI-Update={:.1f}ms.".format(
                path_ms,
                (time.monotonic() - update_started) * 1000,
            ))
    except RuntimeError as error:
        player_state["info_tag_attempts"] = attempts + 1
        player_state["info_tag_retry_at"] = time.monotonic() + 1.0
        _player_debug_log(
            player_state,
            "Kodi-InfoTag noch nicht übernommen (Versuch {}/3, {}); "
            "neuestes Tag bleibt vorgemerkt. Phase={} Dauer_bis_Fehler={:.1f}ms.".format(
                attempts + 1, type(error).__name__, stage,
                (time.monotonic() - operation_started) * 1000),
        )
        return
    if (generation != player_state.get("source_generation", 0)
            or metadata_path != player_state.get("metadata_item_path")
            or revision != player_state.get("info_tag_revision")
            or not player_state.get("owned") or not player_state.get("av_ready")):
        _player_debug_log(player_state,
            "Kodi-InfoTag-Übergabe durch Leserwechsel überholt; keine Übernahmebestätigung.")
        return False
    player_state["applied_info_tag_revision"] = revision
    # A newer event must not be removed if a callback replaced the pending tag.
    if player_state.get("pending_info_tag") is item:
        player_state["pending_info_tag"] = None
    _player_debug_log(player_state,
        "Kodi-InfoTag-Update an das aktuelle Item gesendet; "
        "sichtbare Übernahme wird durch die Anzeigeprobe geprüft.")
    return True


def _queue_info_tag(player_state, item, artist_mbids=None):
    artist_mbids = artist_mbids or {}
    revision = hashlib.sha256(json.dumps(
        [player_state.get("playback", {}).get("item"), artist_mbids],
        sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")).hexdigest()
    if (player_state.get("applied_info_tag_revision") == revision
            and player_state.get("av_ready") and player_state.get("owned")):
        player_state["pending_info_tag"] = None
        player_state["info_tag_revision"] = revision
        return True
    player_state["pending_info_tag"] = item
    if player_state.get("info_tag_revision") != revision:
        player_state["info_tag_attempts"] = 0
        player_state["info_tag_retry_at"] = 0
        player_state["info_tag_revision"] = revision
    return _flush_pending_info_tag(player_state)


def _open_soloist_stream(player_state, url, item, artist_mbids=None):
    """Request Kodi's VideoPlayer without changing global player settings.

    PAPlayer's codec initialization probes seeking on the direct FFmpeg
    input and can reset/reopen a nonseekable TCP source. Player.Open exposes
    a supported per-request player selection. The Python resolver supplies
    initial tags and the installed FFmpegDirect adapter; later tag revisions
    wait for the exact source's onAVStarted confirmation.
    """
    window = xbmcgui.Window(WINDOW_ID)
    previous_key = player_state.get("stream_request_key")
    if previous_key:
        window.clearProperty(previous_key)
        window.clearProperty(previous_key + ".ready")
    request_id = uuid.uuid4().hex
    key = ADDON_ID + ".stream." + request_id
    artist_mbids = artist_mbids or {}
    track = player_state.get("playback", {}).get("item")
    payload = json.dumps({"url": url, "item": track, "artist_mbids": artist_mbids})
    if len(payload.encode("utf-8")) > 262144:
        raise RuntimeError("Soloist-Startmetadaten überschreiten die Übergabegrenze")
    window.setProperty(key, payload)
    player_state["stream_request_key"] = key
    initial_revision = hashlib.sha256(json.dumps(
        [track, artist_mbids], sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")).hexdigest()
    plugin_url = "plugin://{}/?request={}".format(ADDON_ID, request_id)
    player_state["metadata_item_path"] = plugin_url
    request = {
        "jsonrpc": "2.0", "id": 1, "method": "Player.Open",
        "params": {
            "item": {"file": plugin_url},
            "options": {"playername": "VideoPlayer", "resume": False},
        },
    }
    player_state["owned"] = True
    player_state["av_ready"] = False
    player_state["info_tag_revision"] = initial_revision
    player_state["resolved_metadata_revision"] = initial_revision
    player_state["applied_info_tag_revision"] = None
    player_state["kodi_paused"] = False
    player_state["pending_info_tag"] = item
    player_state["info_tag_attempts"] = 0
    player_state["info_tag_retry_at"] = 0
    if player_state.get("pending_audio_recovery") is None:
        player_state["pending_audio_recovery"] = {
            "requested_at": time.monotonic(),
            "track_identity": _item_identity_key(
                (player_state.get("playback") or {}).get("item")
            ),
            "reason": "start",
        }
    _player_debug_log(player_state, "Kodi-Öffnungsanforderung beginnt.")
    rpc_started = time.monotonic()
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        _player_debug_log(player_state, "Kodi-Öffnungsanforderung: {:.1f}ms.".format(
            (time.monotonic() - rpc_started) * 1000))
        if not isinstance(response, dict) or response.get("result") != "OK":
            error = response.get("error") if isinstance(response, dict) else None
            code = error.get("code") if isinstance(error, dict) else "unbekannt"
            _safe_log(
                "Kodi hat Player.Open mit VideoPlayer abgelehnt (Code {}).".format(code),
                level=xbmc.LOGERROR,
            )
            raise RuntimeError("Kodi Player.Open abgelehnt (Code {})".format(code))
    except Exception as error:
        _player_debug_log(player_state, "Kodi-Öffnungsanforderung fehlgeschlagen nach {:.1f}ms ({}).".format(
            (time.monotonic() - rpc_started) * 1000, type(error).__name__))
        window.clearProperty(key)
        window.clearProperty(key + ".ready")
        player_state["stream_request_key"] = None
        player_state["owned"] = False
        player_state["av_ready"] = False
        player_state["pending_info_tag"] = None
        player_state["pending_audio_recovery"] = None
        _safe_log(
            "Kodi-Start mit VideoPlayer konnte nicht angefordert werden ({}).".format(
                type(error).__name__
            ),
            level=xbmc.LOGERROR,
        )
        raise
    _player_debug_log(
        player_state,
        "Kodi hat Player.Open für den FFmpegDirect-Resolver mit VideoPlayer angenommen; "
        "echte Live-Quelle und Startmetadaten werden vor dem Audiostart aufgelöst.",
    )


def _recover_stalled_kodi_stream(audio, player_state, playback):
    """Reopen Kodi's stream only after confirming the source is still delivering PCM."""
    now = time.monotonic()
    attempts = [
        attempt
        for attempt in player_state.get("audio_recovery_attempts", [])
        if now - attempt < 300.0
    ]
    player_state["audio_recovery_attempts"] = attempts
    if len(attempts) >= 2:
        if not player_state.get("audio_recovery_exhausted_logged"):
            _player_debug_log(
                player_state,
                "Kodi-Audiostream blieb nach zwei Wiederöffnungen stehen; "
                "keine weitere automatische Unterbrechung in diesem Zeitfenster.",
            )
            player_state["audio_recovery_exhausted_logged"] = True
        return
    last_attempt = player_state.get("audio_recovery_last_attempt", 0.0)
    if now - last_attempt < 30.0:
        return

    url = audio.playback_url
    item = kodi_music_item(
        {"item": playback.get("item")},
        url,
        xbmcgui.ListItem,
        diagnostic_logger=player_state.get("debug_log"),
    )
    if not url or item is None:
        return

    player = player_state["player"]
    player_state["audio_recovery_last_attempt"] = now
    attempts.append(now)
    player_state["audio_recovery_exhausted_logged"] = False
    _player_debug_log(
        player_state,
        "Kodi-Audiostream wird nach bestätigtem Stillstand kontrolliert "
        "wieder geöffnet; Soloist meldet weiter Wiedergabe und RTP liefert Daten.",
    )
    try:
        audio.close_tcp_clients("Kontrollierte Wiederöffnung nach Kodi-Stillstand")
        player.suppress_next("stop")
        player.stop()
        deadline = time.monotonic() + 1.5
        while player.isPlaying() and time.monotonic() < deadline:
            xbmc.sleep(100)
        if player.isPlaying():
            raise RuntimeError("Kodi-Player stoppte vor Wiederöffnung nicht")
        player_state["owned"] = True
        player_state["pending_audio_recovery"] = {
            "requested_at": time.monotonic(),
            "track_identity": _item_identity_key(playback.get("item")),
        }
        _open_soloist_stream(player_state, url, item)
        player_state["kodi_stall_samples"] = 0
        _player_debug_log(
            player_state,
            "Kodi-Wiederöffnung angefordert; Erfolg wird erst nach onAVStarted bestätigt.",
        )
    except Exception as error:
        player_state["pending_audio_recovery"] = None
        player_state["owned"] = False
        player_state["av_ready"] = False
        _player_debug_log(
            player_state,
            "Automatische Kodi-Audiowiederöffnung fehlgeschlagen ({}).".format(
                type(error).__name__
            ),
        )


def _reattach_after_kodi_error(audio, player_state, websocket, musicbrainz_resolver=None):
    """Refresh Soloist state, then reattach a failed Kodi player if still active."""
    requested_at = player_state.get("kodi_error_reconnect_requested_at")
    if requested_at is None:
        return

    if not player_state.get("kodi_error_state_confirmed"):
        state_request_at = player_state.get("kodi_error_state_request_at")
        attempts = player_state.get("kodi_error_state_request_attempts", 0)
        now = time.monotonic()
        if state_request_at is not None and now - state_request_at < 5.0:
            return
        if attempts >= 2:
            player_state["kodi_error_reconnect_requested_at"] = None
            _player_debug_log(
                player_state,
                "Kodi-Wiederanbindung nach Playerfehler abgebrochen; "
                "Soloist hat auf zwei get_state-Anfragen keinen frischen "
                "Wiedergabestatus geliefert.",
            )
            xbmcgui.Dialog().notification(
                "Soloist",
                "Wiedergabestatus nicht erreichbar",
                xbmcgui.NOTIFICATION_ERROR,
                5000,
                False,
            )
            return
        if not websocket.is_connected():
            return
        if websocket.send_command("get_state"):
            player_state["kodi_error_state_request_at"] = now
            player_state["kodi_error_state_request_attempts"] = attempts + 1
            _player_debug_log(
                player_state,
                "Kodi-Wiederanbindung wartet auf frischen Soloist-Status "
                "(get_state-Anfrage {}).".format(attempts + 1),
            )
        return

    playback = player_state.get("playback") or {}
    if (
        player_state.get("manual_stop")
        or playback.get("status") not in ("playing", "buffering")
        or playback.get("is_active") is not True
        or not playback.get("item")
    ):
        player_state["kodi_error_reconnect_requested_at"] = None
        _player_debug_log(
            player_state,
            "Kodi-Wiederanbindung nach Playerfehler verworfen; "
            "Soloist meldet keine aktive Wiedergabe mehr.",
        )
        return

    player = player_state["player"]
    if player.isPlaying():
        try:
            current_file = player.getPlayingFile()
        except Exception:
            current_file = None
        if current_file == audio.playback_url:
            player_state["owned"] = True
            player_state["kodi_error_reconnect_requested_at"] = None
            _player_debug_log(
                player_state,
                "Kodi-Player ist wieder aktiv; keine zweite Quelle geöffnet.",
            )
        else:
            player_state["kodi_error_reconnect_requested_at"] = None
            _player_debug_log(
                player_state,
                "Kodi-Wiederanbindung nach Playerfehler abgebrochen; "
                "eine andere Kodi-Quelle spielt.",
            )
        return

    now = time.monotonic()
    attempts = [
        attempt
        for attempt in player_state.get("audio_recovery_attempts", [])
        if now - attempt < 300.0
    ]
    player_state["audio_recovery_attempts"] = attempts
    if len(attempts) >= 2:
        player_state["kodi_error_reconnect_requested_at"] = None
        _player_debug_log(
            player_state,
            "Kodi-Wiederanbindung nach Playerfehler wegen des Limits "
            "von zwei Versuchen in fünf Minuten ausgelassen.",
        )
        xbmcgui.Dialog().notification(
            "Soloist",
            "Kodi-Audiostream konnte nicht wiederhergestellt werden",
            xbmcgui.NOTIFICATION_ERROR,
            5000,
            False,
        )
        return

    url = audio.playback_url
    artist_mbids = _artist_mbids_for_item(musicbrainz_resolver, playback.get("item"))
    item = kodi_music_item(
        {"item": playback.get("item")}, url, xbmcgui.ListItem,
        artist_mbids_by_uri=artist_mbids,
        diagnostic_logger=player_state.get("debug_log"),
    )
    if not url or item is None:
        player_state["kodi_error_reconnect_requested_at"] = None
        _player_debug_log(
            player_state,
            "Kodi-Wiederanbindung nach Playerfehler fehlgeschlagen; "
            "Quelle oder ListItem fehlt.",
        )
        return

    attempts.append(now)
    player_state["audio_recovery_attempts"] = attempts
    player_state["audio_recovery_last_attempt"] = now
    player_state["pending_audio_recovery"] = {
        "requested_at": now,
        "track_identity": _item_identity_key(playback.get("item")),
        "cause": "player_error",
    }
    player_state["owned"] = True
    player_state["kodi_error_reconnect_requested_at"] = None
    _player_debug_log(
        player_state,
        "Kodi-Quelle nach Playerfehler wird aus dem letzten aktiven "
        "Soloist-Status neu geöffnet.",
    )
    try:
        _open_soloist_stream(player_state, url, item, artist_mbids)
    except Exception as error:
        player_state["owned"] = False
        player_state["av_ready"] = False
        player_state["pending_audio_recovery"] = None
        _player_debug_log(
            player_state,
            "Kodi-Wiederanbindung nach Playerfehler konnte nicht angefordert "
            "werden ({}).".format(type(error).__name__),
        )


def _item_identity_key(item):
    if not isinstance(item, dict):
        return None
    decorations = item.get("decorations")
    if not isinstance(decorations, dict):
        return None
    identity = decorations.get("identity")
    if not isinstance(identity, dict):
        return None
    raw_identity = identity.get("uri") or identity.get("name")
    if not isinstance(raw_identity, str) or not raw_identity:
        return None
    return hashlib.sha256(raw_identity.encode("utf-8")).hexdigest()[:10]


def _diagnostic_track_label(item):
    """Return bounded title/artist text for opt-in playback diagnostics."""
    if not isinstance(item, dict):
        return "Titel=unbekannt Interpret=unbekannt"
    decorations = item.get("decorations")
    if not isinstance(decorations, dict):
        decorations = {}
    identity = decorations.get("identity")
    if not isinstance(identity, dict):
        identity = {}
    title = identity.get("name")
    if isinstance(title, str):
        title = " ".join(title.split())[:120]
    else:
        title = ""
    artists = creator_artists(item)
    artist_names = ", ".join(artist["name"] for artist in artists[:4])
    artist_names = " ".join(artist_names.split())[:120]
    return "Titel={} Interpret={}".format(
        title or "unbekannt", artist_names or "unbekannt"
    )


def _log_audio_flow_diagnostic(audio, player_state, websocket):
    """Check recovery conditions and optionally log the detailed audio path."""
    queue_bridge = player_state.get("queue_bridge")
    if queue_bridge and queue_bridge.busy():
        return
    enabled = player_state.get("debug_logging_enabled")
    debug_enabled = bool(callable(enabled) and enabled())
    playback = player_state.get("playback", {})
    if not isinstance(playback, dict) or playback.get("status") not in (
        "playing", "buffering"
    ):
        return
    now = time.monotonic()
    if now - player_state.get("last_audio_flow_diagnostic", 0.0) < AUDIO_FLOW_DIAGNOSTIC_INTERVAL:
        return
    player_state["last_audio_flow_diagnostic"] = now

    player = player_state["player"]
    kodi_playing = False
    kodi_source = "unbekannt"
    kodi_time = None
    current_file = None
    try:
        kodi_playing = _observe_player_call(
            player_state, "isPlaying/Audiofluss", player.isPlaying
        )
        if kodi_playing:
            current_file = _observe_player_call(
                player_state, "getPlayingFile/Audiofluss", player.getPlayingFile
            )
            if current_file == player_state.get("playback_url"):
                kodi_source = "soloist"
            elif isinstance(current_file, str) and current_file.startswith("pvr://"):
                kodi_source = "pvr"
            elif current_file:
                kodi_source = "andere"
            kodi_time = float(_observe_player_call(
                player_state, "getTime/Audiofluss", player.getTime
            ))
        else:
            kodi_source = "keine"
    except Exception as error:
        kodi_source = "abfrage-fehler-{}".format(type(error).__name__)

    position = playback.get("position")
    if not isinstance(position, dict):
        position = {}
    audio_snapshot = (
        audio.diagnostic_snapshot()
        if debug_enabled
        else "PulseAudio-Detaildiagnose=deaktiviert"
    )
    transport_state = audio.recovery_snapshot()
    socket_snapshot = (
        websocket.diagnostic_snapshot()
        if debug_enabled
        else "WebSocket-Detaildiagnose=deaktiviert"
    )
    track_label = _diagnostic_track_label(playback.get("item"))
    track_identity = _item_identity_key(playback.get("item")) or "unbekannt"
    previous = player_state.get("last_audio_flow_sample")
    position_ms = position.get("position_ms")
    speed = position.get("speed")
    estimated_ms = _estimated_soloist_position_ms(position)
    now = time.monotonic()
    interval = now - previous["at"] if previous else None
    same_track = previous and previous.get("track_identity") == track_identity
    kodi_delta = (
        kodi_time - previous["kodi_time"]
        if same_track and kodi_time is not None and previous.get("kodi_time") is not None
        else None
    )
    soloist_delta = (
        estimated_ms - previous["soloist_ms"]
        if same_track and estimated_ms is not None and previous.get("soloist_ms") is not None
        else None
    )
    if (
        kodi_playing
        and not player_state.get("kodi_paused", False)
        and isinstance(speed, (int, float))
        and speed > 0
        and kodi_delta is not None
        and interval is not None
        and interval >= 4.0
    ):
        if 0 <= kodi_delta <= 0.1:
            player_state["kodi_stall_samples"] = player_state.get("kodi_stall_samples", 0) + 1
        else:
            player_state["kodi_stall_samples"] = 0
    else:
        player_state["kodi_stall_samples"] = 0
    stall_samples = player_state.get("kodi_stall_samples", 0)
    stall_marker = " KODI-UHR-STILLSTAND" if stall_samples >= 3 else ""
    zero_pcm_progressed = bool(
        previous
        and transport_state["zero_packets"] > previous.get("zero_packets", 0)
    )
    pcm_silence = bool(
        playback.get("status") == "playing"
        and playback.get("is_active") is True
        and isinstance(speed, (int, float))
        and speed > 0
        and interval is not None
        and interval >= 4.0
        and soloist_delta is not None
        and soloist_delta >= max(2000.0, interval * 500.0)
        and transport_state["connections"] > 0
        and transport_state["packet_age_ms"] is not None
        and transport_state["packet_age_ms"] <= 1500
        and zero_pcm_progressed
        and transport_state["zero_pcm_run_ms"] >= 15000
    )
    # A complete RTP outage is different from a stream of zero-valued PCM:
    # there are no packets to classify as silence, so the earlier detector
    # would never attempt recovery. Require an established packet stream,
    # advancing Soloist position, an owned Kodi stream and a long packet gap.
    rtp_stalled = bool(
        playback.get("status") == "playing"
        and playback.get("is_active") is True
        and isinstance(speed, (int, float))
        and speed > 0
        and interval is not None
        and interval >= 4.0
        and soloist_delta is not None
        and soloist_delta >= max(2000.0, interval * 500.0)
        and transport_state["connections"] > 0
        and transport_state["packet_age_ms"] is not None
        and transport_state["packet_age_ms"] >= 10000
        and transport_state["nonzero_packets"] > 0
    )
    pcm_marker = " PCM_NULLSIGNAL_BEI_FORTSCHRITT" if pcm_silence else ""
    rtp_marker = " RTP-PAKETSTILLSTAND" if rtp_stalled else ""
    owns_current_kodi_source = bool(
        kodi_playing
        and kodi_source == "soloist"
        and current_file == player_state.get("playback_url")
        and player_state.get("owned")
    )
    pending = player_state.get("zero_pcm_recovery_pending")
    if pending is not None:
        still_active = bool(
            owns_current_kodi_source
            and playback.get("status") == "playing"
            and playback.get("is_active") is True
            and websocket.is_connected()
        )
        if not still_active:
            player_state["zero_pcm_recovery_pending"] = None
            player_state["zero_pcm_recovery_nonzero_samples"] = 0
            _player_debug_log(
                player_state,
                "Prüfung der PulseAudio-Wiederherstellung beendet, da Soloist oder "
                "Kodi den aktiven Stream inzwischen verlassen hat.",
            )
        else:
            nonzero_recent = bool(
                transport_state["nonzero_pcm_age_ms"] is not None
                and transport_state["nonzero_pcm_age_ms"] <= 1500
            )
            no_full_zero_packet_since_sample = bool(
                previous
                and transport_state["zero_packets"]
                == previous.get("zero_packets")
            )
            if nonzero_recent and no_full_zero_packet_since_sample:
                recovered_samples = player_state.get(
                    "zero_pcm_recovery_nonzero_samples", 0
                ) + 1
                player_state["zero_pcm_recovery_nonzero_samples"] = recovered_samples
            else:
                player_state["zero_pcm_recovery_nonzero_samples"] = 0

            if player_state.get("zero_pcm_recovery_nonzero_samples", 0) >= 2:
                player_state["zero_pcm_recovery_pending"] = None
                player_state["zero_pcm_recovery_nonzero_samples"] = 0
                _player_debug_log(
                    player_state,
                    "PulseAudio-Wiederherstellung bestätigt: Kodi empfing in zwei "
                    "aufeinanderfolgenden Diagnoseproben Nichtnull-PCM ohne Nullpaket dazwischen.",
                )
                _safe_log(
                    "PulseAudio-Wiederherstellung bestätigt; Nichtnull-Audio ist "
                    "wieder am Kodi-Stream angekommen.",
                    level=xbmc.LOGINFO,
                )
            elif now - pending.get("requested_at", now) >= 30.0:
                player_state["zero_pcm_recovery_pending"] = None
                player_state["zero_pcm_recovery_nonzero_samples"] = 0
                _player_debug_log(
                    player_state,
                    "PulseAudio-Sink-Neustart hat innerhalb von 30 s keinen "
                    "anhaltenden Nichtnull-PCM-Eingang zurückgebracht; "
                    "Soloist-Renderer bleibt als Fehlerquelle bestehen.",
                )
                _safe_log(
                    "PulseAudio-Wiederherstellung brachte innerhalb von 30 s "
                    "keinen anhaltenden Nichtnull-Audiostrom zurück.",
                    level=xbmc.LOGERROR,
                )
                xbmcgui.Dialog().notification(
                    "Soloist",
                    "Kein Ton; Audioausgabe konnte nicht wiederhergestellt werden",
                    xbmcgui.NOTIFICATION_ERROR,
                    5000,
                    False,
                )
    prior_audio_was_present = transport_state["nonzero_pcm_age_ms"] is not None
    audio_loss_recoverable = bool(
        (pcm_silence or rtp_stalled)
        and not player_state.get("kodi_paused", False)
        and owns_current_kodi_source
        and websocket.is_connected()
        and prior_audio_was_present
    )
    if pending is None and audio_loss_recoverable:
        recovery = audio.request_zero_pcm_recovery()
        if recovery == "started":
            player_state["zero_pcm_recovery_pending"] = {
                "requested_at": now,
                "track_identity": track_identity,
            }
            player_state["zero_pcm_recovery_nonzero_samples"] = 0
            _player_debug_log(
                player_state,
                "Audioverlust bei fortschreitender Soloist-Position erkannt ({}); "
                "kontrollierter Neustart nur des virtuellen PulseAudio-Sinks angefordert.".format(
                    "RTP-Paketstillstand seit {} ms".format(
                        transport_state["packet_age_ms"]
                    )
                    if rtp_stalled
                    else "Null-PCM seit {} ms".format(
                        transport_state["zero_pcm_run_ms"]
                    )
                ),
            )
            _safe_log(
                "Audioverlust erkannt; kontrollierte PulseAudio-Wiederherstellung "
                "angefordert ({}).".format(
                    "RTP-Paketstillstand seit {} ms".format(
                        transport_state["packet_age_ms"]
                    )
                    if rtp_stalled
                    else "Null-PCM seit {} ms".format(
                        transport_state["zero_pcm_run_ms"]
                    )
                ),
                level=xbmc.LOGINFO,
            )
        elif recovery == "cooldown" and not player_state.get(
            "zero_pcm_recovery_cooldown_logged"
        ):
            player_state["zero_pcm_recovery_cooldown_logged"] = True
            _player_debug_log(
                player_state,
                "PulseAudio-Sink-Neustart wegen Sicherheitsabstand übersprungen; "
                "Null-PCM besteht weiter.",
            )
    player_state["last_audio_flow_sample"] = {
        "at": now,
        "kodi_time": kodi_time,
        "soloist_ms": estimated_ms,
        "track_identity": track_identity,
        "tcp_bytes_sent": transport_state["sent_bytes"],
        "tcp_dropped_bytes": transport_state["dropped_bytes"],
        "zero_packets": transport_state["zero_packets"],
        "packet_age_ms": transport_state["packet_age_ms"],
    }
    source_progressed = bool(
        previous
        and (
            transport_state["sent_bytes"] > previous.get("tcp_bytes_sent", 0)
            or transport_state["dropped_bytes"]
            > previous.get("tcp_dropped_bytes", 0)
        )
    )
    if (
        stall_samples >= 3
        and not player_state.get("kodi_paused", False)
        and kodi_playing
        and kodi_source == "soloist"
        and current_file == player_state.get("playback_url")
        and playback.get("status") == "playing"
        and playback.get("is_active") is True
        and isinstance(speed, (int, float))
        and speed > 0
        and transport_state["connections"] > 0
        and transport_state["packet_age_ms"] is not None
        and transport_state["packet_age_ms"] <= 1500
        and transport_state["nonzero_pcm_age_ms"] is not None
        and transport_state["nonzero_pcm_age_ms"] <= 1500
        and source_progressed
    ):
        _recover_stalled_kodi_stream(audio, player_state, playback)
    if debug_enabled:
        try:
            labels = ["MusicPlayer.Title", "MusicPlayer.Artist", "Player.Art(fanart)",
                      "Window(Visualisation).Property(ArtistSlideshow.Image)",
                      "MusicPlayer.Duration", "Player.Duration", "Player.Time", "Player.Progress"]
            display_started = time.monotonic()
            response = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "XBMC.GetInfoLabels",
                "params": {"labels": labels},
            })))
            values = response.get("result") if isinstance(response, dict) else None
            if not isinstance(values, dict) or any(not isinstance(values.get(key), str) for key in labels):
                raise ValueError("Incomplete Kodi display response")
            title = " ".join(values[labels[0]].split())[:120]
            artist = " ".join(values[labels[1]].split())[:120]
            fanart = bool(values[labels[2]])
            slideshow = bool(values[labels[3]])
            music_duration, player_duration, player_time, player_progress = (
                " ".join(values[key].split())[:40] or "unbekannt" for key in labels[4:]
            )
            display_ms = (time.monotonic() - display_started) * 1000
            _player_debug_log(
                player_state,
                "Kodi-Anzeigeprobe: Titel={} Interpret={} Fanart_vorhanden={} "
                "ArtistSlideshow_Bild_vorhanden={} Musikdauer={} Playerdauer={} "
                "Playerzeit={} Fortschritt={} AV_bestätigt={} Tag_ausstehend={} Abfrage={:.1f}ms.".format(
                    title or "leer", artist or "leer", fanart, slideshow,
                    music_duration, player_duration, player_time, player_progress,
                    bool(player_state.get("av_ready")),
                    player_state.get("pending_info_tag") is not None, display_ms,
                ),
            )
        except (RuntimeError, ValueError, TypeError) as error:
            _player_debug_log(player_state, "Kodi-Anzeigeprobe nicht verfügbar ({}).".format(
                type(error).__name__))
        _player_debug_log(
            player_state,
            "Audioflussprobe: Track={} {}; Soloist={} aktiv={} Position={}ms "
        "geschätzt={}ms Δ={}ms Tempo={}; Kodi-Player={} Quelle={} Zeit={}s Δ={}s "
            "Messintervall={}s Stillstandproben={}/3{}; {}; {}.".format(
            track_identity,
            track_label,
            playback.get("status"),
            str(playback.get("is_active")).lower(),
            position_ms,
            estimated_ms,
            "unbekannt" if soloist_delta is None else int(soloist_delta),
            speed,
            ("pausiert" if player_state.get("kodi_paused", False)
             else "läuft" if kodi_playing else "steht"),
            kodi_source,
            "unbekannt" if kodi_time is None else "{:.3f}".format(kodi_time),
            "unbekannt" if kodi_delta is None else "{:.3f}".format(kodi_delta),
            "unbekannt" if interval is None else "{:.1f}".format(interval),
            stall_samples,
            stall_marker + pcm_marker + rtp_marker,
            socket_snapshot,
            audio_snapshot,
            ),
        )


def _log_queue_failure(player_state, error, phase):
    # No exception text, URLs, frame locals or command payloads: the exact code
    # location distinguishes a transient player read from a failed mutation.
    frames = traceback.extract_tb(error.__traceback__)
    location = ("{}:{}".format(os.path.basename(frames[-1].filename), frames[-1].lineno)
                if frames else "unbekannt")
    bridge = player_state.get("queue_bridge")
    pending = bridge.pending if bridge else None
    _player_debug_log(player_state,
        "Native Queue: {} {} Stelle={} Steuerphase={} Folgeaktionen={} AV={}.".format(
            phase, type(error).__name__, location,
            pending.get("phase") if pending else "keine", len(bridge.actions) if bridge else 0,
            bool(player_state.get("av_ready"))))


class SoloistKodiPlayer(xbmc.Player):
    def __init__(self, websocket, player_state):
        super().__init__()
        self.websocket = websocket
        self.player_state = player_state
        self.suppressed_callbacks = {}

    def suppress_next(self, callback_name):
        self.suppressed_callbacks[callback_name] = time.monotonic()

    def _consume_suppressed(self, callback_name):
        suppressed_at = self.suppressed_callbacks.pop(callback_name, None)
        if suppressed_at is None:
            return False
        if time.monotonic() - suppressed_at <= 10.0:
            return True
        _player_debug_log(
            self.player_state,
            "Veraltete interne Callback-Unterdrückung {} verworfen.".format(
                callback_name
            ),
        )
        return False

    def _log_callback(self, callback_name, detail=""):
        enabled = self.player_state.get("debug_logging_enabled")
        if not callable(enabled) or not enabled():
            return
        try:
            is_playing = _observe_player_call(
                self.player_state, "isPlaying/Callback", self.isPlaying
            )
            source = (_observe_player_call(
                self.player_state, "getPlayingFile/Callback", self.getPlayingFile
            ) if is_playing else "keine")
            player_time = (_observe_player_call(
                self.player_state, "getTime/Callback", self.getTime
            ) if is_playing else None)
        except Exception as error:
            is_playing = "unbekannt"
            source = "abfrage-fehler-{}".format(type(error).__name__)
            player_time = None
        source_kind = (
            "soloist" if source == self.player_state.get("playback_url")
            else "pvr" if isinstance(source, str) and source.startswith("pvr://")
            else "andere" if source not in (None, "keine")
            else "keine"
        )
        snapshot = getattr(self.websocket, "diagnostic_snapshot", None)
        socket_state = snapshot() if callable(snapshot) else "WebSocket-Telemetrie=unbekannt"
        _player_debug_log(
            self.player_state,
            "Kodi-Callback {}: Player={} Quelle={} Zeit={}s {}; {}".format(
                callback_name,
                "läuft" if is_playing is True else is_playing,
                source_kind,
                "unbekannt" if player_time is None else "{:.3f}".format(player_time),
                detail,
                socket_state,
            ).strip(),
        )

    def onPlayBackStarted(self):
        if self.player_state.get("owned"):
            self.player_state["kodi_paused"] = False
            self.player_state["av_ready"] = False
        queue_bridge = self.player_state.get("queue_bridge")
        if queue_bridge and self.player_state.get("owned"):
            generation = self.player_state.get("source_generation", 0) + 1
            self.player_state["source_generation"] = generation
            queue_bridge.callback("started", generation)
        self._log_callback("started")

    def onPlayBackEnded(self):
        self._log_callback("ended")
        queue_bridge = self.player_state.get("queue_bridge")
        if queue_bridge:
            queue_bridge.callback("ended", self._handle_stream_end)
            return
        self._handle_stream_end()

    def _handle_stream_end(self):
        if (
            self.player_state.get("paused_stream_detached")
            and self.player_state.get("pause_stop_expected")
        ):
            _player_debug_log(self.player_state, "Erwartetes Streamende bei Soloist-Pause.")
            return
        if not self.player_state.get("owned"):
            return
        try:
            kodi_still_playing = self.isPlaying()
        except Exception:
            kodi_still_playing = True
        if kodi_still_playing:
            return
        self.player_state["owned"] = False
        self.player_state["av_ready"] = False
        self.player_state["kodi_paused"] = False
        self.player_state["pending_info_tag"] = None
        self.player_state["kodi_error_reconnect_requested_at"] = time.monotonic()
        self.player_state["kodi_error_state_confirmed"] = False
        self.player_state["kodi_error_state_request_at"] = None
        self.player_state["kodi_error_state_request_attempts"] = 0
        _player_debug_log(
            self.player_state,
            "Kodi-Player endete während Soloist weiterlaufen kann; Besitz freigegeben, "
            "vor einer Wiederöffnung wird frischer Soloist-Status abgefragt.",
        )

    def onPlayBackError(self):
        self._log_callback("error")
        queue_bridge = self.player_state.get("queue_bridge")
        if queue_bridge:
            queue_bridge.callback("cancel", "Kodi-Playerfehler")
        if (
            self.player_state.get("paused_stream_detached")
            and self.player_state.get("pause_stop_expected")
        ):
            _player_debug_log(self.player_state, "Player meldet Abschluss des Pausenstreams.")
            return
        try:
            kodi_still_playing = self.isPlaying()
        except Exception:
            kodi_still_playing = True

        # Kodi can reject/terminate the TCP PCM source without changing
        # Soloist's upstream playback state. Release ownership so the next
        # authoritative Soloist playback event can attach the stream again.
        if self.player_state.get("owned") and not kodi_still_playing:
            self.player_state["owned"] = False
            self.player_state["av_ready"] = False
            self.player_state["pending_info_tag"] = None
            self.player_state["kodi_error_reconnect_requested_at"] = time.monotonic()
            self.player_state["kodi_error_state_confirmed"] = False
            self.player_state["kodi_error_state_request_at"] = None
            self.player_state["kodi_error_state_request_attempts"] = 0
            _player_debug_log(
                self.player_state,
                "Kodi-Playerfehler hat den Soloist-Player beendet; "
                "frage vor einer Wiederanbindung den aktuellen Soloist-Status ab.",
            )
        if self.player_state.get("pending_audio_recovery") is not None:
            self.player_state["pending_audio_recovery"] = None
            _player_debug_log(
                self.player_state,
                "Kodi meldet einen Playerfehler bei der Audio-Wiederöffnung.",
            )
            xbmcgui.Dialog().notification(
                "Soloist",
                "Kodi konnte den Audiostream nicht öffnen",
                xbmcgui.NOTIFICATION_ERROR,
                4000,
                False,
            )

    def onPlayBackSpeedChanged(self, speed):
        self._log_callback("speed_changed", "Tempo={}".format(speed))

    def onAVStarted(self):
        self._log_callback("av_started")
        source_known = True
        try:
            current_file = self.getPlayingFile()
        except Exception as error:
            current_file = None
            source_known = False
            _player_debug_log(
                self.player_state,
                "Kodi-AV-Quelle konnte nicht ermittelt werden ({}).".format(
                    type(error).__name__
                ),
            )
        soloist_file = self.player_state.get("playback_url")
        pending_recovery = self.player_state.get("pending_audio_recovery")
        if pending_recovery is not None and source_known:
            if current_file == soloist_file:
                self.player_state["pending_audio_recovery"] = None
                _player_debug_log(
                    self.player_state,
                    "Kodi bestätigt nach der Wiederöffnung onAVStarted für den Soloist-Stream.",
                )
                if pending_recovery.get("reason") not in ("resume", "start"):
                    xbmcgui.Dialog().notification(
                        "Soloist",
                        "Kodi hat den Audiostream erneut geöffnet",
                        xbmcgui.NOTIFICATION_INFO,
                        3000,
                        False,
                    )
            else:
                self.player_state["pending_audio_recovery"] = None
                _player_debug_log(
                    self.player_state,
                    "Wiederöffnung wurde durch eine andere Kodi-Quelle abgelöst.",
                )
        if (
            self.player_state["owned"]
            and current_file
            and soloist_file
            and current_file != soloist_file
        ):
            paused = self.websocket.send_command("pause")
            self.player_state["owned"] = False
            self.player_state["av_ready"] = False
            self.player_state["pending_info_tag"] = None
            self.player_state["manual_stop"] = paused
            queue_bridge = self.player_state.get("queue_bridge")
            if queue_bridge:
                queue_bridge.callback("cancel", "Andere Kodi-Quelle")
            _player_debug_log(
                self.player_state,
                "Fremde Kodi-Quelle gestartet; Soloist-Pause vorgemerkt={}.".format(
                    str(paused).lower()
                ),
            )
            return
        _player_debug_log(
            self.player_state,
            "Kodi-AV-Quelle erkannt: {}.".format(
                "Soloist" if current_file == soloist_file else "andere oder unbekannt"
            ),
        )
        self.player_state["av_ready"] = bool(
            soloist_file and current_file == soloist_file
        )
        key = self.player_state.get("stream_request_key")
        receipt = xbmcgui.Window(WINDOW_ID).getProperty(key + ".ready") if key else ""
        if self.player_state["av_ready"]:
            initial_revision = self.player_state.pop("resolved_metadata_revision", None)
            if initial_revision is not None and receipt == initial_revision:
                self.player_state["applied_info_tag_revision"] = initial_revision
                if self.player_state.get("info_tag_revision") == initial_revision:
                    self.player_state["pending_info_tag"] = None
                    _player_debug_log(self.player_state,
                        "Startmetadaten durch den bestätigten Plugin-Stream übernommen.")
        key = self.player_state.pop("stream_request_key", None)
        if key:
            xbmcgui.Window(WINDOW_ID).clearProperty(key)
            xbmcgui.Window(WINDOW_ID).clearProperty(key + ".ready")
        queue_bridge = self.player_state.get("queue_bridge")
        if queue_bridge:
            queue_bridge.callback("av_started", current_file)
        else:
            _flush_pending_info_tag(self.player_state)

    def _user_action(self, callback_name, command, **fields):
        if self._consume_suppressed(callback_name):
            _player_debug_log(
                self.player_state,
                "Kodi-Playercallback {} wurde intern unterdrückt.".format(callback_name)
            )
            return False
        if self.player_state["owned"]:
            queued = self.websocket.send_command(command, **fields)
            _player_debug_log(
                self.player_state,
                "Kodi-Playercallback {} an Soloist vorgemerkt={}.".format(
                    callback_name, str(queued).lower()
                )
            )
            return bool(queued)
        _player_debug_log(
            self.player_state,
            "Kodi-Playercallback {} ohne Add-on-Playerbesitz.".format(callback_name)
        )
        return False

    def onPlayBackPaused(self):
        queue_bridge = self.player_state.get("queue_bridge")
        if queue_bridge:
            queue_bridge.callback("cancel", "Kodi-Pause")
        if self.player_state.get("owned"):
            self.player_state["kodi_paused"] = True
        self._log_callback("paused")
        self._user_action("pause", "pause")

    def onPlayBackResumed(self):
        queue_bridge = self.player_state.get("queue_bridge")
        if queue_bridge:
            queue_bridge.callback("cancel", "Kodi-Fortsetzen während Übergabe")
        if self.player_state.get("owned"):
            self.player_state["kodi_paused"] = False
        self._log_callback("resumed")
        self._user_action("resume", "play")

    def onPlayBackStopped(self):
        queue_bridge = self.player_state.get("queue_bridge")
        if queue_bridge:
            queue_bridge.callback("cancel", "Kodi-Stopp")
        self.player_state["kodi_paused"] = False
        self._log_callback("stopped")
        if (
            self.player_state.get("paused_stream_detached")
            and self.player_state.get("pause_stop_expected")
        ):
            self._consume_suppressed("stop")
            self.player_state["owned"] = False
            self.player_state["av_ready"] = False
            self.player_state["pause_stop_confirmed"] = True
            self.player_state["pause_stop_expected"] = False
            _player_debug_log(self.player_state, "Pausenstream in Kodi gestoppt.")
            return
        if self._consume_suppressed("stop"):
            return
        if self._user_action("stop", "pause"):
            self.player_state["manual_stop"] = True
        self.player_state["owned"] = False
        self.player_state["av_ready"] = False

    def onPlayBackSeek(self, time, seek_offset):
        # Kodi delivers both arguments in milliseconds, relative to its stream.
        # Only the delta can be applied to the independent Soloist song clock.
        self._log_callback(
            "seek", "Streamziel={}ms Offset={}ms".format(time, seek_offset)
        )
        queue_bridge = self.player_state.get("queue_bridge")
        if queue_bridge and queue_bridge.busy():
            return
        if not self.player_state["owned"] or not self.player_state.get("av_ready"):
            return
        expected_source = self.player_state.get("playback_url")
        try:
            current_source = _observe_player_call(
                self.player_state, "getPlayingFile/Seek", self.getPlayingFile
            )
        except RuntimeError:
            return  # Playback can finish between the callback and this read.
        if not expected_source or current_source != expected_source:
            return
        position = _estimated_soloist_position_ms(
            (self.player_state.get("playback") or {}).get("position")
        )
        if (
            position is None or isinstance(seek_offset, bool)
            or not isinstance(seek_offset, (int, float)) or not math.isfinite(seek_offset)
        ):
            _player_debug_log(
                self.player_state,
                "Kodi-Suchaktion nicht weitergegeben: Soloist-Position oder Offset unbekannt.",
            )
            return
        target_ms = max(0, position + int(seek_offset))
        queued = self.websocket.send_command("seek", position_ms=target_ms)
        _player_debug_log(
            self.player_state,
            "Kodi-Suchaktion: Soloist-Ziel={}ms Offset={}ms vorgemerkt={}.".format(
                target_ms, seek_offset, str(queued).lower()
            ),
        )


def _stop_owned_player(player_state):
    if not player_state["owned"]:
        return "not_owned"
    player = player_state["player"]
    try:
        is_playing = player.isPlaying()
    except Exception as error:
        _player_debug_log(
            player_state,
            "Kodi-Playerstatus vor Stopp nicht lesbar; stop wird zur Sicherheit "
            "nicht aufgerufen ({}).".format(type(error).__name__),
        )
        return "failed"
    if not is_playing:
        player_state["owned"] = False
        player_state["av_ready"] = False
        player_state["pending_info_tag"] = None
        _player_debug_log(
            player_state,
            "Kodi-Playerstopp übersprungen: Player steht bereits; "
            "kein Kodi-Playeraufruf erforderlich.",
        )
        return "not_playing"
    try:
        current_file = player.getPlayingFile()
    except Exception as error:
        _player_debug_log(
            player_state,
            "Kodi-Quelle vor Stopp nicht lesbar; fremde Wiedergabe bleibt "
            "unangetastet ({}).".format(type(error).__name__),
        )
        return "failed"
    if current_file != player_state.get("playback_url"):
        player_state["owned"] = False
        player_state["av_ready"] = False
        player_state["pending_info_tag"] = None
        _player_debug_log(
            player_state,
            "Kodi-Playerstopp übersprungen: Kodi spielt eine andere Quelle; "
            "diese bleibt unangetastet.",
        )
        return "other_source"
    player_state["owned"] = False
    player_state["av_ready"] = False
    player_state["pending_info_tag"] = None
    player.suppress_next("stop")
    player.stop()
    return "stopped"


def _stop_owned_player_and_wait(player_state, timeout=3.0):
    stop_result = _stop_owned_player(player_state)
    if stop_result == "failed":
        return False
    if stop_result != "stopped":
        return True
    player = player_state["player"]
    deadline = time.monotonic() + max(0.0, float(timeout))
    while time.monotonic() < deadline:
        if not player.isPlaying():
            return True
        xbmc.sleep(100)
    return not player.isPlaying()


def _shutdown_step(name, callback, api_key):
    """Run one shutdown action without skipping the remaining cleanup on failure."""
    _safe_log("Kodi-Shutdown: {} beginnt.".format(name), api_key, xbmc.LOGDEBUG)
    try:
        result = callback()
    except Exception as error:
        _safe_log(
            "Kodi-Shutdown: {} fehlgeschlagen ({}).".format(
                name, type(error).__name__
            ),
            api_key,
            xbmc.LOGERROR,
        )
        return False
    else:
        _safe_log("Kodi-Shutdown: {} abgeschlossen.".format(name), api_key, xbmc.LOGDEBUG)
        return result is not False


def _control_request(websocket, process, control, playback):
    if not process.is_running():
        return "not_running"
    if control == "toggle":
        status = playback.get("status") if isinstance(playback, dict) else None
        command = "pause" if status in ("playing", "buffering") else "play"
    else:
        command = {"previous": "skip_prev", "next": "skip_next"}.get(control)
    if command is None:
        return "invalid_command"
    return "control_queued" if websocket.send_command(command) else "command_failed"


def _command_state_matches(pending, state, event_type):
    command = pending.get("command")
    status = state.get("status")
    if event_type != "command_result":
        if command in ("pause", "play") and event_type not in (
            "playback_changed",
            "playback_state",
            "position_sync",
        ):
            return False
        if command in ("skip_next", "skip_prev") and event_type not in (
            "track_changed",
            "playback_state",
        ):
            return False
    if command == "pause":
        return status == "paused" or (
            event_type == "position_sync"
            and isinstance(state.get("position"), dict)
            and state["position"].get("speed") == 0.0
        )
    if command == "play":
        return status in ("playing", "buffering") and state.get("is_active") is True
    if command in ("skip_next", "skip_prev"):
        if event_type == "track_changed":
            return True
        current_track = _item_identity_key(state.get("item"))
        if current_track and current_track != pending.get("track_before"):
            return True
        changed_at = state.get("last_track_changed_at")
        accepted_at = pending.get("accepted_at")
        return (
            isinstance(changed_at, (int, float))
            and isinstance(accepted_at, (int, float))
            and -1.0 <= accepted_at - changed_at <= 3.0
        )
    return False


def _record_command_acceptance(event, player_state):
    command = event.get("command")
    if command not in ("pause", "play", "skip_next", "skip_prev"):
        return
    state = dict(player_state.get("playback") or {})
    state["last_track_changed_at"] = player_state.get("last_track_changed_at")
    pending = {
        "command": command,
        "accepted_at": time.monotonic(),
        "track_before": _item_identity_key(state.get("item")),
    }
    if _command_state_matches(pending, state, "command_result"):
        _player_debug_log(
            player_state,
            "Soloist-Befehl {} angenommen; passender Wiedergabestatus ist "
            "bereits beobachtet.".format(command),
        )
        return
    pending_commands = player_state.setdefault("pending_command_confirmations", [])
    pending_commands.append(pending)
    if len(pending_commands) > 16:
        expired = pending_commands.pop(0)
        _player_debug_log(
            player_state,
            "Statusbestätigung für Befehl {} wegen zu vieler offener "
            "Bestätigungen verworfen.".format(expired["command"]),
        )


def _confirm_playback_command(event, player_state):
    pending_commands = player_state.get("pending_command_confirmations", [])
    state = dict(player_state.get("playback") or {})
    state["last_track_changed_at"] = player_state.get("last_track_changed_at")
    remaining = []
    for pending in pending_commands:
        if _command_state_matches(pending, state, event.get("type")):
            _player_debug_log(
                player_state,
                "Soloist-Befehl {}: passender Status nach Annahme beobachtet "
                "(Ereignis {}).".format(pending["command"], event.get("type")),
            )
        else:
            remaining.append(pending)
    player_state["pending_command_confirmations"] = remaining


def _expire_playback_command_confirmations(player_state, now=None):
    now = time.monotonic() if now is None else now
    remaining = []
    for pending in player_state.get("pending_command_confirmations", []):
        if now - pending.get("accepted_at", now) >= COMMAND_CONFIRMATION_TIMEOUT:
            _player_debug_log(
                player_state,
                "Soloist-Befehl {} wurde angenommen, aber innerhalb von {} s "
                "wurde kein passender Wiedergabestatus beobachtet; es erfolgt "
                "keine automatische Wiederholung.".format(
                    pending["command"], int(COMMAND_CONFIRMATION_TIMEOUT)
                ),
            )
        else:
            remaining.append(pending)
    player_state["pending_command_confirmations"] = remaining


def _start_soloist(addon, data_path, process, audio, websocket, allow_download=False):
    """Start Soloist without reporting success before the process exists."""
    api_key = load_api_key(data_path)
    device_name = addon.getSetting("device_name").strip()
    if not api_key or not device_name:
        return "configuration_missing"

    binary_path = os.path.join(data_path, "soloist", "bin", "soloist")
    if not os.path.isfile(binary_path):
        if not allow_download:
            return "binary_missing"
        try:
            binary_path, version = install_soloist(data_path)
            _safe_log("Spotify Soloist installiert: {}".format(version), api_key)
        except SoloistRuntimeError as error:
            _safe_log(
                "Soloist-Installation fehlgeschlagen: {}".format(error),
                api_key,
                xbmc.LOGERROR,
            )
            return "install_failed"
        process.binary_path = binary_path

    if process.is_running():
        return "already_running"

    try:
        audio.setup()
    except AudioSetupError as error:
        _safe_log(
            "PulseAudio-/TCP-Audiopfad konnte nicht eingerichtet werden: {}".format(error),
            api_key,
            xbmc.LOGERROR,
        )
        return "audio_setup_failed"

    try:
        code = process.start(
            device_name,
            api_key,
            audio_sink=audio.sink_name,
        )
    except Exception:
        audio.cleanup()
        raise
    if code != "started":
        audio.cleanup()
        if code == "start_failed":
            _safe_log("Soloist-Prozess konnte nicht gestartet werden.", api_key, xbmc.LOGERROR)
        return code

    try:
        websocket.start()
    except Exception:
        process.stop()
        audio.cleanup()
        raise
    if not process.is_running():
        websocket.stop()
        process.poll_exit()
        audio.cleanup()
        return "start_failed"
    _safe_log("Soloist-Prozess läuft; Steuerverbindung wird aufgebaut.", api_key)
    return "started"


def _handle_command(command, addon, data_path, process, window, audio, websocket, player_state):
    request_id = command.get("request_id")
    action = command.get("action")
    queue_bridge = player_state.get("queue_bridge")
    if queue_bridge and action in ("stop", "prepare_update"):
        queue_bridge.close()
    if action == "stop":
        audio.close_tcp_clients("Soloist-Stopp über Add-on-Menü")
        code = process.stop()
        websocket.stop()
        _stop_owned_player(player_state)
        player_state["playback"] = {}
        player_state["last_status"] = None
        player_state["manual_stop"] = False
        player_state["paused_stream_detached"] = False
        player_state["pause_stop_expected"] = False
        player_state["pending_audio_recovery"] = None
        audio.cleanup()
        player_state["connection_notice_deadline"] = None
        player_state["connection_failure_notified"] = False
        player_state["connection_was_ready"] = False
        _result(window, request_id, code)
        return
    if action == "prepare_update":
        if not request_id:
            _result(window, request_id, "invalid_command")
            return
        player_state["update_request_id"] = request_id
        _result(window, request_id, "stopping_for_update")
        _safe_log("Kodi-Updatevorbereitung angefordert; Dienst fährt kontrolliert herunter.", process.api_key)
        return
    if action == "status":
        if process.is_running():
            code = "ready" if websocket.is_connected() else "running_disconnected"
        elif not load_api_key(data_path) or not addon.getSetting("device_name").strip():
            code = "configuration_missing"
        elif not os.path.isfile(os.path.join(data_path, "soloist", "bin", "soloist")):
            code = "binary_missing"
        else:
            code = "not_running"
        _result(window, request_id, code)
        return
    if action == "control":
        if queue_bridge and queue_bridge.busy():
            if (command.get("control") == "toggle"
                    and player_state.get("playback", {}).get("status") in ("playing", "buffering")):
                queue_bridge.cancel("Pause über Add-on-Menü")
            else:
                _result(window, request_id, "command_failed")
                return
        code = _control_request(
            websocket,
            process,
            command.get("control"),
            player_state["playback"],
        )
        _result(window, request_id, code)
        return
    if action != "start":
        _result(window, request_id, "invalid_command")
        return
    code = _start_soloist(
        addon,
        data_path,
        process,
        audio,
        websocket,
        allow_download=bool(command.get("allow_download")),
    )
    if code in ("started", "already_running"):
        if code == "started":
            player_state["paused_stream_detached"] = False
            player_state["pause_stop_expected"] = False
            player_state["pending_audio_recovery"] = None
        player_state["playback_url"] = audio.playback_url
        player_state["connection_notice_deadline"] = (
            time.monotonic() + CONNECTION_NOTICE_TIMEOUT
        )
        player_state["connection_failure_notified"] = False
        player_state["connection_was_ready"] = websocket.is_connected()
    _result(window, request_id, code)


def _artist_mbids_for_item(resolver, item):
    if resolver is None:
        return {}
    artist_mbids = {}
    for artist in creator_artists(item):
        mbid = resolver.lookup_or_queue(artist["uri"], artist["name"])
        if mbid:
            artist_mbids[artist["uri"]] = mbid
    return artist_mbids


def _apply_musicbrainz_result(result, resolver, audio, player_state):
    if result is None:
        return
    artist_uri, mbid = result
    if not mbid or not player_state.get("owned"):
        return
    item = player_state.get("playback", {}).get("item")
    if not any(artist["uri"] == artist_uri for artist in creator_artists(item)):
        return
    artist_mbids = _artist_mbids_for_item(resolver, item)
    list_item = kodi_music_item(
        {"item": item},
        audio.playback_url,
        xbmcgui.ListItem,
        artist_mbids_by_uri=artist_mbids,
        diagnostic_logger=player_state.get("debug_log"),
    )
    if list_item is None:
        return
    _queue_info_tag(player_state, list_item, artist_mbids)


def _resume_detached_stream(audio, player_state, musicbrainz_resolver=None):
    """Reopen at the live edge only after the old Kodi player has stopped."""
    if not player_state.get("paused_stream_detached"):
        return
    if not player_state.get("pause_stop_confirmed"):
        requested_at = player_state.get("pause_stop_requested_at", time.monotonic())
        if time.monotonic() - requested_at < 3.0:
            return
        if not player_state["player"].isPlaying():
            player_state["pause_stop_confirmed"] = True
            player_state["pause_stop_expected"] = False
            _player_debug_log(
                player_state,
                "Stoppcallback fehlt; Kodi bestätigt nach Statusabfrage "
                "einen stehenden Player. Fortsetzen ist wieder zulässig.",
            )
        elif not player_state.get("pause_stop_timeout_logged"):
            player_state["pause_stop_timeout_logged"] = True
            _player_debug_log(
                player_state,
                "Kodi bestätigt den Pausenstopp nicht innerhalb von 3 s; "
                "kein neuer Audiostream wird darübergelegt.",
            )
        if not player_state.get("pause_stop_confirmed"):
            return
    state = player_state.get("playback") or {}
    if (
        state.get("status") != "playing"
        or state.get("is_active") is not True
        or not state.get("item")
        or player_state.get("manual_stop")
        or player_state["player"].isPlaying()
    ):
        return
    artist_mbids = _artist_mbids_for_item(musicbrainz_resolver, state["item"])
    item = kodi_music_item(
        {"item": state["item"]}, audio.playback_url, xbmcgui.ListItem,
        artist_mbids_by_uri=artist_mbids,
        diagnostic_logger=player_state.get("debug_log"),
    )
    if item is None:
        return
    audio.set_playback_enabled(True)
    player_state["paused_stream_detached"] = False
    player_state["pause_stop_expected"] = False
    player_state["kodi_paused"] = False
    player_state["owned"] = True
    player_state["pending_info_tag"] = item
    player_state["pending_audio_recovery"] = {
        "requested_at": time.monotonic(),
        "track_identity": _item_identity_key(state["item"]),
        "reason": "resume",
    }
    _player_debug_log(
        player_state,
        "Soloist setzt fort: neuer PCM-Stream nach bestätigtem Kodi-Stopp; "
        "Startbestätigung durch onAVStarted steht aus.",
    )
    try:
        _open_soloist_stream(player_state, audio.playback_url, item, artist_mbids)
    except Exception as error:
        player_state["owned"] = False
        player_state["av_ready"] = False
        player_state["pending_audio_recovery"] = None
        player_state["kodi_error_reconnect_requested_at"] = time.monotonic()
        player_state["kodi_error_state_confirmed"] = False
        player_state["kodi_error_state_request_at"] = None
        player_state["kodi_error_state_request_attempts"] = 0
        _player_debug_log(
            player_state,
            "Pausenstream konnte nicht neu geöffnet werden ({}); "
            "bestehende begrenzte Recovery fragt frischen Soloist-Status ab.".format(
                type(error).__name__
            ),
        )


def _handle_playback_event(
    event, audio, player_state, addon, musicbrainz_resolver=None, websocket=None
):
    if (
        event.get("type") == "playback_state"
        and player_state.get("kodi_error_reconnect_requested_at") is not None
        and player_state.get("kodi_error_state_request_at") is not None
    ):
        player_state["kodi_error_state_confirmed"] = True
        _player_debug_log(
            player_state,
            "Frischer Soloist-playback_state nach Kodi-Playerfehler empfangen.",
        )
    player_state["playback"] = playback_snapshot(event, player_state["playback"])
    state = player_state["playback"]
    queue_bridge = player_state.get("queue_bridge")
    if queue_bridge and queue_bridge.handle_event(event):
        return
    previous_status = player_state["last_status"]
    previous_active = player_state.get("last_active")
    position = state.get("position")
    if not isinstance(position, dict):
        position = {}
    if (
        state.get("status") != previous_status
        or state.get("is_active") != previous_active
        or event.get("type") in ("track_changed", "device_changed", "auth_state")
    ):
        snapshot = getattr(websocket, "diagnostic_snapshot", None)
        socket_state = snapshot() if callable(snapshot) else "WebSocket-Telemetrie=unbekannt"
        _player_debug_log(
            player_state,
            "Soloist-Ereignis type={} status={} aktiv={} position_ms={} tempo={}; {}.".format(
                event.get("type"),
                state.get("status"),
                state.get("is_active"),
                position.get("position_ms"),
                position.get("speed"),
                socket_state,
            )
        )
    player_state["last_status"] = state.get("status")
    player_state["last_active"] = state.get("is_active")
    if state.get("status") in ("paused", "idle") or state.get("is_active") is False:
        player_state["last_blocked_track_key"] = None
        player_state["last_blocked_notification_at"] = None
    item = state.get("item") or {}
    if player_state["manual_stop"] and state.get("status") in ("playing", "buffering"):
        resumed = (
            previous_status in ("paused", "idle")
            or event.get("type") == "playback_changed"
            or (
                event.get("type") == "device_changed"
                and state.get("is_active") is True
                and previous_active is False
            )
        )
        if not resumed:
            return
        player_state["manual_stop"] = False
    if event.get("type") == "auth_state" and not event.get("logged_in"):
        _stop_owned_player(player_state)
        return

    try:
        _log_position_diagnostic(event, player_state)
    except Exception as error:
        _safe_log(
            "Player-Zeitprobe übersprungen ({})".format(type(error).__name__),
            level=xbmc.LOGDEBUG,
        )

    enabled = player_state.get("debug_logging_enabled")
    buffer_snapshot = getattr(audio, "buffer_snapshot", None)
    if (
        callable(enabled) and enabled()
        and callable(buffer_snapshot)
        and event.get("type") in (
            "position_sync", "volume_changed", "playback_changed", "track_changed"
        )
    ):
        sequence = player_state.get("audio_marker_sequence", 0) + 1
        player_state["audio_marker_sequence"] = sequence
        marker_position = position.get("position_ms")
        marker_speed = position.get("speed")
        volume = event.get("volume")
        if not isinstance(marker_position, (int, float)) or not math.isfinite(marker_position):
            marker_position = "unbekannt"
        if not isinstance(marker_speed, (int, float)) or not math.isfinite(marker_speed):
            marker_speed = "unbekannt"
        if not isinstance(volume, (int, float)) or not math.isfinite(volume):
            volume = "unbekannt"
        _player_debug_log(
            player_state,
            "Audio-Ereignismarke={} Typ={} Position={}ms Tempo={} Lautstärke={} "
            "Status={} Kodi_pausiert={}; {}".format(
                sequence, event.get("type"), marker_position,
                marker_speed, volume, state.get("status"),
                player_state.get("kodi_paused", False), buffer_snapshot(),
            ),
        )

    if state.get("status") == "paused" and player_state["owned"]:
        # Pause is an end of this live PCM response, not a time-shift point.
        # Mark the transition before closing sockets: EOF callbacks can race
        # the explicit Kodi stop and must not start error recovery.
        player_state["paused_stream_detached"] = True
        player_state["pause_stop_confirmed"] = False
        player_state["pause_stop_expected"] = True
        player_state["pause_stop_requested_at"] = time.monotonic()
        player_state["pause_stop_timeout_logged"] = False
        player_state["pending_audio_recovery"] = None
        player_state["kodi_error_reconnect_requested_at"] = None
        audio.set_playback_enabled(False)
        try:
            stop_result = _stop_owned_player(player_state)
        except Exception as error:
            stop_result = "fehlgeschlagen-{}".format(type(error).__name__)
        if stop_result in ("not_playing", "other_source", "not_owned"):
            player_state["pause_stop_confirmed"] = True
            player_state["pause_stop_expected"] = False
        _player_debug_log(
            player_state,
            "Bestätigte Soloist-Pause: TCP gesperrt, Kodi-Stopp={}; "
            "Fortsetzen öffnet einen neuen Live-Stream.".format(stop_result),
        )
        return

    if player_state.get("paused_stream_detached"):
        player = player_state["player"]
        # A foreign player still follows the existing notification/pause path.
        # An old Soloist player awaiting its stop acknowledgement must not be
        # mistaken for a foreign source or cause a pause command upstream.
        if not (
            state.get("status") in ("playing", "buffering")
            and player.isPlaying()
            and player.getPlayingFile() != player_state.get("playback_url")
        ):
            return

    # Position/volume notifications do not change metadata or transport.
    # Keep diagnostics above, but avoid synchronous Kodi GUI updates for them.
    if (
        player_state["owned"]
        and event.get("type") in ("position_sync", "volume_changed")
        and state.get("status") == previous_status
        and state.get("is_active") == previous_active
    ):
        return

    if (
        state.get("status") in ("playing", "buffering")
        and state.get("is_active")
        and state.get("item")
    ):
        if event.get("type") == "track_changed":
            player_state["last_track_changed_at"] = time.monotonic()
            _player_debug_log(
                player_state,
                "Soloist-Trackwechsel: {} status={} position_ms={} tempo={}.".format(
                    _diagnostic_track_label(state.get("item")),
                    state.get("status"),
                    position.get("position_ms"),
                    position.get("speed"),
                ),
            )
        metadata_event = (
            event
            if event.get("type") in ("playback_state", "track_changed")
            else state
        )
        artist_mbids = _artist_mbids_for_item(musicbrainz_resolver, state.get("item"))
        list_item = kodi_music_item(
            metadata_event,
            audio.playback_url,
            xbmcgui.ListItem,
            artist_mbids_by_uri=artist_mbids,
            diagnostic_logger=player_state.get("debug_log"),
        )
        if list_item is None:
            return
        if player_state["owned"]:
            player_is_playing = player_state["player"].isPlaying()
            applied = _queue_info_tag(player_state, list_item, artist_mbids)
            if event.get("type") == "track_changed":
                _player_debug_log(
                    player_state,
                    "Kodi-InfoTag {}: Track={} {}.".format(
                        "Update gesendet" if applied else "vorgemerkt",
                        _item_identity_key(state.get("item")) or "unbekannt",
                        _diagnostic_track_label(state.get("item")),
                    ),
                )
            if (
                state.get("status") == "playing"
                and player_is_playing
                and player_state.get("kodi_paused", False)
            ):
                player_state["player"].suppress_next("resume")
                player_state["kodi_paused"] = False
                player_state["player"].pause()
        elif not player_state["player"].isPlaying():
            if player_state.get("kodi_error_reconnect_requested_at") is not None:
                player_state["pending_info_tag"] = list_item
                _player_debug_log(
                    player_state,
                    "Kodi-Start nach Playerfehler wartet auf den angeforderten "
                    "frischen Soloist-Status.",
                )
            else:
                _open_soloist_stream(player_state, audio.playback_url, list_item, artist_mbids)
        else:
            _safe_log("Kodi spielt bereits; bestehende Wiedergabe bleibt unberührt")
            if (
                player_state.get("kodi_error_reconnect_requested_at") is not None
                and _playback_attempted(event, state, previous_status, previous_active)
            ):
                _player_debug_log(
                    player_state,
                    "Recovery nach Kodi-Playerfehler wird nicht auf eine "
                    "laufende andere Kodi-Quelle gelegt.",
                )
            elif _playback_attempted(
                event, state, previous_status, previous_active
            ):
                track_key = _item_identity_key(item)
                last_notification_at = player_state.get(
                    "last_blocked_notification_at"
                )
                no_key_recently_notified = (
                    track_key is None
                    and last_notification_at is not None
                    and time.monotonic() - last_notification_at < 10.0
                )
                same_track_already_notified = (
                    track_key is not None
                    and track_key == player_state.get("last_blocked_track_key")
                )
                if not no_key_recently_notified and not same_track_already_notified:
                    pause_queued = bool(
                        websocket is not None and websocket.send_command("pause")
                    )
                    player_state["last_blocked_track_key"] = track_key
                    player_state["last_blocked_notification_at"] = time.monotonic()
                    notification_shown = _notify(
                        addon,
                        32054,
                        xbmcgui.NOTIFICATION_WARNING,
                        display_time=8000,
                        sound=False,
                    )
                    _player_debug_log(
                        player_state,
                        "Soloist-Start bei belegtem Kodi-Player nicht übernommen; "
                        "Pause an Soloist vorgemerkt={}, Meldung {}.".format(
                            str(pause_queued).lower(),
                            "angezeigt" if notification_shown else "deaktiviert",
                        ),
                    )
    elif (
        (state.get("status") == "idle" or state.get("is_active") is False)
        and player_state["owned"]
    ):
        _stop_owned_player(player_state)


def run_service():
    """Prepare private runtime paths, handle Kodi menu requests, and stop cleanly."""
    addon = xbmcaddon.Addon()
    monitor = xbmc.Monitor()

    data_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    if not xbmcvfs.exists(data_path) and not xbmcvfs.mkdirs(data_path):
        _safe_log("Add-on-Profilverzeichnis konnte nicht angelegt werden", level=xbmc.LOGERROR)
        return

    soloist_root = os.path.join(data_path, "soloist")
    process = SoloistProcess(
        os.path.join(soloist_root, "bin", "soloist"),
        os.path.join(soloist_root, "data"),
        os.path.join(soloist_root, "cache"),
        lambda message: _safe_log(message, process.api_key),
    )
    websocket = SoloistWebSocket(
        os.path.join(soloist_root, "data"),
        lambda message: _safe_log(message, process.api_key),
    )
    musicbrainz_resolver = MusicBrainzResolver(
        os.path.join(data_path, "musicbrainz_artist_cache.json"),
        "Kodi-Soloist-Native/0.3.27 (https://github.com/blauesgruen/service.soloist)",
        lambda message: _safe_log(message, level=xbmc.LOGDEBUG),
    )
    audio = ProcessPulseRtpAudio(data_path, lambda message: _safe_log(message, process.api_key))
    window = xbmcgui.Window(WINDOW_ID)
    window.clearProperty(UPDATE_READY_PROPERTY)
    player_state = {
        "player": None,
        "owned": False,
        "av_ready": False,
        "playback_url": audio.playback_url,
        "manual_stop": False,
        "playback": {},
        "pending_command_confirmations": [],
        "last_status": None,
        "last_active": None,
        "pending_info_tag": None,
        "kodi_error_reconnect_requested_at": None,
        "kodi_error_state_confirmed": False,
        "kodi_error_state_request_at": None,
        "kodi_error_state_request_attempts": 0,
        "audio_recovery_attempts": [],
        "zero_pcm_recovery_pending": None,
        "zero_pcm_recovery_nonzero_samples": 0,
        "last_track_changed_at": None,
        "last_position_diagnostic": 0.0,
        "last_audio_flow_diagnostic": 0.0,
        "last_audio_flow_sample": None,
        "kodi_stall_samples": 0,
        "last_blocked_track_key": None,
        "last_blocked_notification_at": None,
        "connection_notice_deadline": None,
        "connection_failure_notified": False,
        "connection_was_ready": False,
        "update_request_id": None,
    }
    player_state["player"] = SoloistKodiPlayer(websocket, player_state)
    player_state["debug_logging_enabled"] = lambda: addon.getSettingBool(
        "audio_diagnostics"
    )
    player_state["debug_log"] = lambda message: _debug_log(
        addon, message, process.api_key
    )
    queue_bridge = SoloistQueueBridge(
        websocket, player_state, player_state["debug_log"],
        lambda: xbmcgui.Dialog().notification(
            addon.getLocalizedString(32000), addon.getLocalizedString(32060),
            xbmcgui.NOTIFICATION_INFO, 4000, False),
        lambda item: _artist_mbids_for_item(musicbrainz_resolver, item),
    )
    player_state["queue_bridge"] = queue_bridge
    _safe_log("Kodi-Service gestartet; Soloist-Autostart wartet kurz.")

    try:
        startup_deadline = time.monotonic() + STARTUP_DELAY_SECONDS
        while time.monotonic() < startup_deadline:
            if monitor.waitForAbort(min(0.25, startup_deadline - time.monotonic())):
                return
        try:
            startup_result = _start_soloist(addon, data_path, process, audio, websocket)
            player_state["playback_url"] = audio.playback_url
        except Exception as error:
            startup_result = "start_failed"
            _safe_log(
                "Automatischer Soloist-Start fehlgeschlagen ({})".format(
                    type(error).__name__
                ),
                load_api_key(data_path),
                xbmc.LOGERROR,
            )
        if startup_result in ("started", "already_running"):
            player_state["connection_notice_deadline"] = (
                time.monotonic() + CONNECTION_NOTICE_TIMEOUT
            )
            _safe_log("Automatischer Soloist-Start: {}".format(startup_result))
        else:
            player_state["connection_notice_deadline"] = None
            player_state["connection_failure_notified"] = False
            _notify(addon, {
                "configuration_missing": 32042,
                "binary_missing": 32043,
                "audio_setup_failed": 32035,
                "install_failed": 32023,
                "start_failed": 32024,
            }.get(startup_result, 32024), xbmcgui.NOTIFICATION_ERROR)
            _safe_log("Automatischer Soloist-Start nicht möglich: {}".format(startup_result))
        while not monitor.waitForAbort(0.25):
            try:
                queue_bridge.poll_request(accept=False)
            except (RuntimeError, ValueError, TypeError, KeyError, IndexError) as error:
                _log_queue_failure(player_state, error, "Anfragefehler")
                queue_bridge.cancel("Anfragefehler", notify=True)
            try:
                audio.check_health()
            except AudioSetupError as error:
                _safe_log("Audioprozess ausgefallen: {}".format(error),
                          process.api_key, xbmc.LOGERROR)
                if player_state.get("owned"):
                    websocket.send_command("pause")
                _handle_command({"action": "stop"}, addon, data_path, process,
                                window, audio, websocket, player_state)
                xbmcgui.Dialog().notification(
                    addon.getLocalizedString(32000), addon.getLocalizedString(32059),
                    xbmcgui.NOTIFICATION_ERROR, 5000, False,
                )
                continue  # The service stays available for a deliberate restart.
            pending_recovery = player_state.get("pending_audio_recovery")
            if (
                isinstance(pending_recovery, dict)
                and time.monotonic() - pending_recovery.get("requested_at", 0.0) >= 12.0
            ):
                player_state["pending_audio_recovery"] = None
                _player_debug_log(
                    player_state,
                    "Kodi hat onAVStarted für die Wiederöffnung innerhalb von 12 s "
                    "nicht gemeldet.",
                )
                xbmcgui.Dialog().notification(
                    "Soloist",
                    "Kodi bestätigt den Streamstart nicht",
                    xbmcgui.NOTIFICATION_ERROR,
                    4000,
                    False,
                )
            exit_code = process.poll_exit()
            if exit_code is not None:
                websocket.stop()
                _stop_owned_player(player_state)
                player_state["playback"] = {}
                player_state["last_status"] = None
                player_state["paused_stream_detached"] = False
                player_state["pause_stop_expected"] = False
                player_state["pending_audio_recovery"] = None
                audio.cleanup()
                player_state["connection_notice_deadline"] = None
                _notify(addon, 32044, xbmcgui.NOTIFICATION_ERROR)
            connected = process.is_running() and websocket.is_connected()
            was_connected = player_state.get("connection_was_ready", False)
            if connected and not was_connected:
                _player_debug_log(
                    player_state, "Soloist-WebSocket-Steuerverbindung hergestellt."
                )
                _notify(addon, 32045)
                player_state["connection_failure_notified"] = False
                player_state["connection_notice_deadline"] = None
            elif was_connected and not connected and process.is_running():
                _player_debug_log(
                    player_state, "Soloist-WebSocket-Steuerverbindung getrennt."
                )
                _notify(addon, 32046, xbmcgui.NOTIFICATION_ERROR)
            player_state["connection_was_ready"] = connected
            deadline = player_state.get("connection_notice_deadline")
            if (
                process.is_running()
                and not connected
                and deadline is not None
                and time.monotonic() >= deadline
                and not player_state.get("connection_failure_notified")
            ):
                _notify(addon, 32047, xbmcgui.NOTIFICATION_ERROR)
                player_state["connection_failure_notified"] = True
            raw_command = window.getProperty(COMMAND_PROPERTY)
            if raw_command:
                window.clearProperty(COMMAND_PROPERTY)
                request_id = None
                api_key = None
                try:
                    command = json.loads(raw_command)
                    if not isinstance(command, dict):
                        raise ValueError("command must be an object")
                    request_id = command.get("request_id")
                    _handle_command(
                        command,
                        addon,
                        data_path,
                        process,
                        window,
                        audio,
                        websocket,
                        player_state,
                    )
                    if player_state.get("update_request_id"):
                        break
                except Exception as error:
                    api_key = load_api_key(data_path)
                    _safe_log(
                        "Kodi-Befehl fehlgeschlagen ({})".format(type(error).__name__),
                        api_key,
                        xbmc.LOGERROR,
                    )
                    _result(window, request_id, "command_failed")
            while True:
                event = websocket.get_event()
                if event is None:
                    break
                try:
                    if event.get("type") == "command_result":
                        command_name = event.get("command")
                        if isinstance(command_name, str):
                            _player_debug_log(
                                player_state,
                                "Soloist-WebSocket hat den Befehl {} angenommen "
                                "und dispatcht; Zustandswechsel ist damit noch "
                                "nicht bestätigt.".format(command_name),
                            )
                            if not queue_bridge.accept_result(command_name):
                                _record_command_acceptance(event, player_state)
                        continue
                    if event.get("type") == "error":
                        error_detail = event.get("message")
                        if isinstance(error_detail, str):
                            error_detail = "".join(
                                char if char.isprintable() else " "
                                for char in error_detail
                            )
                            error_detail = " ".join(error_detail.split())[:180]
                        else:
                            error_detail = ""
                        _player_debug_log(
                            player_state,
                            "Soloist-WebSocket hat eine Fehlerantwort gesendet; "
                            "der Befehl ist nicht bestätigt.{}".format(
                                " Grund={}".format(error_detail)
                                if error_detail
                                else ""
                            ),
                        )
                        continue
                    _handle_playback_event(
                        event,
                        audio,
                        player_state,
                        addon,
                        musicbrainz_resolver,
                        websocket,
                    )
                    _confirm_playback_command(event, player_state)
                except Exception as error:
                    _safe_log(
                        "Soloist-Ereignis ignoriert ({})".format(type(error).__name__),
                        level=xbmc.LOGERROR,
                    )
            try:
                queue_bridge.poll_request()
            except (RuntimeError, ValueError, TypeError, KeyError, IndexError) as error:
                _log_queue_failure(player_state, error, "Prüfungsfehler")
                queue_bridge.cancel("Queue-Prüfung fehlgeschlagen", notify=True)
            _expire_playback_command_confirmations(player_state)
            try:
                if not queue_bridge.busy():
                    _resume_detached_stream(audio, player_state, musicbrainz_resolver)
                    _reattach_after_kodi_error(
                        audio, player_state, websocket, musicbrainz_resolver
                    )
            except Exception as error:
                player_state["kodi_error_reconnect_requested_at"] = None
                player_state["owned"] = False
                player_state["av_ready"] = False
                _safe_log(
                    "Kodi-Wiederanbindung nach Playerfehler fehlgeschlagen ({})".format(
                        type(error).__name__
                    ),
                    level=xbmc.LOGERROR,
                )
            while not queue_bridge.busy():
                result = musicbrainz_resolver.get_result()
                if result is None:
                    break
                try:
                    _apply_musicbrainz_result(
                        result,
                        musicbrainz_resolver,
                        audio,
                        player_state,
                    )
                except Exception as error:
                    _safe_log(
                        "MusicBrainz-Ergebnis ignoriert ({})".format(
                            type(error).__name__
                        ),
                        level=xbmc.LOGERROR,
                    )
            try:
                queue_bridge.sync()
            except Exception as error:
                queue_bridge.disable("Kodi-Playlistfehler {}".format(type(error).__name__))
            try:
                _flush_pending_info_tag(player_state)
                _log_audio_flow_diagnostic(audio, player_state, websocket)
            except Exception as error:
                _player_debug_log(
                    player_state,
                    "Audioflussprobe übersprungen ({}).".format(
                        type(error).__name__
                    ),
                )
    finally:
        queue_bridge.close()
        key = player_state.pop("stream_request_key", None)
        if key:
            window.clearProperty(key)
            window.clearProperty(key + ".ready")
        shutdown_api_key = process.api_key
        update_request_id = player_state.get("update_request_id")
        _safe_log("Kodi-Shutdown: PCM-Verbindung wird vor dem Playerstopp getrennt.", shutdown_api_key)
        tcp_clients_closed = _shutdown_step(
            "Kodi-PCM-Verbindungen schließen",
            audio.close_tcp_clients,
            shutdown_api_key,
        )
        player_stopped = _shutdown_step(
            "Kodi-Player stoppen",
            lambda: (
                _stop_owned_player_and_wait(player_state)
                if update_request_id
                else _stop_owned_player(player_state)
            ),
            shutdown_api_key,
        )
        soloist_stopped = _shutdown_step(
            "Soloist-Prozess beenden",
            lambda: process.stop(timeout=5.0 if update_request_id else 0.5),
            shutdown_api_key,
        )
        audio_cleaned = _shutdown_step("Audio-Ressourcen bereinigen", audio.cleanup, shutdown_api_key)
        websocket_stopped = _shutdown_step(
            "WebSocket beenden",
            lambda: websocket.stop(timeout=3.0 if update_request_id else 0.25),
            shutdown_api_key,
        )
        resolver_closed = _shutdown_step(
            "MusicBrainz-Resolver schließen",
            musicbrainz_resolver.close,
            shutdown_api_key,
        )
        if update_request_id:
            if all((tcp_clients_closed, player_stopped, soloist_stopped, audio_cleaned, websocket_stopped, resolver_closed)):
                window.setProperty(UPDATE_READY_PROPERTY, update_request_id)
                _safe_log("Kodi-Updatevorbereitung abgeschlossen; Wiedergabe beendet.", shutdown_api_key)
            else:
                _safe_log(
                    "Kodi-Updatevorbereitung fehlgeschlagen; Update nicht starten.",
                    shutdown_api_key,
                    xbmc.LOGERROR,
                )
        _safe_log("Kodi-Shutdown erkannt")


if __name__ == "__main__":
    run_service()
