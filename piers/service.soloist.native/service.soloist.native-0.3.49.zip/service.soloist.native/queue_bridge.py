"""Bounded native Kodi neighbours for Soloist's externally managed live stream."""

import hashlib
import json
import queue
import re
import threading
import time
import uuid

import xbmc
import xbmcgui

from audio import kodi_music_item

PREFIX = "service.soloist.native.queue."
REQUEST_PROPERTY = PREFIX + "request"
RESOLVE_TIMEOUT = 10.0
COMMAND_TIMEOUT = 7.0
MAX_PAYLOAD_BYTES = 262144
TOKEN_PATTERN = re.compile(r"[0-9a-f]{32}")
URI_PATTERN = re.compile(r"spotify:(?:track|episode):[A-Za-z0-9]{22}")


def item_uri(item):
    uri = item.get("uri") if isinstance(item, dict) else None
    return uri if isinstance(uri, str) and URI_PATTERN.fullmatch(uri) else None


def neighbor(event, direction, current_uri):
    """Reject ambiguous URI occurrences: playback events do not expose queue UIDs."""
    if not isinstance(event, dict):
        return None
    entries = event.get("previous" if direction == "previous" else "upcoming")
    if not isinstance(entries, list) or not entries:
        return None
    entry = entries[0]
    if not isinstance(entry, dict) or not item_uri(entry.get("item")):
        return None
    uri = item_uri(entry["item"])
    decorations = entry["item"].get("decorations")
    identity = decorations.get("identity") if isinstance(decorations, dict) else None
    title = identity.get("name") if isinstance(identity, dict) else None
    if not isinstance(title, str) or not title.strip():
        return None
    uid = entry.get("uid") or uri
    if not isinstance(uid, str) or len(uid) > 1024 or uri == current_uri:
        return None
    all_entries = []
    for field in ("previous", "upcoming"):
        values = event.get(field)
        if not isinstance(values, list) or len(values) > 10:
            return None
        all_entries.extend(values)
    if sum(isinstance(value, dict) and item_uri(value.get("item")) == uri
           for value in all_entries) != 1:
        return None
    if sum(isinstance(value, dict) and (value.get("uid") or item_uri(value.get("item"))) == uid
           for value in all_entries) != 1:
        return None
    return {"uid": uid, "uri": uri, "item": entry["item"]}


def result_key(operation):
    return PREFIX + operation + ".result"


class SoloistQueueBridge:
    """Own at most two neighbours; never clear a playlist or control audio output."""

    def __init__(self, websocket, player_state, logger, notify_failure, artist_mbids):
        self.websocket = websocket
        self.state = player_state
        self.log = logger
        self.notify_failure = notify_failure
        self.artist_mbids = artist_mbids
        self.window = xbmcgui.Window(10000)
        self.session = uuid.uuid4().hex
        self.entries = {}
        self.paths = []
        self.current_path = None
        self.queue = None
        self.queue_uri = None
        self.dirty = False
        self.pending = None
        self.disabled = False
        self.last_poll = 0.0
        self.requested_at = None
        self.mutation = None
        self.desired = None
        self.generation = websocket.control_generation()
        self.callbacks = queue.Queue(maxsize=16)
        self.callback_overflow = threading.Event()
        self.queue_attempts = 0
        self.observed_uri = item_uri((player_state.get("playback") or {}).get("item"))

    def callback(self, name, detail=None):
        """Kodi callback threads never mutate bridge state or wait for its owner."""
        try:
            self.callbacks.put_nowait((name, detail))
        except queue.Full:
            self.callback_overflow.set()

    def _drain_callbacks(self):
        if self.callback_overflow.is_set():
            self.callback_overflow.clear()
            self.cancel("Kodi-Callbackverlust")
        while True:
            try:
                name, detail = self.callbacks.get_nowait()
            except queue.Empty:
                return
            if name == "av_started":
                self.av_started(detail)
            elif name == "ended":
                if self.expected_end():
                    self.log("Native Queue: altes Streamende während bestätigter Übergabe.")
                else:
                    self.cancel("Kodi-Stream beendet")
                    detail()
            else:
                self.cancel(detail)

    def busy(self):
        return bool(self.pending or self.window.getProperty(REQUEST_PROPERTY))

    def _rpc(self, method, **params):
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": method, "params": params,
        })))
        if not isinstance(response, dict) or "error" in response or "result" not in response:
            raise RuntimeError("Kodi queue request rejected")
        return response["result"]

    def _owned_source(self):
        player = self.state["player"]
        return (self.state.get("owned") and self.state.get("av_ready")
                and player.isPlaying()
                and player.getPlayingFile() == self.state.get("playback_url"))

    def _context(self):
        """Read only the active audio playlist; fail closed on shuffle/repeat/mixed items."""
        if self.window.getProperty(REQUEST_PROPERTY):
            return None
        if not self._owned_source():
            return None
        players = self._rpc("Player.GetActivePlayers")
        active = [entry for entry in players if entry.get("type") == "audio"]
        if len(active) != 1:
            return None
        properties = self._rpc("Player.GetProperties", playerid=active[0]["playerid"],
                               properties=["playlistid", "position", "shuffled", "repeat"])
        if (properties.get("playlistid") != 0 or properties.get("shuffled") is not False
                or properties.get("repeat") != "off"):
            return None
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        if not 1 <= playlist.size() <= 3:
            return None
        paths = [playlist[index].getPath() for index in range(playlist.size())]
        position = properties.get("position")
        if (isinstance(position, bool) or not isinstance(position, int)
                or not 0 <= position < len(paths)):
            return None
        expected = self.paths or [self.state.get("metadata_item_path")]
        if paths != expected or paths[position] != self.state.get("metadata_item_path"):
            return None
        return playlist, paths, position

    def _read_request(self):
        raw = self.window.getProperty(REQUEST_PROPERTY)
        if not raw:
            return None
        try:
            if len(raw) > 512:
                raise ValueError("oversized navigation request")
            request = json.loads(raw)
            if (not isinstance(request, dict)
                    or set(request) != {"operation", "entry", "session"}
                    or any(not isinstance(request[field], str)
                           or not TOKEN_PATTERN.fullmatch(request[field]) for field in request)):
                raise ValueError("invalid navigation request")
            return request
        except (ValueError, TypeError):
            self.window.clearProperty(REQUEST_PROPERTY)
            return None

    def _reply(self, request, payload):
        if self._read_request() == request:
            self.window.setProperty(result_key(request["operation"]), json.dumps(payload))

    def _revoke_entries(self):
        for token, entry in list(self.entries.items()):
            if entry["path"] != self.current_path:
                self.window.clearProperty(PREFIX + token)
                del self.entries[token]

    def cancel(self, reason, notify=False):
        pending = self.pending
        self.pending = None
        if pending:
            self._reply(pending["request"], {"ok": False})
            self.log("Native Queue: Übergabe abgebrochen ({}); kein Skip wiederholt.".format(reason))
            self.disabled = True
            if notify:
                self.notify_failure()
        self.queue = None
        self.queue_uri = None
        self.dirty = True
        self.desired = None
        self._revoke_entries()

    def close(self):
        self.cancel("Dienst beendet")
        for token in self.entries:
            self.window.clearProperty(PREFIX + token)
        self.entries.clear()
        # Do not mutate Kodi's playlist during service teardown. Tokens are revoked;
        # another source can already own the playlist at this point.

    def disable(self, reason):
        self.disabled = True
        self.cancel(reason)
        self.mutation = None
        self.paths = []
        self.log("Native Queue deaktiviert: {}. Audioweg bleibt unverändert.".format(reason))

    def poll_request(self, accept=True):
        """Only Window properties and WS commands while Kodi waits for its resolver."""
        self._drain_callbacks()
        request = self._read_request()
        generation = self.websocket.control_generation()
        if generation != self.generation:
            self.generation = generation
            self.cancel("Verbindungswechsel oder Ereignisverlust")
        if self.pending and not self.websocket.is_connected():
            self.cancel("Steuerverbindung getrennt", notify=True)
        if self.pending:
            if self.pending["phase"] == "opening":
                if request and request != self.pending["request"]:
                    self._reply(request, {"ok": False})
                if time.monotonic() >= self.pending["deadline"]:
                    self.cancel("Kodi-AV-Start nicht bestätigt", notify=True)
                    # EOF can have belonged to the old reader. If the new player
                    # never starts, retain the existing bounded fresh-state path.
                    self.state["kodi_error_reconnect_requested_at"] = time.monotonic()
                    self.state["kodi_error_state_confirmed"] = False
                    self.state["kodi_error_state_request_at"] = None
                    self.state["kodi_error_state_request_attempts"] = 0
                return
            if request != self.pending["request"]:
                self.cancel("Resolver beendet")
                return
            if time.monotonic() >= self.pending["deadline"]:
                self.cancel("Zeitlimit", notify=True)
            return
        if request is None or not accept:
            return
        entry = self.entries.get(request["entry"])
        if (self.disabled or self.mutation or not entry or request["session"] != self.session
                or not self.state.get("owned") or not self.state.get("av_ready")
                or not self.websocket.is_connected()
                or (self.state.get("playback") or {}).get("status") not in ("playing", "buffering")
                or (self.state.get("playback") or {}).get("is_active") is not True
                or item_uri((self.state.get("playback") or {}).get("item")) != entry["current"]):
            self._reply(request, {"ok": False})
            return
        self.pending = {
            "request": request, "entry": entry, "phase": "checking",
            "deadline": time.monotonic() + COMMAND_TIMEOUT,
            "state_seen": False, "queue_seen": None,
            "before_position": (self.state.get("playback") or {}).get("position") or {},
        }
        if not (self.websocket.send_command("get_state")
                and self.websocket.send_command("get_queue", limit=10)):
            self.cancel("Steuerverbindung fehlt", notify=True)
        else:
            self.log("Native Queue: Nachbar wird vor dem relativen Skip erneut geprüft.")

    def _send_if_checked(self):
        pending = self.pending
        if not pending or pending["phase"] != "checking" or not pending["state_seen"]:
            return
        queue = pending["queue_seen"]
        if queue is None:
            return
        entry = pending["entry"]
        current = item_uri((self.state.get("playback") or {}).get("item"))
        if (self._read_request() != pending["request"]
                or not self.state.get("owned") or not self.state.get("av_ready")
                or not self.websocket.is_connected()
                or self.websocket.control_generation() != self.generation):
            self.cancel("Resolver oder Quelle inzwischen beendet")
            return
        if entry["direction"] == "current":
            if current == entry["current"]:
                self._resolve_target()
            else:
                self.cancel("Aktueller Titel inzwischen geändert", notify=True)
            return
        target = neighbor(queue, entry["direction"], current)
        if (current != entry["current"] or not target
                or (target["uid"], target["uri"]) != (entry["uid"], entry["uri"])):
            self.cancel("Queue inzwischen geändert", notify=True)
            return
        command = "skip_prev" if entry["direction"] == "previous" else "skip_next"
        actions = (self.state.get("playback") or {}).get("available_actions")
        if isinstance(actions, dict) and actions.get(command) is False:
            self.cancel("Soloist erlaubt diese Aktion nicht", notify=True)
            return
        if not self.websocket.send_command(command):
            self.cancel("Skip nicht vorgemerkt", notify=True)
            return
        pending["phase"] = "waiting"
        self.log("Native Queue: {} einmalig vorgemerkt; warte auf tatsächlichen Titel.".format(command))

    def handle_event(self, event):
        """Called after merging playback state, before normal Kodi metadata calls."""
        event_type = event.get("type")
        playback = self.state.get("playback") or {}
        current = item_uri(playback.get("item"))
        if event_type == "queue_changed":
            if self.pending and self.pending["phase"] == "checking":
                self.pending["queue_seen"] = event
                self._send_if_checked()
            elif not self.pending:
                self.queue = event
                self.queue_uri = current
                self.requested_at = None
                self.queue_attempts = 0
                self.dirty = True
                self.desired = None
            return True
        if event_type in ("track_changed", "playback_state") and current != self.observed_uri:
            self.observed_uri = current
            self.queue = None
            self.queue_uri = None
            self.requested_at = None
            self.queue_attempts = 0
            self.dirty = True
            self.desired = None
        if (playback.get("status") not in ("playing", "buffering")
                or playback.get("is_active") is not True
                or (event_type == "auth_state" and not event.get("logged_in"))):
            if self.pending:
                self.cancel("Soloist nicht mehr aktiv")
            return False  # normal pause/audio-gate processing must still run
        if not self.pending:
            return bool(self.window.getProperty(REQUEST_PROPERTY))
        pending = self.pending
        if pending["phase"] == "checking":
            if event_type == "playback_state":
                pending["state_seen"] = True
                self._send_if_checked()
        elif pending["phase"] == "waiting":
            if event_type in ("track_changed", "playback_state"):
                if current == pending["entry"]["uri"]:
                    self._resolve_target()
                elif current != pending["entry"]["current"]:
                    self.cancel("Anderer Titel gestartet", notify=True)
            elif (event_type == "position_sync"
                  and pending["entry"]["direction"] == "previous"
                  and current == pending["entry"]["current"]):
                baseline = pending["before_position"]
                before = baseline.get("position_ms") if isinstance(baseline, dict) else None
                after = (playback.get("position") or {}).get("position_ms")
                if (isinstance(before, (int, float)) and not isinstance(before, bool)
                        and isinstance(after, (int, float)) and not isinstance(after, bool)
                        and before >= 3000 and 0 <= after <= 1500):
                    # Spotify Previous can restart the current track. Resolve its
                    # actual metadata, never label the restart as the neighbour.
                    self._resolve_target()
        return True

    def _resolve_target(self):
        pending = self.pending
        playback = self.state["playback"]
        mbids = self.artist_mbids(playback["item"])
        payload = {"ok": True, "url": self.state["playback_url"],
                   "item": playback["item"], "artist_mbids": mbids}
        if len(json.dumps(payload).encode("utf-8")) > MAX_PAYLOAD_BYTES:
            self.cancel("Titelmetadaten zu groß", notify=True)
            return
        self.current_path = pending["entry"]["path"]
        self.state["metadata_item_path"] = self.current_path
        self.state["av_ready"] = False
        self.state["applied_info_tag_revision"] = None
        self.state["pending_info_tag"] = None
        self.state["pending_audio_recovery"] = None
        pending["revision"] = hashlib.sha256(json.dumps(
            [playback["item"], mbids], sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")).hexdigest()
        pending["resolved_uri"] = item_uri(playback["item"])
        self.state["info_tag_revision"] = pending["revision"]
        pending["phase"] = "opening"
        pending["deadline"] = time.monotonic() + RESOLVE_TIMEOUT
        self._reply(pending["request"], payload)
        self.log("Native Queue: bestätigte Titelmetadaten an den Kodi-Resolver übergeben.")

    def av_started(self, source):
        if not self.pending:
            return
        if source != self.state.get("playback_url") or self.pending["phase"] != "opening":
            self.cancel("Andere Quelle gestartet")
            return
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        position = playlist.getposition()
        if not 0 <= position < playlist.size() or playlist[position].getPath() != self.current_path:
            self.cancel("Kodi-Eintrag passt nicht zur Übergabe")
            return
        self.state["applied_info_tag_revision"] = self.pending["revision"]
        playback = self.state.get("playback") or {}
        if item_uri(playback.get("item")) != self.pending["resolved_uri"]:
            mbids = self.artist_mbids(playback.get("item"))
            self.state["pending_info_tag"] = kodi_music_item(
                playback, source, xbmcgui.ListItem, artist_mbids_by_uri=mbids)
            self.state["info_tag_revision"] = hashlib.sha256(json.dumps(
                [playback.get("item"), mbids], sort_keys=True, separators=(",", ":"),
            ).encode("utf-8")).hexdigest()
            self.state["info_tag_attempts"] = 0
            self.state["info_tag_retry_at"] = 0
        self.pending = None
        self.queue = None
        self.queue_uri = None
        self.requested_at = None
        self.queue_attempts = 0
        self.dirty = True
        self.desired = None
        self.log("Native Queue: neuer Kodi-Leser bestätigt; Audioformat unverändert.")

    def expected_end(self):
        # Only the old-reader EOF during the acknowledged new-item open is ours.
        # Stopped is deliberately not covered: an explicit user stop must cancel.
        pending = self.pending
        return bool(pending and pending["phase"] == "opening")

    def _remove(self, index, expected_path):
        context = self._context()
        if context is None:
            raise RuntimeError("Playlist ownership changed before removal")
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        if (not self._owned_source() or index >= playlist.size()
                or playlist[index].getPath() != expected_path):
            raise RuntimeError("Playlist ownership changed")
        self._rpc("Playlist.Remove", playlistid=0, position=index)
        after = list(self.paths)
        after.pop(index)
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0}

    def _tag_slot(self, index, path, item):
        slot = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)[index]
        slot.setLabel((item.get("decorations", {}).get("identity") or {}).get("name", ""))
        slot.getMusicInfoTag().setMusicBrainzArtistID([])
        slot.setArt({"thumb": "", "icon": ""})
        kodi_music_item({"item": item}, path, lambda **kwargs: slot,
                        artist_mbids_by_uri=self.artist_mbids(item))
        if "?queue=" in path:
            slot.setProperty("ForceResolvePlugin", "true")
        slot.setProperty("IsPlayable", "true")
        slot.setProperty("inputstream", "inputstream.ffmpegdirect")
        slot.setProperty("inputstream-player", "videodefaultplayer")

    def _new_entry(self, direction, target, current_uri):
        token = uuid.uuid4().hex
        path = "plugin://service.soloist.native/?queue={}&session={}".format(token, self.session)
        entry = dict(target, direction=direction, current=current_uri, path=path)
        self.entries[token] = entry
        return path

    def _insert(self, index, path, target):
        if self._context() is None:
            raise RuntimeError("Playlist ownership changed before insertion")
        self._rpc("Playlist.Insert", playlistid=0, position=index, item={"file": path})
        after = list(self.paths)
        after.insert(index, path)
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0,
                         "inserted": (index, path, target)}

    def _settle_mutation(self):
        mutation = self.mutation
        if not mutation:
            return True
        if not self._owned_source():
            return False
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        paths = [playlist[index].getPath() for index in range(playlist.size())]
        if paths == mutation["after"]:
            self.paths = paths
            self.mutation = None
            inserted = mutation.get("inserted")
            if inserted:
                index, path, target = inserted
                self._tag_slot(index, path, target["item"])
                token = next((key for key, entry in self.entries.items()
                              if entry["path"] == path), None)
                if token:
                    self.window.setProperty(PREFIX + token, self.session)
            return True
        if paths != mutation["before"] or time.monotonic() >= mutation["deadline"]:
            self.mutation = None
            self.disabled = True
            self.cancel("Playlist-Änderung nicht bestätigt")
            # No further writes: the main thread could still execute a late ACK.
            self.paths = []
        return False

    def _make_desired(self, current):
        self._revoke_entries()
        self.desired = [(self.current_path, None)]
        if self.disabled or self.queue is None or self.queue_uri != current:
            return
        previous = neighbor(self.queue, "previous", current)
        upcoming = neighbor(self.queue, "next", current)
        actions = (self.state.get("playback") or {}).get("available_actions")
        if isinstance(actions, dict):
            if actions.get("skip_prev") is False:
                previous = None
            if actions.get("skip_next") is False:
                upcoming = None
        if previous:
            self.desired.insert(0, (self._new_entry("previous", previous, current), previous))
        if upcoming:
            self.desired.append((self._new_entry("next", upcoming, current), upcoming))

    def sync(self):
        """Mutate only a verified own playlist, never while a resolver is waiting."""
        if self.pending or self.window.getProperty(REQUEST_PROPERTY):
            return
        now = time.monotonic()
        if now - self.last_poll < 0.5:
            return
        self.last_poll = now
        if not self.websocket.is_connected() or not self.state.get("owned"):
            self.cancel("Verbindung oder Playerbesitz beendet")
            return
        if not self.state.get("av_ready"):
            return
        path = self.state.get("metadata_item_path")
        if path != self.current_path:
            # A fresh one-shot open (including pause/resume) owns a new session.
            if path in self.paths:
                return
            self._revoke_entries()
            self.session = uuid.uuid4().hex
            self.paths = []
            self.current_path = path
            self.disabled = False
            self.queue = None
            self.queue_uri = None
            self.requested_at = None
            self.queue_attempts = 0
            self.mutation = None
            self.desired = None
            self.dirty = True
        if not self._settle_mutation():
            return
        context = self._context()
        if context is None:
            if self.entries:
                self.cancel("Playlist verändert oder Shuffle/Repeat aktiv")
            return
        playlist, paths, position = context
        if not self.paths:
            self.paths = paths
        current = item_uri((self.state.get("playback") or {}).get("item"))
        if not current:
            return
        if not self.disabled and (self.queue is None or self.queue_uri != current):
            if (self.queue_attempts < 3
                    and (self.requested_at is None or now - self.requested_at >= 5.0)):
                if self.websocket.send_command("get_queue", limit=10):
                    self.requested_at = now
                    self.queue_attempts += 1
            # Revoke stale neighbours immediately, keeping the current slot alive.
            if self.entries:
                self.dirty = True
        if not self.dirty:
            return
        if self.desired is None:
            self._make_desired(current)
        desired_paths = [path for path, _ in self.desired]
        for index in range(len(self.paths) - 1, -1, -1):
            if self.paths[index] not in desired_paths and index != position:
                self._remove(index, self.paths[index])
                return
        for index, (path, target) in enumerate(self.desired):
            if path not in self.paths:
                self._insert(index, path, target)
                return
        self._tag_slot(position, self.current_path, self.state["playback"]["item"])
        for token, entry in self.entries.items():
            if entry["path"] == self.current_path:
                entry.update(direction="current", current=current, uri=current)
                self.window.setProperty(PREFIX + token, self.session)
        self.dirty = False
        self.log("Native Queue: {} echte Nachbarn; laufender Leser bleibt erhalten.".format(
            len(self.paths) - 1))
