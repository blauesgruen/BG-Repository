"""Bounded native Kodi neighbours for Soloist's externally managed live stream."""

import hashlib
import json
import queue
import re
import threading
import time
import uuid
from collections import deque
from urllib.parse import parse_qs, urlsplit

import xbmc
import xbmcgui

from audio import estimated_position_ms, kodi_music_item

PREFIX = "service.soloist.native.queue."
REQUEST_PROPERTY = PREFIX + "request"
RESOLVE_TIMEOUT = 10.0
COMMAND_TIMEOUT = 7.0
MAX_PAYLOAD_BYTES = 262144
TOKEN_PATTERN = re.compile(r"[0-9a-f]{32}")
URI_PATTERN = re.compile(r"spotify:(?:track|episode):[A-Za-z0-9]{22}")


def item_uri(item):
    uri = item.get("uri") if isinstance(item, dict) else None
    return uri if isinstance(uri, str) and URI_PATTERN.fullmatch(uri) else None


def item_title(item):
    decorations = item.get("decorations") if isinstance(item, dict) else None
    identity = decorations.get("identity") if isinstance(decorations, dict) else None
    title = identity.get("name") if isinstance(identity, dict) else None
    return " ".join(title.split())[:512] if isinstance(title, str) else ""


def neighbor(event, direction, current_uri):
    """Reject ambiguous URI occurrences: playback events do not expose queue UIDs."""
    if not isinstance(event, dict):
        return None
    entries = event.get("previous" if direction == "previous" else "upcoming")
    if not isinstance(entries, list) or not entries:
        return None
    entry = entries[0]
    if not isinstance(entry, dict) or not item_uri(entry.get("item")):
        return None
    uri = item_uri(entry["item"])
    decorations = entry["item"].get("decorations")
    identity = decorations.get("identity") if isinstance(decorations, dict) else None
    title = identity.get("name") if isinstance(identity, dict) else None
    if not isinstance(title, str) or not title.strip():
        return None
    uid = entry.get("uid") or uri
    if not isinstance(uid, str) or len(uid) > 1024 or uri == current_uri:
        return None
    all_entries = []
    for field in ("previous", "upcoming"):
        values = event.get(field)
        if not isinstance(values, list) or len(values) > 10:
            return None
        all_entries.extend(values)
    if sum(isinstance(value, dict) and item_uri(value.get("item")) == uri
           for value in all_entries) != 1:
        return None
    if sum(isinstance(value, dict) and (value.get("uid") or item_uri(value.get("item"))) == uid
           for value in all_entries) != 1:
        return None
    return {"uid": uid, "uri": uri, "item": entry["item"]}


def result_key(operation):
    return PREFIX + operation + ".result"


def registry_data(raw):
    """A slot URL is stable; each published target has an immutable revision."""
    if not raw or len(raw) > 512:
        raise ValueError("Missing slot grant")
    value = json.loads(raw)
    if (not isinstance(value, dict) or set(value) != {"session", "revision"}
            or not isinstance(value["session"], str)
            or not TOKEN_PATTERN.fullmatch(value["session"])
            or isinstance(value["revision"], bool) or not isinstance(value["revision"], int)
            or not 1 <= value["revision"] <= 2147483647):
        raise ValueError("Invalid slot grant")
    return value


class SoloistQueueBridge:
    """Own at most two neighbours; never clear a playlist or control audio output."""

    def __init__(self, websocket, player_state, logger, notify_failure, artist_mbids):
        self.websocket = websocket
        self.state = player_state
        self.log = logger
        self.notify_failure = notify_failure
        self.artist_mbids = artist_mbids
        self.window = xbmcgui.Window(10000)
        self.session = uuid.uuid4().hex
        self.entries = {}
        self.paths = []
        self.current_path = None
        self.queue = None
        self.queue_uri = None
        self.dirty = False
        self.pending = None
        self.disabled = False
        self.last_poll = 0.0
        self.requested_at = None
        self.mutation = None
        self.generation = websocket.control_generation()
        self.callbacks = queue.Queue(maxsize=16)
        self.callback_overflow = threading.Event()
        self.queue_attempts = 0
        self.observed_uri = item_uri((player_state.get("playback") or {}).get("item"))
        self.revision = 0
        self.finished_operations = deque(maxlen=16)
        self.native_commands = deque(maxlen=16)

    def accept_result(self, command):
        """Native skips have their own target/reset confirmation, not a generic track-change timeout."""
        now = time.monotonic()
        while self.native_commands and now - self.native_commands[0][1] > COMMAND_TIMEOUT + 2:
            self.native_commands.popleft()
        for index, (name, _) in enumerate(self.native_commands):
            if name == command:
                del self.native_commands[index]
                return True
        return False

    def callback(self, name, detail=None):
        """Kodi callback threads never mutate bridge state or wait for its owner."""
        try:
            self.callbacks.put_nowait((name, detail))
        except queue.Full:
            self.callback_overflow.set()

    def _drain_callbacks(self):
        if self.callback_overflow.is_set():
            self.callback_overflow.clear()
            self.cancel("Kodi-Callbackverlust")
        while True:
            try:
                name, detail = self.callbacks.get_nowait()
            except queue.Empty:
                return
            if name == "av_started":
                self.av_started(detail)
            elif name == "ended":
                if self.expected_end():
                    self.log("Native Queue: altes Streamende während bestätigter Übergabe.")
                else:
                    self.cancel("Kodi-Stream beendet")
                    detail()
            else:
                self.cancel(detail)

    def busy(self):
        return bool(self.pending or self.window.getProperty(REQUEST_PROPERTY))

    def _rpc(self, method, **params):
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": method, "params": params,
        })))
        if not isinstance(response, dict) or "error" in response or "result" not in response:
            raise RuntimeError("Kodi queue request rejected")
        return response["result"]

    def _owned_source(self):
        player = self.state["player"]
        return (self.state.get("owned") and self.state.get("av_ready")
                and player.isPlaying()
                and player.getPlayingFile() == self.state.get("playback_url"))

    def _context(self):
        """Read only the active audio playlist; fail closed on shuffle/repeat/mixed items."""
        if self.window.getProperty(REQUEST_PROPERTY):
            return None
        if not self._owned_source():
            return None
        players = self._rpc("Player.GetActivePlayers")
        active = [entry for entry in players if entry.get("type") == "audio"]
        if len(active) != 1:
            return None
        properties = self._rpc("Player.GetProperties", playerid=active[0]["playerid"],
                               properties=["playlistid", "position", "shuffled", "repeat"])
        if (properties.get("playlistid") != 0 or properties.get("shuffled") is not False
                or properties.get("repeat") != "off"):
            return None
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        if not 1 <= playlist.size() <= 3:
            return None
        paths = [playlist[index].getPath() for index in range(playlist.size())]
        position = properties.get("position")
        if (isinstance(position, bool) or not isinstance(position, int)
                or not 0 <= position < len(paths)):
            return None
        expected = self.paths or [self.state.get("metadata_item_path")]
        if paths != expected or paths[position] != self.state.get("metadata_item_path"):
            return None
        return playlist, paths, position

    def _read_request(self):
        raw = self.window.getProperty(REQUEST_PROPERTY)
        if not raw:
            return None
        try:
            if len(raw) > 512:
                raise ValueError("oversized navigation request")
            request = json.loads(raw)
            if (not isinstance(request, dict)
                    or set(request) != {"operation", "entry", "session", "revision"}
                    or any(not isinstance(request[field], str)
                           or not TOKEN_PATTERN.fullmatch(request[field])
                           for field in ("operation", "entry", "session"))
                    or isinstance(request["revision"], bool)
                    or not isinstance(request["revision"], int)
                    or not 1 <= request["revision"] <= 2147483647):
                raise ValueError("invalid navigation request")
            return request
        except (ValueError, TypeError):
            self.window.clearProperty(REQUEST_PROPERTY)
            return None

    def _reply(self, request, payload):
        if self._read_request() == request:
            self.window.setProperty(result_key(request["operation"]), json.dumps(payload))
            if request["operation"] not in self.finished_operations:
                self.finished_operations.append(request["operation"])

    def _revoke_entries(self):
        for token, entry in list(self.entries.items()):
            if entry["path"] != self.current_path:
                self.window.clearProperty(PREFIX + token)
                del self.entries[token]

    def cancel(self, reason, notify=False):
        pending = self.pending
        self.pending = None
        if pending:
            self._reply(pending["request"], {"ok": False})
            self.log("Native Queue: Übergabe abgebrochen ({}); kein Skip wiederholt.".format(reason))
            if notify:
                self.notify_failure()
        self.queue = None
        self.queue_uri = None
        self.dirty = True

    def close(self):
        self.cancel("Dienst beendet")
        self.native_commands.clear()
        for token in self.entries:
            self.window.clearProperty(PREFIX + token)
        self.entries.clear()
        # Do not mutate Kodi's playlist during service teardown. Tokens are revoked;
        # another source can already own the playlist at this point.

    def disable(self, reason):
        self.disabled = True
        self.cancel(reason)
        self.mutation = None
        self.paths = []
        self._revoke_entries()
        self.log("Native Queue deaktiviert: {}. Audioweg bleibt unverändert.".format(reason))

    def _navigation_failed(self, reason):
        playback = self.state.get("playback") or {}
        if (self.pending and self._read_request() == self.pending["request"]
                and self.state.get("owned") and self.websocket.is_connected()
                and playback.get("status") in ("playing", "buffering")
                and playback.get("is_active") is True and item_uri(playback.get("item"))):
            # A rejected relative command must not turn valid live media into an
            # unplayable playlist item. Return only the actual current track;
            # report the action as unconfirmed and never send another skip.
            self.log("Native Queue: {}. Aktueller Titel bleibt erhalten; kein weiterer Skip.".format(reason))
            self.notify_failure()
            self.pending["passthrough"] = True
            self._resolve_target()
        else:
            self.cancel(reason, notify=True)

    def poll_request(self, accept=True):
        """Only Window properties and WS commands while Kodi waits for its resolver."""
        self._drain_callbacks()
        request = self._read_request()
        generation = self.websocket.control_generation()
        if generation != self.generation:
            self.generation = generation
            self.native_commands.clear()
            self.cancel("Verbindungswechsel oder Ereignisverlust")
            if request:
                self._reply(request, {"ok": False})
                return
        if self.pending and not self.websocket.is_connected():
            self.cancel("Steuerverbindung getrennt", notify=True)
        if self.pending:
            if self.pending["phase"] == "opening":
                if request and request != self.pending["request"]:
                    entry = self.entries.get(request["entry"])
                    if entry and request["session"] == self.session:
                        self.pending = {"request": request, "entry": dict(entry),
                                        "phase": "checking", "passthrough": True}
                        self._navigation_failed("Vorige Übergabe wird noch abgeschlossen")
                    else:
                        self._reply(request, {"ok": False})
                if self.pending and time.monotonic() >= self.pending["deadline"]:
                    self.cancel("Kodi-AV-Start nicht bestätigt", notify=True)
                    self.state["kodi_error_reconnect_requested_at"] = time.monotonic()
                    self.state["kodi_error_state_confirmed"] = False
                    self.state["kodi_error_state_request_at"] = None
                    self.state["kodi_error_state_request_attempts"] = 0
                return
            if request != self.pending["request"]:
                self.cancel("Resolver beendet")
                return
            if time.monotonic() >= self.pending["deadline"]:
                self._navigation_failed("Zeitlimit der Zielbestätigung")
            return
        if request is None or not accept:
            return
        if request["operation"] in self.finished_operations:
            if not self.window.getProperty(result_key(request["operation"])):
                self._reply(request, {"ok": False})
            return
        entry = self.entries.get(request["entry"])
        playback = self.state.get("playback") or {}
        current = item_uri(playback.get("item"))
        if (self.disabled or not entry or request["session"] != self.session
                or not self.state.get("owned") or not self.state.get("av_ready")
                or not self.websocket.is_connected() or not current
                or playback.get("status") not in ("playing", "buffering")
                or playback.get("is_active") is not True):
            self._reply(request, {"ok": False})
            return
        entry = dict(entry)  # immutable selection, never the mutable slot registry
        if entry["path"] not in self.paths or self.current_path not in self.paths:
            self._reply(request, {"ok": False})
            return
        selected = self.paths.index(entry["path"])
        active = self.paths.index(self.current_path)
        direction = "previous" if selected < active else "next" if selected > active else "current"
        rebased = bool(self.dirty or self.mutation or entry["current"] != current
                       or entry["direction"] != direction)
        entry.update(direction=direction, current=current)
        self.pending = {
            "request": request, "entry": entry, "phase": "checking",
            "deadline": time.monotonic() + COMMAND_TIMEOUT,
            "state_seen": False, "queue_seen": None, "rebased": rebased,
            "before_position": None,
        }
        if self.mutation:
            # Kodi may already have applied a Swap while our path snapshot is
            # still old. Do not infer a relative skip from either ordering.
            self._navigation_failed("Playlistabgleich noch nicht bestätigt")
            return
        if request["revision"] != entry["revision"]:
            self._navigation_failed("Auswahl inzwischen aktualisiert")
            return
        if not (self.websocket.send_command("get_state")
                and self.websocket.send_command("get_queue", limit=10)):
            self.cancel("Steuerverbindung fehlt", notify=True)
        else:
            self.log("Native Queue: Nachbar wird vor dem relativen Skip erneut geprüft.")

    def _send_if_checked(self):
        pending = self.pending
        if not pending or pending["phase"] != "checking" or not pending["state_seen"]:
            return
        queue = pending["queue_seen"]
        if queue is None:
            return
        entry = pending["entry"]
        current = item_uri((self.state.get("playback") or {}).get("item"))
        if (self._read_request() != pending["request"]
                or not self.state.get("owned") or not self.state.get("av_ready")
                or not self.websocket.is_connected()
                or self.websocket.control_generation() != self.generation):
            self.cancel("Resolver oder Quelle inzwischen beendet")
            return
        if entry["direction"] == "current":
            if current == entry["current"]:
                self._resolve_target()
            else:
                self._navigation_failed("Aktueller Titel inzwischen geändert")
            return
        target = neighbor(queue, entry["direction"], current)
        if pending.get("rebased") and target and current == entry["current"]:
            entry.update(uid=target["uid"], uri=target["uri"], item=target["item"])
        if (current != entry["current"] or not target
                or (target["uid"], target["uri"]) != (entry["uid"], entry["uri"])):
            self._navigation_failed("Queue inzwischen geändert")
            return
        command = "skip_prev" if entry["direction"] == "previous" else "skip_next"
        actions = (self.state.get("playback") or {}).get("available_actions")
        if isinstance(actions, dict) and actions.get(command) is False:
            self._navigation_failed("Soloist erlaubt diese Aktion nicht")
            return
        pending["before_position"] = estimated_position_ms(
            (self.state.get("playback") or {}).get("position"))
        pending["sent_at_ms"] = time.time() * 1000
        if not self.websocket.send_command(command):
            self.cancel("Skip nicht vorgemerkt", notify=True)
            return
        self.native_commands.append((command, time.monotonic()))
        pending["command"] = command
        pending["phase"] = "waiting"
        self.log("Native Queue: {} einmalig vorgemerkt; Position_vorher_geschätzt={}ms; "
                 "warte auf tatsächlichen Titel oder bestätigten Neustart.".format(
                     command, pending["before_position"]))

    def handle_event(self, event):
        """Called after merging playback state, before normal Kodi metadata calls."""
        event_type = event.get("type")
        playback = self.state.get("playback") or {}
        current = item_uri(playback.get("item"))
        if event_type == "queue_changed":
            counts = [len(event[name]) if isinstance(event.get(name), list) else None
                      for name in ("previous", "upcoming")]
            self.log("Native Queue: Snapshot Vorher_Anzahl={} anbindbar={} "
                     "Nachher_Anzahl={} anbindbar={}.".format(
                         counts[0], bool(neighbor(event, "previous", current)),
                         counts[1], bool(neighbor(event, "next", current))))
            if self.pending:
                self.pending["latest_queue"] = (event, current)
            if self.pending and self.pending["phase"] == "checking":
                self.pending["queue_seen"] = event
                self._send_if_checked()
            elif not self.pending:
                self.queue = event
                self.queue_uri = current
                self.requested_at = None
                self.queue_attempts = 0
                self.dirty = True
            return True
        if event_type in ("track_changed", "playback_state") and current != self.observed_uri:
            self.observed_uri = current
            self.queue = None
            self.queue_uri = None
            self.requested_at = None
            self.queue_attempts = 0
            self.dirty = True
        if (playback.get("status") not in ("playing", "buffering")
                or playback.get("is_active") is not True
                or (event_type == "auth_state" and not event.get("logged_in"))):
            if self.pending:
                self.cancel("Soloist nicht mehr aktiv")
            return False  # normal pause/audio-gate processing must still run
        if not self.pending:
            return bool(self.window.getProperty(REQUEST_PROPERTY))
        pending = self.pending
        if pending["phase"] == "checking":
            if event_type == "playback_state":
                pending["state_seen"] = True
                self._send_if_checked()
        elif pending["phase"] == "waiting":
            if event_type in ("track_changed", "playback_state"):
                if current == pending["entry"]["uri"]:
                    self._resolve_target()
                elif current != pending["entry"]["current"]:
                    self._navigation_failed("Anderer Titel gestartet")
            elif (event_type == "position_sync"
                  and pending["entry"]["direction"] == "previous"
                  and current == pending["entry"]["current"]):
                before = pending["before_position"]
                position = playback.get("position") or {}
                after = estimated_position_ms(position)
                timestamp = position.get("timestamp_ms") if isinstance(position, dict) else None
                if (isinstance(before, (int, float)) and not isinstance(before, bool)
                        and isinstance(after, (int, float)) and not isinstance(after, bool)
                        and isinstance(timestamp, (int, float)) and not isinstance(timestamp, bool)
                        and timestamp >= pending.get("sent_at_ms", float("inf"))
                        and before >= 3000 and 0 <= after <= 1500):
                    # Spotify Previous can restart the current track. Resolve its
                    # actual metadata, never label the restart as the neighbour.
                    self.log("Native Queue: aktueller Titel neu gestartet; "
                             "vorher_geschätzt={}ms jetzt_geschätzt={}ms.".format(before, after))
                    self._resolve_target()
        return True

    def _resolve_target(self):
        pending = self.pending
        playback = self.state["playback"]
        mbids = self.artist_mbids(playback["item"])
        payload = {"ok": True, "url": self.state["playback_url"],
                   "item": playback["item"], "artist_mbids": mbids}
        if len(json.dumps(payload).encode("utf-8")) > MAX_PAYLOAD_BYTES:
            self.cancel("Titelmetadaten zu groß", notify=True)
            return
        self.current_path = pending["entry"]["path"]
        self.state["metadata_item_path"] = self.current_path
        self.state["av_ready"] = False
        self.state["applied_info_tag_revision"] = None
        self.state["pending_info_tag"] = None
        self.state["pending_audio_recovery"] = None
        pending["revision"] = hashlib.sha256(json.dumps(
            [playback["item"], mbids], sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")).hexdigest()
        pending["resolved_uri"] = item_uri(playback["item"])
        self.state["info_tag_revision"] = pending["revision"]
        pending["phase"] = "opening"
        pending["deadline"] = time.monotonic() + RESOLVE_TIMEOUT
        self._reply(pending["request"], payload)
        self.log("Native Queue: bestätigte Titelmetadaten an den Kodi-Resolver übergeben.")

    def av_started(self, source):
        if not self.pending:
            return
        if source != self.state.get("playback_url") or self.pending["phase"] != "opening":
            self.cancel("Andere Quelle gestartet")
            return
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        position = playlist.getposition()
        if not 0 <= position < playlist.size() or playlist[position].getPath() != self.current_path:
            self.cancel("Kodi-Eintrag passt nicht zur Übergabe")
            return
        self.state["applied_info_tag_revision"] = self.pending["revision"]
        playback = self.state.get("playback") or {}
        if item_uri(playback.get("item")) != self.pending["resolved_uri"]:
            mbids = self.artist_mbids(playback.get("item"))
            self.state["pending_info_tag"] = kodi_music_item(
                playback, source, xbmcgui.ListItem, artist_mbids_by_uri=mbids)
            self.state["info_tag_revision"] = hashlib.sha256(json.dumps(
                [playback.get("item"), mbids], sort_keys=True, separators=(",", ":"),
            ).encode("utf-8")).hexdigest()
            self.state["info_tag_attempts"] = 0
            self.state["info_tag_retry_at"] = 0
        pending = self.pending
        latest_queue = pending.get("latest_queue")
        if latest_queue and latest_queue[1] == item_uri(playback.get("item")):
            self.queue, self.queue_uri = latest_queue
        elif item_uri(playback.get("item")) == pending["entry"]["current"]:
            self.queue = pending.get("queue_seen") or self.queue
            self.queue_uri = item_uri(playback.get("item")) if self.queue is not None else None
        else:
            self.queue = None
            self.queue_uri = None
        self.pending = None
        self.requested_at = None
        self.queue_attempts = 0
        self.dirty = True
        self.log("Native Queue: neuer Kodi-Leser bestätigt; Audioformat unverändert.")

    def expected_end(self):
        # Only the old-reader EOF during the acknowledged new-item open is ours.
        # Stopped is deliberately not covered: an explicit user stop must cancel.
        pending = self.pending
        return bool(pending and pending["phase"] == "opening")

    def _remove(self, index, expected_path):
        context = self._context()
        if context is None:
            raise RuntimeError("Playlist ownership changed before removal")
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        if (not self._owned_source() or index >= playlist.size()
                or playlist[index].getPath() != expected_path):
            raise RuntimeError("Playlist ownership changed")
        self._rpc("Playlist.Remove", playlistid=0, position=index)
        after = list(self.paths)
        after.pop(index)
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0}

    def _tag_slot(self, index, path, item):
        slot = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)[index]
        slot.setLabel(item_title(item))
        slot.getMusicInfoTag().setMusicBrainzArtistID([])
        slot.setArt({"thumb": "", "icon": ""})
        kodi_music_item({"item": item}, path, lambda **kwargs: slot,
                        artist_mbids_by_uri=self.artist_mbids(item))
        slot.setProperty("ForceResolvePlugin", "true")
        slot.setProperty("IsPlayable", "true")
        slot.setProperty("inputstream", "inputstream.ffmpegdirect")
        slot.setProperty("inputstream-player", "videodefaultplayer")

    def _slot_token(self, path):
        parameters = parse_qs(urlsplit(path).query)
        token = (parameters.get("queue") or parameters.get("request") or [""])[0]
        if not TOKEN_PATTERN.fullmatch(token):
            raise ValueError("Not an owned resolver slot")
        return token

    def _publish_slot(self, index, path, direction, target, current):
        token = self._slot_token(path)
        candidate = dict(target, direction=direction, current=current, path=path)
        old = self.entries.get(token) or {}
        if {key: value for key, value in old.items() if key != "revision"} != candidate:
            self.revision += 1
            candidate["revision"] = self.revision
        else:
            candidate["revision"] = old["revision"]
        self._tag_slot(index, path, target["item"])
        self.entries[token] = candidate
        self.window.setProperty(PREFIX + token, json.dumps({
            "session": self.session, "revision": candidate["revision"],
        }))

    def _new_entry(self, direction, target, current_uri):
        token = uuid.uuid4().hex
        path = "plugin://service.soloist.native/?queue={}&session={}".format(token, self.session)
        self.revision += 1
        self.entries[token] = dict(target, direction=direction, current=current_uri,
                                   path=path, revision=self.revision)
        return path

    def _insert(self, index, path, target):
        if self._context() is None:
            raise RuntimeError("Playlist ownership changed before insertion")
        after = list(self.paths)
        after.insert(index, path)
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0,
                         "inserted": (index, path, target)}
        try:
            self._rpc("Playlist.Insert", playlistid=0, position=index, item={"file": path})
        except Exception:
            self.mutation = None
            raise

    def _swap(self, first, second):
        if self._context() is None:
            raise RuntimeError("Playlist ownership changed before swap")
        after = list(self.paths)
        after[first], after[second] = after[second], after[first]
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0}
        try:
            self._rpc("Playlist.Swap", playlistid=0, position1=first, position2=second)
        except Exception:
            self.mutation = None
            raise

    def _settle_mutation(self):
        mutation = self.mutation
        if not mutation:
            return True
        if not self._owned_source():
            return False
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        paths = [playlist[index].getPath() for index in range(playlist.size())]
        if paths == mutation["after"] and len(set(paths)) == len(paths):
            self.paths = paths
            self.mutation = None
            inserted = mutation.get("inserted")
            if inserted:
                index, path, target = inserted
                token = self._slot_token(path)
                entry = self.entries[token]
                self._publish_slot(index, path, entry["direction"], target,
                                   item_uri((self.state.get("playback") or {}).get("item")))
            for token, entry in list(self.entries.items()):
                if entry["path"] not in paths:
                    self.window.clearProperty(PREFIX + token)
                    del self.entries[token]
            return True
        if paths != mutation["before"] or time.monotonic() >= mutation["deadline"]:
            self.disable("Playlist-Änderung nicht bestätigt")
        return False

    def _targets(self, current):
        playback = self.state.get("playback") or {}
        targets = [("current", {"uid": current, "uri": current, "item": playback["item"]})]
        previous = neighbor(self.queue, "previous", current)
        upcoming = neighbor(self.queue, "next", current)
        actions = playback.get("available_actions")
        if isinstance(actions, dict):
            if actions.get("skip_prev") is False:
                previous = None
            if actions.get("skip_next") is False:
                upcoming = None
        if previous:
            targets.insert(0, ("previous", previous))
        if upcoming:
            targets.append(("next", upcoming))
        return targets

    def sync(self):
        """Mutate only a verified own playlist, never while a resolver is waiting."""
        if self.pending or self.window.getProperty(REQUEST_PROPERTY):
            return
        now = time.monotonic()
        if not self.dirty and now - self.last_poll < 0.5:
            return
        self.last_poll = now
        if not self.websocket.is_connected() or not self.state.get("owned"):
            self.cancel("Verbindung oder Playerbesitz beendet")
            return
        if not self.state.get("av_ready"):
            return
        path = self.state.get("metadata_item_path")
        if path != self.current_path:
            # A fresh one-shot open (including pause/resume) owns a new session.
            if path in self.paths:
                return
            self.close()
            self.session = uuid.uuid4().hex
            self.paths = []
            self.current_path = path
            self.disabled = False
            self.queue = None
            self.queue_uri = None
            self.requested_at = None
            self.queue_attempts = 0
            self.mutation = None
            self.dirty = True
        if not self._settle_mutation():
            return
        context = self._context()
        if context is None:
            if self.entries:
                self.cancel("Playlist verändert oder Shuffle/Repeat aktiv")
            return
        playlist, paths, position = context
        if not self.paths:
            self.paths = paths
        current = item_uri((self.state.get("playback") or {}).get("item"))
        if not current:
            return
        if self.disabled:
            return
        token = self._slot_token(self.current_path)
        existing = self.entries.get(token)
        if not existing or existing.get("direction") != "current" or existing.get("current") != current:
            target = {"uid": current, "uri": current, "item": self.state["playback"]["item"]}
            self._publish_slot(position, self.current_path, "current", target, current)
        if self.queue is None or self.queue_uri != current:
            if (self.queue_attempts < 3
                    and (self.requested_at is None or now - self.requested_at >= 5.0)):
                if self.websocket.send_command("get_queue", limit=10):
                    self.requested_at = now
                    self.queue_attempts += 1
            # A missing queue response does not revoke working native slots.
            if self.dirty:
                target = {"uid": current, "uri": current, "item": self.state["playback"]["item"]}
                self._publish_slot(position, self.current_path, "current", target, current)
                self.dirty = False
            return
        if not self.dirty:
            return
        targets = self._targets(current)
        if len(self.paths) < len(targets):
            # Grow only at the end. Existing native resolver URLs stay alive.
            present = {entry.get("uri") for entry in self.entries.values()}
            role, target = next(((role, target) for role, target in reversed(targets)
                                 if target["uri"] not in present), targets[-1])
            path = self._new_entry(role, target, current)
            self._insert(len(self.paths), path, target)
            return
        desired_position = next(index for index, (role, _) in enumerate(targets)
                                if role == "current")
        if position != desired_position:
            self._swap(position, desired_position)
            return
        if len(self.paths) > len(targets):
            self._remove(len(self.paths) - 1, self.paths[-1])
            return
        for index, (direction, target) in enumerate(targets):
            self._publish_slot(index, self.paths[index], direction, target, current)
        self.dirty = False
        labels = {role: item_title(target["item"])[:80] for role, target in targets}
        self.log("Native Queue: {} echte Nachbarn; Slotadressen erhalten, aktueller Index={}; "
                 "Vorher={} Aktuell={} Nächster={}.".format(
                     len(self.paths) - 1, position, labels.get("previous", "keiner"),
                     labels["current"], labels.get("next", "keiner")))
