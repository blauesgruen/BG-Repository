"""Download and validate the official Spotify Soloist Linux build for this system."""

import datetime
import hashlib
import io
import os
import re
import ssl
import struct
import subprocess
import tarfile
import tempfile
import urllib.request
import zlib
from urllib.parse import urlparse


DOWNLOAD_BASE = "https://soloist-builds.spotifycdn.com/soloist_release_{}.tar.gz"
# Spotify's Linux packages: ELF class (1 = 32-bit, 2 = 64-bit), ELF machine
# and the platform reported by `soloist --version` (checked 23.11.2026, 1.4.0).
PLATFORMS = {
    "arm64": {"elf_class": 2, "machine": 183, "version": "linux/aarch64",
              "label": "Linux ARM64"},
    "arm32": {"elf_class": 1, "machine": 40, "version": "linux/arm",
              "label": "Linux ARM (32 Bit)"},
    "x86_64": {"elf_class": 2, "machine": 62, "version": "linux/x86_64",
               "label": "Linux x86-64"},
}
DEFAULT_PLATFORM = "arm64"
# Spotify: every Soloist build runs 90 days, then exits with code 10.
SOLOIST_LIFETIME_DAYS = 90
REFRESH_BEFORE_DAYS = 30
EXPIRED_EXIT_CODE = 10

# Soloist links libatomic.so.1, which LibreELEC ships only for 32-bit ARM
# (spotify/soloist#16). When it is missing, the official Debian 13 package is
# downloaded with pinned checksums and used for Soloist only (LD_LIBRARY_PATH).
LIBATOMIC_VERSION = "14.2.0-19"
LIBATOMIC_PACKAGES = {
    "arm64": {"deb_arch": "arm64", "triplet": "aarch64-linux-gnu",
              "snapshot_sha1": "1c253948664b91d1351b0fe793a8528d75369561",
              "deb_sha256": "7ccff90234484bf21ae5ecb79d25b6a84b2f4038f65dd139085b2e3a937cd8dc",
              "lib_sha256": "6465c95aef505776652e9caf582d54c67b8e6314ae5a26973bd188b8f5d56c8e"},
    "x86_64": {"deb_arch": "amd64", "triplet": "x86_64-linux-gnu",
               "snapshot_sha1": "a478fbcba038f4a18db43b9771ee01a7da5ab23c",
               "deb_sha256": "212b399aae2f7299203d261a57e49372e09565a9a5ea971905f94a3960366c05",
               "lib_sha256": "9558489f171274c220104894258f483055853ed8a23d4ff754c850ce55765aa2"},
    "arm32": {"deb_arch": "armhf", "triplet": "arm-linux-gnueabihf",
              "snapshot_sha1": "3bc4903bbbfba4cb703a393a7c31524ec4580391",
              "deb_sha256": "e4a4dc17913ded43f2a8571f9c8c214d05534632fc5a41705d6b39acd8d5f4a4",
              "lib_sha256": "d40c6c4be043726abd201f64fdf1e74ee1d73c5f3aac22303948abb7b0d5499f"},
}
MAX_LIBATOMIC_DEB_BYTES = 1024 * 1024
DOWNLOAD_URL = DOWNLOAD_BASE.format(DEFAULT_PLATFORM)
MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
MAX_BINARY_BYTES = 128 * 1024 * 1024
DOWNLOAD_TIMEOUT_SECONDS = 30
VERSION_TIMEOUT_SECONDS = 10


class SoloistRuntimeError(Exception):
    """A safe, user-displayable runtime installation error."""


class UnsupportedPlatformError(SoloistRuntimeError):
    """Spotify offers no Soloist build for this system's programs."""


class MissingLibraryError(SoloistRuntimeError):
    """The system lacks a shared library Soloist needs (e.g. libatomic)."""

    def __init__(self, library):
        super().__init__("Dem System fehlt die Bibliothek {}".format(library))
        self.library = library


def _elf_identity(path):
    """Return (ELF class, machine) of a little-endian ELF file, or None."""
    try:
        with open(path, "rb") as elf_file:
            header = elf_file.read(20)
    except OSError:
        return None
    if len(header) < 20 or header[:4] != b"\x7fELF" or header[5] != 1:
        return None
    return header[4], struct.unpack("<H", header[18:20])[0]


def _platform_for(identity):
    for name, platform in PLATFORMS.items():
        if identity == (platform["elf_class"], platform["machine"]):
            return name
    return None


def detect_platform(executable="/proc/self/exe", machine=None, pointer_bits=None):
    """Return the Soloist package matching the programs on this system.

    Uses the running program (Kodi) rather than the kernel: several CoreELEC
    and LibreELEC images run a 64-bit kernel with 32-bit programs, where only
    the arm32 build can start.
    """
    name = _platform_for(_elf_identity(executable))
    if name:
        return name
    machine = (machine if machine is not None else os.uname().machine).lower()
    bits = pointer_bits if pointer_bits is not None else struct.calcsize("P") * 8
    if machine in ("aarch64", "arm64", "armv8l") or machine.startswith("armv7"):
        return "arm64" if bits == 64 else "arm32"
    if machine in ("x86_64", "amd64") and bits == 64:
        return "x86_64"
    raise UnsupportedPlatformError(
        "Spotify bietet Soloist für dieses System nicht an ({}, {} Bit)".format(machine, bits)
    )


def binary_matches_platform(binary_path, platform):
    spec = PLATFORMS[platform]
    return _elf_identity(binary_path) == (spec["elf_class"], spec["machine"])


def _validate_elf(binary_path, platform=DEFAULT_PLATFORM):
    if not binary_matches_platform(binary_path, platform):
        raise SoloistRuntimeError("Das Spotify-Binary ist kein {}-Programm".format(
            PLATFORMS[platform]["label"]))


def _validate_aarch64_elf(binary_path):
    _validate_elf(binary_path, "arm64")


def _download_archive(archive_path, opener=None, platform=DEFAULT_PLATFORM, progress=None):
    open_url = opener or urllib.request.urlopen
    request = urllib.request.Request(
        DOWNLOAD_BASE.format(platform),
        headers={"User-Agent": "Kodi-Soloist-Native"},
    )
    context = ssl.create_default_context()
    total = 0
    try:
        response = open_url(
            request,
            timeout=DOWNLOAD_TIMEOUT_SECONDS,
            context=context,
        )
        with response, open(archive_path, "wb") as archive_file:
            final_url = response.geturl()
            parsed_url = urlparse(final_url)
            if (
                parsed_url.scheme.lower() != "https"
                or parsed_url.hostname != "soloist-builds.spotifycdn.com"
            ):
                raise SoloistRuntimeError(
                    "Der Download endete außerhalb der offiziellen Spotify-Quelle"
                )
            try:
                expected = int(response.headers.get("Content-Length") or 0)
            except (AttributeError, TypeError, ValueError):
                expected = 0
            while True:
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if progress is not None:
                    progress("download", total, expected)
                if total > MAX_ARCHIVE_BYTES:
                    raise SoloistRuntimeError(
                        "Das Spotify-Archiv überschreitet die Größenbegrenzung"
                    )
                archive_file.write(chunk)
    except SoloistRuntimeError:
        raise
    except Exception as error:
        raise SoloistRuntimeError("Der Download von Spotify ist fehlgeschlagen") from error
    if total == 0:
        raise SoloistRuntimeError("Spotify hat ein leeres Archiv geliefert")


def _extract_binary(archive_path, candidate_path):
    try:
        with tarfile.open(archive_path, mode="r|gz") as archive:
            binary_count = 0
            seen_names = set()
            total_size = 0
            member_count = 0
            for member in archive:
                member_count += 1
                if member_count > 3:
                    raise SoloistRuntimeError(
                        "Spotify-Archiv enthält eine ungültige Anzahl Dateien"
                    )
                name = member.name
                if (
                    not name
                    or name.startswith("/")
                    or ".." in name.split("/")
                    or "\\" in name
                ):
                    raise SoloistRuntimeError("Spotify-Archiv enthält einen ungültigen Pfad")
                if name in seen_names:
                    raise SoloistRuntimeError("Spotify-Archiv enthält doppelte Einträge")
                seen_names.add(name)
                total_size += member.size
                if (
                    member.size < 0
                    or member.size > MAX_BINARY_BYTES
                    or total_size > MAX_ARCHIVE_BYTES
                ):
                    raise SoloistRuntimeError("Spotify-Archiv überschreitet die Größenbegrenzung")
                if name == "soloist":
                    if not member.isfile():
                        raise SoloistRuntimeError("Spotify-Archiv enthält kein reguläres Binary")
                    binary_count += 1
                    if member.size <= 0 or member.size > MAX_BINARY_BYTES:
                        raise SoloistRuntimeError("Das Spotify-Binary hat eine ungültige Größe")
                    source = archive.extractfile(member)
                    if source is None:
                        raise SoloistRuntimeError("Das Spotify-Binary kann nicht gelesen werden")
                    with source, open(candidate_path, "wb") as candidate:
                        remaining = member.size
                        while remaining:
                            chunk = source.read(min(1024 * 1024, remaining))
                            if not chunk:
                                raise SoloistRuntimeError("Das Spotify-Binary ist unvollständig")
                            candidate.write(chunk)
                            remaining -= len(chunk)
                        if source.read(1):
                            raise SoloistRuntimeError(
                                "Das Spotify-Binary ist größer als im Archiv angegeben"
                            )
                elif name not in ("CHANGELOG.md", "THIRD_PARTY_LICENSES.txt"):
                    raise SoloistRuntimeError("Spotify-Archiv enthält einen unerwarteten Eintrag")
                elif not member.isfile():
                    raise SoloistRuntimeError("Spotify-Archiv enthält einen unerwarteten Dateityp")

            if member_count == 0 or binary_count != 1:
                raise SoloistRuntimeError("Spotify-Archiv enthält nicht genau ein Soloist-Binary")
        os.chmod(candidate_path, 0o700)
    except SoloistRuntimeError:
        raise
    except (OSError, EOFError, tarfile.TarError, zlib.error) as error:
        raise SoloistRuntimeError(
            "Das Spotify-Archiv ist beschädigt oder ungültig ({})".format(
                type(error).__name__
            )
        ) from error


def library_dir(soloist_root):
    return os.path.join(soloist_root, "lib")


def soloist_environment(soloist_root, base=None):
    """Environment for Soloist: add our own library folder if it holds libraries."""
    environment = dict(os.environ if base is None else base)
    directory = library_dir(soloist_root)
    if os.path.isdir(directory) and os.listdir(directory):
        current = environment.get("LD_LIBRARY_PATH")
        environment["LD_LIBRARY_PATH"] = directory + (":" + current if current else "")
    return environment


def _xz_decompress(data, runner=None):
    """Decompress xz data; Kodi's Python on (Core|Libre)ELEC lacks lzma, busybox has xzcat."""
    try:
        import lzma
        return lzma.decompress(data)
    except ImportError:
        pass
    run = runner or subprocess.run
    for command in (["xzcat"], ["xz", "-dc"], ["busybox", "xzcat"]):
        try:
            result = run(command, input=data, stdout=subprocess.PIPE,
                         stderr=subprocess.DEVNULL, timeout=30, check=False)
        except (OSError, subprocess.TimeoutExpired):
            continue
        if result.returncode == 0 and result.stdout:
            return result.stdout
    raise SoloistRuntimeError("Kein xz-Entpacker für libatomic gefunden")


def _ar_member(data, prefix):
    if data[:8] != b"!<arch>\n":
        raise SoloistRuntimeError("libatomic-Paket hat ein ungültiges Format")
    offset = 8
    while offset + 60 <= len(data):
        header = data[offset:offset + 60]
        name = header[:16].decode("ascii", "replace").strip().rstrip("/")
        size = int(header[48:58].decode("ascii").strip() or 0)
        body = data[offset + 60:offset + 60 + size]
        if name.startswith(prefix):
            return name, body
        offset += 60 + size + (size & 1)
    raise SoloistRuntimeError("libatomic-Paket enthält keine Daten")


def _fetch_libatomic_deb(spec, opener=None):
    open_url = opener or urllib.request.urlopen
    name = "libatomic1_{}_{}.deb".format(LIBATOMIC_VERSION, spec["deb_arch"])
    urls = ("https://deb.debian.org/debian/pool/main/g/gcc-14/" + name,
            "https://snapshot.debian.org/file/" + spec["snapshot_sha1"])
    for url in urls:
        request = urllib.request.Request(url, headers={"User-Agent": "Kodi-Soloist-Native"})
        try:
            response = open_url(request, timeout=DOWNLOAD_TIMEOUT_SECONDS,
                                context=ssl.create_default_context())
            with response:
                if urlparse(response.geturl()).scheme.lower() != "https":
                    continue
                data = response.read(MAX_LIBATOMIC_DEB_BYTES + 1)
        except Exception:
            continue
        if len(data) <= MAX_LIBATOMIC_DEB_BYTES and \
                hashlib.sha256(data).hexdigest() == spec["deb_sha256"]:
            return data
    raise SoloistRuntimeError("libatomic konnte nicht von Debian geladen werden")


def install_libatomic(soloist_root, platform, opener=None, runner=None):
    """Install the pinned Debian libatomic.so.1 into Soloist's own library folder."""
    spec = LIBATOMIC_PACKAGES.get(platform)
    if spec is None:
        raise MissingLibraryError("libatomic.so.1")
    deb = _fetch_libatomic_deb(spec, opener)
    name, payload = _ar_member(deb, "data.tar")
    if name.endswith(".xz"):
        payload = _xz_decompress(payload, runner)
    elif not name.endswith(".gz"):
        raise SoloistRuntimeError("libatomic-Paket hat ein unbekanntes Format")
    wanted = "./usr/lib/{}/libatomic.so.1.2.0".format(spec["triplet"])
    try:
        with tarfile.open(fileobj=io.BytesIO(payload)) as archive:
            member = archive.getmember(wanted)
            if not member.isfile():
                raise SoloistRuntimeError("libatomic-Paket enthält keine Bibliothek")
            library = archive.extractfile(member).read()
    except (KeyError, tarfile.TarError, OSError) as error:
        raise SoloistRuntimeError("libatomic-Paket ist beschädigt") from error
    if hashlib.sha256(library).hexdigest() != spec["lib_sha256"]:
        raise SoloistRuntimeError("libatomic hat eine unerwartete Prüfsumme")
    directory = library_dir(soloist_root)
    os.makedirs(directory, mode=0o700, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=".libatomic-", dir=directory)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(library)
        os.chmod(temporary, 0o644)
        os.replace(temporary, os.path.join(directory, "libatomic.so.1"))
    except OSError:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    return os.path.join(directory, "libatomic.so.1")


def _check_version(binary_path, runner=None, platform=DEFAULT_PLATFORM, environment=None):
    run = runner or subprocess.run
    try:
        result = run(
            [binary_path, "--version"],
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=VERSION_TIMEOUT_SECONDS,
            check=False,
        )
    except Exception as error:
        raise SoloistRuntimeError(
            "Das Soloist-Binary kann auf diesem Gerät nicht gestartet werden"
        ) from error
    output = result.stdout or ""
    missing = re.search(r"error while loading shared libraries: ([\w.+-]+\.so[\w.]*)", output)
    if result.returncode != 0 and missing:
        raise MissingLibraryError(missing.group(1))
    if result.returncode != 0 or PLATFORMS[platform]["version"] not in output.lower():
        raise SoloistRuntimeError("Spotify lieferte kein startfähiges {}-Binary".format(
            PLATFORMS[platform]["label"]))
    return output.strip()


def install_soloist(data_dir, opener=None, runner=None, platform=None, progress=None,
                    library_opener=None):
    """Download, validate, and atomically install Soloist under add-on data."""
    platform = platform or detect_platform()
    root = os.path.join(data_dir, "soloist")
    binary_dir = os.path.join(root, "bin")
    runtime_dir = os.path.join(data_dir, "runtime")
    final_path = os.path.join(binary_dir, "soloist")
    archive_path = None
    candidate_path = None
    try:
        os.makedirs(binary_dir, mode=0o700, exist_ok=True)
        os.makedirs(runtime_dir, mode=0o700, exist_ok=True)
        os.chmod(binary_dir, 0o700)
        os.chmod(runtime_dir, 0o700)
        archive_descriptor, archive_path = tempfile.mkstemp(
            prefix="soloist-", suffix=".tar.gz", dir=runtime_dir
        )
        os.close(archive_descriptor)
        candidate_descriptor, candidate_path = tempfile.mkstemp(
            prefix=".soloist-", dir=binary_dir
        )
        os.close(candidate_descriptor)
        _download_archive(archive_path, opener=opener, platform=platform, progress=progress)
        if progress is not None:
            progress("verify", 0, 0)
        _extract_binary(archive_path, candidate_path)
        _validate_elf(candidate_path, platform)
        try:
            version = _check_version(candidate_path, runner=runner, platform=platform,
                                     environment=soloist_environment(root))
        except MissingLibraryError as error:
            if error.library != "libatomic.so.1":
                raise
            if progress is not None:
                progress("library", 0, 0)
            try:
                install_libatomic(root, platform, opener=library_opener, runner=runner)
            except MissingLibraryError:
                raise
            except (SoloistRuntimeError, OSError) as library_error:
                raise MissingLibraryError("libatomic.so.1") from library_error
            version = _check_version(candidate_path, runner=runner, platform=platform,
                                     environment=soloist_environment(root))
        os.replace(candidate_path, final_path)
        return final_path, version
    except SoloistRuntimeError:
        raise
    except OSError as error:
        raise SoloistRuntimeError("Kodi-Datenpfad ist nicht beschreibbar") from error
    finally:
        for temporary_path in (archive_path, candidate_path):
            if temporary_path is None:
                continue
            try:
                os.unlink(temporary_path)
            except FileNotFoundError:
                pass


def build_date(version_text):
    """Build date from `soloist --version`, e.g. `... build 1795456923 (20261123) ...`."""
    match = re.search(r"\((\d{4})(\d{2})(\d{2})\)", version_text or "")
    if not match:
        return None
    try:
        return datetime.date(*(int(part) for part in match.groups()))
    except ValueError:
        return None


def expiry_date(version_text):
    built = build_date(version_text)
    return built + datetime.timedelta(days=SOLOIST_LIFETIME_DAYS) if built else None


def refresh_state(version_text, today=None):
    """"ok", "due" (less than REFRESH_BEFORE_DAYS left), "expired" or "unknown"."""
    expires = expiry_date(version_text)
    if expires is None:
        return "unknown"
    today = today or datetime.date.today()
    if today >= expires:
        return "expired"
    if (expires - today).days <= REFRESH_BEFORE_DAYS:
        return "due"
    return "ok"


def installed_version(binary_path, platform=DEFAULT_PLATFORM, runner=None):
    """`soloist --version` of the installed binary (raises SoloistRuntimeError)."""
    root = os.path.dirname(os.path.dirname(binary_path))
    return _check_version(binary_path, runner=runner, platform=platform,
                          environment=soloist_environment(root))
