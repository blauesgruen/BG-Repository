#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os

import xbmcaddon


def _translate_path(path: str) -> str:
    try:
        import xbmcvfs

        translated = xbmcvfs.translatePath(path)
        if translated:
            return translated
    except Exception:
        pass
    return path


def get_addon_id() -> str:
    current_dir = os.path.dirname(os.path.abspath(_translate_path(__file__)))
    addon_dir = os.path.abspath(os.path.join(current_dir, "..", ".."))
    addon_id = os.path.basename(addon_dir).strip()
    if addon_id:
        return addon_id

    try:
        addon_id = xbmcaddon.Addon().getAddonInfo("id").strip()
        if addon_id:
            return addon_id
    except Exception:
        pass

    raise RuntimeError("Unable to resolve addon id")
