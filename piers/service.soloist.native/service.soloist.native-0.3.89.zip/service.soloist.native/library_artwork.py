"""Resolve Kodi music-library artist fanart without importing Kodi modules."""

import json
import queue
import re
import threading
import time
import unicodedata


MAX_QUEUE_SIZE = 16
MAX_CACHE_ENTRIES = 128
CACHE_SECONDS = 300.0
NEGATIVE_CACHE_SECONDS = 30.0
MAX_ARTISTS = 25
MAX_FANART_LENGTH = 8192
_MBID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)


class _ArtworkError(Exception):
    """A safe error code suitable for logging without request data."""

    def __init__(self, code):
        super().__init__(code)
        self.code = code


class LibraryArtworkResolver:
    """Look up exact Kodi music-library artist matches on one bounded worker."""

    def __init__(self, execute_jsonrpc, logger):
        self.execute_jsonrpc = execute_jsonrpc
        self.logger = logger
        self._lock = threading.Lock()
        self._cache = {}
        self._pending = set()
        self._requests = queue.Queue(maxsize=MAX_QUEUE_SIZE)
        self._stop_event = threading.Event()
        self._thread = None

    def lookup_or_queue(self, artist_uri, name, mbid=None):
        """Return cached fanart, queueing a refresh or first lookup as needed."""
        if (not isinstance(artist_uri, str) or len(artist_uri) > 1024
                or not isinstance(name, str) or not name.strip() or len(name) > 512
                or (mbid is not None and not _valid_mbid(mbid))):
            return None
        normalized_name = unicodedata.normalize("NFKC", name).casefold()
        key = (artist_uri, normalized_name, mbid.lower() if mbid else "")
        now = time.monotonic()
        with self._lock:
            if self._stop_event.is_set():
                return None
            cached = self._cache.get(key)
            fresh = cached is not None and cached[1] > now
            if not fresh and key not in self._pending:
                try:
                    self._requests.put_nowait((key, artist_uri, name, mbid))
                except queue.Full:
                    pass
                else:
                    self._pending.add(key)
                    self._start_worker_locked()
            return cached[0] if cached is not None else None

    def close(self):
        """Stop the worker and wait briefly for an in-flight JSON-RPC call."""
        with self._lock:
            if not self._stop_event.is_set():
                self._stop_event.set()
                try:
                    self._requests.put_nowait(None)
                except queue.Full:
                    pass
            thread = self._thread
        if thread is not None:
            thread.join(timeout=0.25)
            return not thread.is_alive()
        return True

    def _start_worker_locked(self):
        if self._thread is None or not self._thread.is_alive():
            self._thread = threading.Thread(
                target=self._run, name="soloist-library-artwork", daemon=True,
            )
            self._thread.start()

    def _run(self):
        while not self._stop_event.is_set():
            try:
                task = self._requests.get(timeout=0.1)
            except queue.Empty:
                continue
            if task is None:
                return
            key, _artist_uri, name, mbid = task
            try:
                fanart = self._lookup(name, mbid)
                ttl = CACHE_SECONDS if fanart else NEGATIVE_CACHE_SECONDS
            except Exception as error:
                fanart = None
                ttl = NEGATIVE_CACHE_SECONDS
                reason = error.code if isinstance(error, _ArtworkError) else type(error).__name__
                self._log("lookup_failed", reason)
            with self._lock:
                self._pending.discard(key)
                if self._stop_event.is_set():
                    continue
                self._cache[key] = (fanart, time.monotonic() + ttl)
                self._trim_cache_locked()

    def _lookup(self, name, mbid):
        request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "AudioLibrary.GetArtists",
            "params": {
                "albumartistsonly": False,
                "filter": {"field": "artist", "operator": "is", "value": name},
                "properties": ["musicbrainzartistid", "fanart", "art"],
                "limits": {"start": 0, "end": MAX_ARTISTS},
            },
        }
        try:
            raw = self.execute_jsonrpc(json.dumps(request, separators=(",", ":")))
        except Exception as error:
            raise _ArtworkError("rpc_" + type(error).__name__) from None
        if not isinstance(raw, str) or len(raw.encode("utf-8")) > 512 * 1024:
            raise _ArtworkError("oversized_or_invalid_response")
        try:
            response = json.loads(raw)
        except (TypeError, ValueError):
            raise _ArtworkError("invalid_json") from None
        if not isinstance(response, dict):
            raise _ArtworkError("invalid_response")
        if "error" in response:
            error = response.get("error")
            code = error.get("code") if isinstance(error, dict) else None
            safe_code = (str(code) if isinstance(code, int) and not isinstance(code, bool)
                         and -2147483648 <= code <= 2147483647 else "unknown")
            raise _ArtworkError("jsonrpc_" + safe_code)
        result = response.get("result")
        if not isinstance(result, dict):
            raise _ArtworkError("invalid_artists")
        artists = result.get("artists")
        limits = result.get("limits")
        if not isinstance(artists, list) or not isinstance(limits, dict):
            raise _ArtworkError("invalid_schema")
        total = limits.get("total")
        if isinstance(total, bool) or not isinstance(total, int) or total < 0:
            raise _ArtworkError("invalid_limits")
        if total > MAX_ARTISTS or len(artists) > MAX_ARTISTS:
            raise _ArtworkError("too_many_matches")
        if total != len(artists):
            raise _ArtworkError("incomplete_results")
        exact_name = unicodedata.normalize("NFKC", name).casefold()
        matches = [artist for artist in artists if _artist_name(artist) == exact_name]
        if not matches:
            return None
        for artist in matches:
            values = artist.get("musicbrainzartistid", [])
            if (not isinstance(values, list)
                    or any(not isinstance(value, str) or (value and not _valid_mbid(value))
                           for value in values)):
                raise _ArtworkError("invalid_artist_ids")
        requested_mbid = mbid.lower() if mbid else None
        if requested_mbid:
            matching_ids = [artist for artist in matches
                            if requested_mbid in _artist_mbids(artist)]
            if len(matches) == 1:
                ids = _artist_mbids(matches[0])
                if ids and requested_mbid not in ids:
                    return None
                selected = matches[0]
            else:
                if len(matching_ids) != 1:
                    return None
                selected = matching_ids[0]
        elif len(matches) == 1:
            selected = matches[0]
        else:
            return None
        return _fanart(selected)

    def _trim_cache_locked(self):
        if len(self._cache) <= MAX_CACHE_ENTRIES:
            return
        oldest = sorted(self._cache.items(), key=lambda entry: entry[1][1])
        for key, _value in oldest[:len(self._cache) - MAX_CACHE_ENTRIES]:
            self._cache.pop(key, None)

    def _log(self, code, detail):
        try:
            self.logger("Kodi-Künstlerbild {} ({}).".format(code, detail))
        except Exception:
            pass


def _valid_mbid(value):
    return isinstance(value, str) and _MBID_RE.fullmatch(value) is not None


def _artist_name(artist):
    if not isinstance(artist, dict):
        return ""
    value = artist.get("artist")
    if not isinstance(value, str):
        return ""
    return unicodedata.normalize("NFKC", value).casefold()


def _artist_mbids(artist):
    if not isinstance(artist, dict):
        return []
    values = artist.get("musicbrainzartistid")
    if not isinstance(values, list):
        return []
    return [value.lower() for value in values if _valid_mbid(value)]


def _fanart(artist):
    value = artist.get("fanart")
    if not _valid_art(value):
        art = artist.get("art")
        value = art.get("fanart") if isinstance(art, dict) else None
    return value if _valid_art(value) else None


def _valid_art(value):
    return (isinstance(value, str) and 0 < len(value) <= MAX_FANART_LENGTH
            and not any(unicodedata.category(char) == "Cc" for char in value))
