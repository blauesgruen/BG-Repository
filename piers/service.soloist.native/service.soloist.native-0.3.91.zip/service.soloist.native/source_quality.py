"""Source quality of the current track, read from Soloist's verbose output.

Soloist prints a small block when it opens a track (checked 25.11.2026,
Soloist 1.4.0)::

    FileStreamer file average bitrate: 1498210
        codec: flac
        bitrate: 1400000 bits/s
        sample format: 32-bit-float-pcm

The bit depth is not printed. Spotify's lossless tiers have the nominal
bitrates 700 000 (FLAC 16 bit) and 1 400 000 bit/s (FLAC 24 bit), matching
the file formats FLAC_FLAC and FLAC_FLAC_24BIT in the binary, so the depth
is derived from the nominal bitrate. A block that arrives long after a track
change belongs to a prefetched next track and waits for that change.
"""

import re
import time

TRACK_CHANGE_WINDOW = 15.0
LOSSLESS_24_BIT_MIN = 1000000

_AVERAGE = re.compile(r"FileStreamer file average bitrate:\s*(\d+)")
_CODEC = re.compile(r"^\s*codec:\s*([\w.+-]+)\s*$")
_BITRATE = re.compile(r"^\s*bitrate:\s*(\d+)\s*bits/s\s*$")
_SAMPLE_FORMAT = re.compile(r"^\s*sample format:\s*(\S+)\s*$")
_RENDER_RATE = re.compile(r"format \[[^,\]]+,\s*(\d+)\s*Hz\]")
_SDK_PREFIX = re.compile(r"^(?:Soloist:\s*)?[A-Z]\s+\[f:\d+\]")

CODEC_NAMES = {"flac": "FLAC", "vorbis": "Ogg Vorbis", "aac": "AAC", "mp3": "MP3",
               "opus": "Opus"}


def _body(message):
    """Strip "Soloist: I [f:347]" so the indented field lines can be matched."""
    return _SDK_PREFIX.sub("", message, count=1)


class SourceQuality:
    def __init__(self, clock=None):
        self.clock = clock or time.monotonic
        self.current = None
        self.pending = None
        self.sample_rate = None
        self._average = None
        self._block = None
        self._last_track_change = None

    def feed(self, message):
        """Parse one forwarded Soloist line (already without secrets)."""
        if not isinstance(message, str):
            return
        rate = _RENDER_RATE.search(message)
        if rate:
            self.sample_rate = int(rate.group(1))
        average = _AVERAGE.search(message)
        if average:
            value = int(average.group(1))
            if value > 0:
                self._average = value
            return
        body = _body(message)
        codec = _CODEC.match(body)
        if codec:
            self._block = {"codec": codec.group(1).lower(), "average": self._average}
            self._average = None
            return
        if self._block is None:
            return
        bitrate = _BITRATE.match(body)
        if bitrate:
            self._block["nominal"] = int(bitrate.group(1))
            return
        if _SAMPLE_FORMAT.match(body):
            self._commit(self._block)
            self._block = None

    def _commit(self, record):
        now = self.clock()
        recent = (self._last_track_change is not None
                  and now - self._last_track_change <= TRACK_CHANGE_WINDOW)
        if self.current is None or recent:
            self.current = record
            self.pending = None
        else:
            self.pending = record

    def on_track_changed(self):
        self._last_track_change = self.clock()
        if self.pending is not None:
            self.current, self.pending = self.pending, None

    def clear(self):
        self.current = None
        self.pending = None

    def values(self):
        """Raw values for the current track: codec, lossless, bit depth, kbit/s."""
        record = self.current
        if not record:
            return {}
        codec = record.get("codec", "")
        nominal = record.get("nominal")
        average = record.get("average")
        lossless = codec == "flac"
        result = {"codec": CODEC_NAMES.get(codec, codec.upper()), "lossless": lossless}
        if lossless and isinstance(nominal, int):
            result["bits"] = 24 if nominal >= LOSSLESS_24_BIT_MIN else 16
        kbps = average or nominal
        if isinstance(kbps, int) and kbps > 0:
            result["kbps"] = int(round(kbps / 1000.0))
        if self.sample_rate:
            result["rate"] = self.sample_rate
        return result


def _khz(rate, decimal):
    text = "{:.1f}".format(rate / 1000.0).rstrip("0").rstrip(".")
    return text.replace(".", decimal)


def quality_properties(values, output_bits, german=True):
    """Skin properties (all strings). Empty dict when nothing is known."""
    if not values:
        return {}
    decimal = "," if german else "."
    bit = " Bit" if german else "-bit"
    props = {"Codec": values["codec"], "OutputBitDepth": str(output_bits)}
    if values.get("lossless"):
        props["Lossless"] = "true"
    if "bits" in values:
        props["BitDepth"] = str(values["bits"])
    if "rate" in values:
        props["SampleRate"] = "{} kHz".format(_khz(values["rate"], decimal))
    if "kbps" in values:
        props["Bitrate"] = "{} kbit/s".format(values["kbps"])
    parts = [values["codec"]]
    if "bits" in values:
        parts.append("{}{}".format(values["bits"], bit))
    elif "kbps" in values:
        parts.append(props["Bitrate"])
    if "SampleRate" in props:
        parts.append(props["SampleRate"])
    quality = " · ".join(parts)
    if "bits" in values and output_bits < values["bits"]:
        quality += (" ({}{} wiedergegeben)" if german else " ({}{} playback)").format(
            output_bits, bit)
    props["Quality"] = quality
    return props


QUALITY_PROPERTY_NAMES = ("Codec", "BitDepth", "SampleRate", "Bitrate", "Lossless",
                          "OutputBitDepth", "Quality")
