"""Kodi controls for status, API-key storage, and the Soloist service."""

import json
import os
import uuid

import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs

from credentials import delete_api_key, load_api_key, save_api_key


ADDON_ID = "service.soloist.native"
COMMAND_PROPERTY = "service.soloist.native.command"
RESULT_PROPERTY = "service.soloist.native.result"
PROGRESS_PROPERTY = "service.soloist.native.progress"
UPDATE_READY_PROPERTY = "service.soloist.native.update_ready"
WINDOW_ID = 10000
REQUEST_TIMEOUT_SECONDS = 90


RESULT_STRINGS = {
    "started": 32017,
    "already_running": 32018,
    "stopped:0": 32019,
    "not_running": 32020,
    "binary_missing": 32021,
    "configuration_missing": 32022,
    "install_failed": 32023,
    "unsupported_platform": 32063,
    "library_missing": 32064,
    "pulseaudio_missing": 32070,
    "pulseaudio_not_running": 32071,
    "pulseaudio_no_sink": 32072,
    "audio_setup_failed": 32035,
    "start_failed": 32024,
    "download_consent_required": 32025,
    "invalid_command": 32026,
    "command_failed": 32026,
    "request_timeout": 32030,
}


def _data_path(addon):
    return xbmcvfs.translatePath(addon.getAddonInfo("profile"))


def _request_service(action, allow_download=False, timeout=REQUEST_TIMEOUT_SECONDS):
    window = xbmcgui.Window(WINDOW_ID)
    monitor = xbmc.Monitor()
    request_id = uuid.uuid4().hex
    payload = {
        "action": action,
        "allow_download": bool(allow_download),
        "request_id": request_id,
    }
    window.setProperty(COMMAND_PROPERTY, json.dumps(payload))
    progress = _DownloadProgress(window, request_id) if allow_download else None
    try:
        return _wait_for_result(window, monitor, request_id, timeout, progress)
    finally:
        if progress is not None:
            progress.close()


class _DownloadProgress:
    """Progress dialog while the service downloads Soloist from Spotify."""

    def __init__(self, window, request_id):
        self.window = window
        self.request_id = request_id
        self.dialog = None

    def update(self):
        raw = self.window.getProperty(PROGRESS_PROPERTY)
        if not raw:
            return
        try:
            state = json.loads(raw)
        except ValueError:
            return
        if state.get("request_id") != self.request_id:
            return
        addon = xbmcaddon.Addon()
        if self.dialog is None:
            self.dialog = xbmcgui.DialogProgress()
            self.dialog.create(addon.getLocalizedString(32000), addon.getLocalizedString(32067))
        if state.get("stage") == "verify":
            self.dialog.update(100, addon.getLocalizedString(32068))
            return
        done_mb = state.get("done", 0) / 1048576.0
        total_mb = state.get("total", 0) / 1048576.0
        detail = ("{:.1f} / {:.1f} MB".format(done_mb, total_mb) if total_mb
                  else "{:.1f} MB".format(done_mb))
        self.dialog.update(int(state.get("percent", 0)),
                           "{}\n{}".format(addon.getLocalizedString(32067), detail))

    def close(self):
        if self.dialog is not None:
            self.dialog.close()


def _wait_for_result(window, monitor, request_id, timeout, progress):
    for _ in range(int(timeout / 0.25)):
        if monitor.waitForAbort(0.25):
            return "invalid_command"
        if progress is not None:
            progress.update()
        raw_result = window.getProperty(RESULT_PROPERTY)
        if not raw_result:
            continue
        try:
            result = json.loads(raw_result)
        except ValueError:
            continue
        if result.get("request_id") == request_id:
            window.clearProperty(RESULT_PROPERTY)
            return result.get("code", "invalid_command")
    return "request_timeout"


def show_status():
    """Show the current runtime status without exposing credentials."""
    addon = xbmcaddon.Addon()
    data_path = _data_path(addon)
    binary_path = os.path.join(data_path, "soloist", "bin", "soloist")
    installed = os.path.isfile(binary_path)
    runtime = _request_service("status", timeout=3)
    runtime_string = {
        "ready": 32048,
        "running_disconnected": 32049,
        "not_running": 32050,
        "configuration_missing": 32042,
        "binary_missing": 32043,
        "request_timeout": 32051,
        "invalid_command": 32051,
    }.get(runtime, 32051)
    xbmcgui.Dialog().ok(
        addon.getLocalizedString(32002),
        "{}\n{}".format(
            addon.getLocalizedString(runtime_string),
            addon.getLocalizedString(32015 if installed else 32014),
        ),
    )


def _save_key(addon):
    data_path = _data_path(addon)
    dialog = xbmcgui.Dialog()
    value = dialog.input(
        addon.getLocalizedString(32010),
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT,
    )
    if not value:
        return
    try:
        save_api_key(data_path, value)
    except (OSError, ValueError):
        dialog.notification(
            addon.getLocalizedString(32000),
            addon.getLocalizedString(32027),
            xbmcgui.NOTIFICATION_ERROR,
        )
        return
    dialog.notification(addon.getLocalizedString(32000), addon.getLocalizedString(32011))


def _start(addon):
    dialog = xbmcgui.Dialog()
    data_path = _data_path(addon)
    if load_api_key(data_path) is None:
        _save_key(addon)
        if load_api_key(data_path) is None:
            return

    device_name = addon.getSetting("device_name").strip()
    if not device_name:
        device_name = dialog.input(
            addon.getLocalizedString(32008),
            defaultt="Kodi Soloist",
            type=xbmcgui.INPUT_ALPHANUM,
        ).strip()
        if not device_name or len(device_name) > 80 or any(ord(char) < 32 for char in device_name):
            return
        addon.setSetting("device_name", device_name)

    binary_path = os.path.join(data_path, "soloist", "bin", "soloist")
    allow_download = False
    if not os.path.isfile(binary_path):
        allow_download = dialog.yesno(
            addon.getLocalizedString(32000),
            addon.getLocalizedString(32012),
            yeslabel=addon.getLocalizedString(32028),
            nolabel=addon.getLocalizedString(32029),
        )
        if not allow_download:
            return

    result = _request_service("start", allow_download=allow_download)
    if allow_download and result == "started":
        # After a download the user waited; a short toast is easy to miss.
        dialog.ok(addon.getLocalizedString(32000),
                  addon.getLocalizedString(32069).format(device_name))
        return
    message_id = RESULT_STRINGS.get(result)
    if message_id is None:
        message_id = 32030 if result == "request_timeout" else 32026
    icon = (
        xbmcgui.NOTIFICATION_INFO
        if result in ("started", "already_running")
        else xbmcgui.NOTIFICATION_ERROR
    )
    dialog.notification(
        addon.getLocalizedString(32000), addon.getLocalizedString(message_id), icon
    )


def _stop(addon):
    result = _request_service("stop")
    if result.startswith("stopped:"):
        result = "stopped:0"
    message_id = RESULT_STRINGS.get(result, 32026)
    icon = (
        xbmcgui.NOTIFICATION_INFO
        if result.startswith("stopped") or result == "not_running"
        else xbmcgui.NOTIFICATION_ERROR
    )
    xbmcgui.Dialog().notification(
        addon.getLocalizedString(32000), addon.getLocalizedString(message_id), icon
    )


def _prepare_update(addon):
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        addon.getLocalizedString(32000), addon.getLocalizedString(32055)
    ):
        return

    window = xbmcgui.Window(WINDOW_ID)
    monitor = xbmc.Monitor()
    request_id = uuid.uuid4().hex
    window.clearProperty(UPDATE_READY_PROPERTY)
    window.setProperty(
        COMMAND_PROPERTY,
        json.dumps({"action": "prepare_update", "request_id": request_id}),
    )
    stopping_acknowledged = False
    for _ in range(int(REQUEST_TIMEOUT_SECONDS / 0.25)):
        if monitor.waitForAbort(0.25):
            return
        raw_result = window.getProperty(RESULT_PROPERTY)
        if raw_result:
            try:
                result = json.loads(raw_result)
            except ValueError:
                result = {}
            if result.get("request_id") == request_id:
                window.clearProperty(RESULT_PROPERTY)
                if result.get("code") != "stopping_for_update":
                    break
                stopping_acknowledged = True
        if stopping_acknowledged and window.getProperty(UPDATE_READY_PROPERTY) == request_id:
            window.clearProperty(UPDATE_READY_PROPERTY)
            xbmc.sleep(500)
            dialog.ok(
                addon.getLocalizedString(32000), addon.getLocalizedString(32056)
            )
            return

    dialog.ok(addon.getLocalizedString(32000), addon.getLocalizedString(32057))


def _delete_key(addon):
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(addon.getLocalizedString(32000), addon.getLocalizedString(32009)):
        return
    result = _request_service("stop")
    if result != "not_running" and not result.startswith("stopped:"):
        dialog.notification(
            addon.getLocalizedString(32000),
            addon.getLocalizedString(32026),
            xbmcgui.NOTIFICATION_ERROR,
        )
        return
    delete_api_key(_data_path(addon))
    dialog.notification(addon.getLocalizedString(32000), addon.getLocalizedString(32034))


def show_menu():
    addon = xbmcaddon.Addon()
    actions = [
        (32002, lambda: show_status()),
        (32007, lambda: _start(addon)),
        (32031, lambda: _stop(addon)),
        (32032, lambda: _save_key(addon)),
        (32033, lambda: _delete_key(addon)),
        (32058, lambda: _prepare_update(addon)),
    ]
    selected = xbmcgui.Dialog().select(
        addon.getLocalizedString(32000),
        [addon.getLocalizedString(string_id) for string_id, _ in actions],
    )
    if 0 <= selected < len(actions):
        actions[selected][1]()


if __name__ == "__main__":
    show_menu()
