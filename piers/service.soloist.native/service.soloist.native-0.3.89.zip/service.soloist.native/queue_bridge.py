"""Native Kodi neighbours and serialized Soloist controls for a live stream."""

import json
import queue
import re
import threading
import time
import uuid
from collections import deque
from urllib.parse import parse_qs, urlsplit

import xbmc
import xbmcgui

from audio import estimated_position_ms, kodi_music_item, music_item_revision

PREFIX = "service.soloist.native.queue."
REQUEST_PROPERTY = PREFIX + "request"
RESOLVE_TIMEOUT = 10.0
COMMAND_TIMEOUT = 7.0
SKIP_SETTLE_SECONDS = 0.5
MAX_FOLLOWUP_ACTIONS = 1
# Kodi's playlist shows one past row (for Kodi's Previous action) and up to ten
# upcoming rows. Older history is reachable only through repeated Previous.
MAX_PREVIOUS_ROWS = 1
MAX_UPCOMING_ROWS = 10
# A forward selection of two or more rows is one jump (Soloist has no
# skip-to-entry command): verify the route once, pause Soloist so Kodi's still
# open old reader hears no intermediate titles, send one skip_next per row as
# soon as the previous expected title is reported, then resume. Kodi waits in
# the resolver for the whole jump, so its wait grows by a bounded per-row budget.
MAX_JUMP_STEPS = MAX_UPCOMING_ROWS
JUMP_STEP_SECONDS = 3.0
MAX_RESOLVE_WAIT = RESOLVE_TIMEOUT + (MAX_JUMP_STEPS - 1) * JUMP_STEP_SECONDS
FAST_LOOP_SECONDS = 0.05
SLOW_LOOP_SECONDS = 0.25
MAX_PAYLOAD_BYTES = 262144
PLAYLIST_WINDOW_ID = 10500
PLAYLIST_WINDOW_CONDITIONS = (
    "Window.IsActive(10500)", "Window.IsVisible(10500)",
    "Window.IsActive(musicplaylist)", "Window.IsVisible(musicplaylist)",
)
TOKEN_PATTERN = re.compile(r"[0-9a-f]{32}")
URI_PATTERN = re.compile(r"spotify:(?:track|episode):[A-Za-z0-9]{22}")


def item_uri(item):
    uri = item.get("uri") if isinstance(item, dict) else None
    return uri if isinstance(uri, str) and URI_PATTERN.fullmatch(uri) else None


def item_title(item):
    decorations = item.get("decorations") if isinstance(item, dict) else None
    identity = decorations.get("identity") if isinstance(decorations, dict) else None
    title = identity.get("name") if isinstance(identity, dict) else None
    return " ".join(title.split())[:512] if isinstance(title, str) else ""


def neighbor(event, direction, current_uri):
    """Reject ambiguous URI occurrences: playback events do not expose queue UIDs."""
    if not isinstance(event, dict):
        return None
    entries = event.get("previous" if direction == "previous" else "upcoming")
    if not isinstance(entries, list) or not entries:
        return None
    entry = entries[0]
    if not isinstance(entry, dict) or not item_uri(entry.get("item")):
        return None
    uri = item_uri(entry["item"])
    decorations = entry["item"].get("decorations")
    identity = decorations.get("identity") if isinstance(decorations, dict) else None
    title = identity.get("name") if isinstance(identity, dict) else None
    if not isinstance(title, str) or not title.strip():
        return None
    uid = entry.get("uid") or uri
    if not isinstance(uid, str) or len(uid) > 1024 or uri == current_uri:
        return None
    all_entries = []
    for field in ("previous", "upcoming"):
        values = event.get(field)
        if not isinstance(values, list) or len(values) > 10:
            return None
        all_entries.extend(values)
    if sum(isinstance(value, dict) and item_uri(value.get("item")) == uri
           for value in all_entries) != 1:
        return None
    if sum(isinstance(value, dict) and (value.get("uid") or item_uri(value.get("item"))) == uid
           for value in all_entries) != 1:
        return None
    return {"uid": uid, "uri": uri, "item": entry["item"]}


def neighbors(event, direction, current_uri, limit=10):
    """Return consecutive unambiguous queue neighbours, nearest first."""
    if (not isinstance(event, dict) or direction not in ("previous", "upcoming")
            or isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0):
        return []
    limit = min(limit, 10)
    previous = event.get("previous")
    upcoming = event.get("upcoming")
    if (not isinstance(previous, list) or not isinstance(upcoming, list)
            or len(previous) > 10 or len(upcoming) > 10):
        return []

    entries = previous + upcoming
    uri_counts = {}
    uid_counts = {}
    normalized = {}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        item = entry.get("item")
        uri = item_uri(item)
        uid = entry.get("uid") or uri
        if uri is not None:
            uri_counts[uri] = uri_counts.get(uri, 0) + 1
        if isinstance(uid, str) and uid:
            uid_counts[uid] = uid_counts.get(uid, 0) + 1
        if (uri is not None and item_title(item) and isinstance(uid, str) and uid and len(uid) <= 1024):
            normalized[id(entry)] = {"uid": uid, "uri": uri, "item": item}

    result = []
    for entry in event[direction]:
        candidate = normalized.get(id(entry))
        if candidate is None:
            break
        uri = candidate["uri"]
        uid = candidate["uid"]
        if (uri == current_uri or uri_counts[uri] != 1 or uid_counts[uid] != 1):
            break
        result.append(candidate)
        if len(result) >= limit:
            break
    return result


def previous_gap_reason(event, current_uri, actions):
    """Name why no past row is shown, without titles, URIs or queue UIDs."""
    if isinstance(actions, dict) and actions.get("skip_prev") is False:
        return "Soloist erlaubt skip_prev nicht"
    if not isinstance(event, dict):
        return "keine Queue-Antwort"
    previous, upcoming = event.get("previous"), event.get("upcoming")
    if not isinstance(previous, list) or not isinstance(upcoming, list):
        return "Queue ohne previous/upcoming-Liste"
    if len(previous) > 10 or len(upcoming) > 10:
        return "Queue-Listen zu lang (previous={} upcoming={})".format(
            len(previous), len(upcoming))
    if not previous:
        return "Soloist liefert keine vorherigen Einträge (upcoming={})".format(len(upcoming))
    first = previous[0]
    if not isinstance(first, dict):
        return "erster previous-Eintrag ist kein Objekt"
    item = first.get("item")
    uri = item_uri(item)
    if uri is None:
        return "erster previous-Eintrag ohne Track-/Episoden-URI (source={})".format(
            first.get("source") if isinstance(first.get("source"), str) else "unbekannt")
    if not item_title(item):
        return "erster previous-Eintrag ohne Titel"
    if uri == current_uri:
        return "erster previous-Eintrag ist der aktuelle Titel"
    entries = [entry for entry in previous + upcoming if isinstance(entry, dict)]
    uri_count = sum(item_uri(entry.get("item")) == uri for entry in entries)
    uid = first.get("uid") or uri
    uid_count = sum((entry.get("uid") or item_uri(entry.get("item"))) == uid for entry in entries)
    if uri_count != 1 or uid_count != 1:
        return "erster previous-Eintrag mehrdeutig (URI {}x, UID {}x)".format(uri_count, uid_count)
    return "unbekannt (previous={})".format(len(previous))


def result_key(operation):
    return PREFIX + operation + ".result"


def registry_data(raw):
    """A slot URL is stable; each published target has an immutable revision."""
    if not raw or len(raw) > 512:
        raise ValueError("Missing slot grant")
    value = json.loads(raw)
    if (not isinstance(value, dict) or set(value) != {"session", "revision"}
            or not isinstance(value["session"], str)
            or not TOKEN_PATTERN.fullmatch(value["session"])
            or isinstance(value["revision"], bool) or not isinstance(value["revision"], int)
            or not 1 <= value["revision"] <= 2147483647):
        raise ValueError("Invalid slot grant")
    return value


class SoloistQueueBridge:
    """Serialize Soloist controls independently of Kodi's live reader opens.

    Slots express relative Next/Previous against Soloist's fresh queue, not an
    atomic absolute URI-play API. Resolve changed media only after Soloist confirms
    the resulting playback; a slot label alone never proves that a song plays.
    Never reorder the playlist while a reader or a control is starting.
    """

    def __init__(self, websocket, player_state, logger, notify_failure, artist_mbids,
                 notify_busy=None, artist_fanart=None, adopt_stream=None,
                 notify_unavailable=None):
        self.websocket = websocket
        self.state = player_state
        self.log = logger
        self.notify_failure = notify_failure
        self.notify_busy = notify_busy or (lambda: None)
        self.last_busy_notice = float("-inf")
        self.artist_mbids = artist_mbids
        self.artist_fanart = artist_fanart or (lambda item, mbids: "")
        # Service hook: take over the live stream for a row Kodi opens itself
        # after a selection made while Kodi was stopped (no Player.Open).
        self.adopt_stream = adopt_stream or (lambda: None)
        self.notify_unavailable = notify_unavailable or notify_failure
        self.last_unavailable_notice = float("-inf")
        self.playlist_released = False
        self.window = xbmcgui.Window(10000)
        self.session = uuid.uuid4().hex
        self.entries = {}
        self.paths = []
        self.current_path = None
        self.queue = None
        self.queue_uri = None
        self.dirty = False
        self.pending = None
        self.resolver_waiter = None
        self.next_action_at = 0.0
        self.controls_blocked_at = None
        self.controls_blocked_cursor = None
        self.controls_probe_at = 0.0
        self.controls_probe_attempts = 0
        self.actions = deque()
        self.disabled = False
        self.orphaned_reader = False
        self.last_poll = 0.0
        self.requested_at = None
        self.mutation = None
        self.generation = websocket.control_generation()
        self.callbacks = queue.Queue(maxsize=32)
        self.callback_overflow = threading.Event()
        self.queue_attempts = 0
        self.observed_uri = item_uri((player_state.get("playback") or {}).get("item"))
        self.revision = 0
        self.finished_operations = deque(maxlen=32)
        self.native_commands = deque(maxlen=32)
        self.resolved_starts = deque(maxlen=32)
        self.cached_candidate = None
        self.ambiguous_starts = False
        self.reader_deadline = None
        self.last_verified_context = None
        self.unexpected_end = False
        self.last_selection_at = 0.0
        self.last_previous_gap = None
        # token -> revision last written into the Kodi row. Rewriting an
        # unchanged row makes skins flicker (art/label briefly incomplete).
        self.tagged = {}
        self.rows_retagged = 0
        # Inserted rows waiting for one window refresh once the playlist is
        # complete; refreshing after every insert made covers flicker 10x.
        self.rows_inserted_pending = 0
        self.jump = None

    def accept_result(self, command):
        now = time.monotonic()
        while self.native_commands and now - self.native_commands[0][1] > COMMAND_TIMEOUT + 2:
            self.native_commands.popleft()
        for index, (name, _) in enumerate(self.native_commands):
            if name == command:
                del self.native_commands[index]
                return True
        return False

    def callback(self, name, detail=None):
        # Callbacks have no immutable item/reader identity. Do not read GUI state
        # here: Kodi may be synchronously waiting for a plugin resolver.
        try:
            self.callbacks.put_nowait((name, detail))
        except queue.Full:
            self.callback_overflow.set()

    def _drain_callbacks(self):
        if self.callback_overflow.is_set():
            self.callback_overflow.clear()
            self.cancel("Kodi-Callbackverlust", notify=True)
            self.ambiguous_starts = True
        while True:
            try:
                name, detail = self.callbacks.get_nowait()
            except queue.Empty:
                return
            if name == "av_started":
                self.av_started(detail)
            elif name == "started":
                if not self.state.get("owned"):
                    self._release_navigation("Fremder Kodi-Start")
                    continue
                if self.cached_candidate is not None and self.cached_candidate != detail:
                    self.ambiguous_starts = True
                self.cached_candidate = detail
                if not self.orphaned_reader:
                    self.reader_deadline = time.monotonic() + RESOLVE_TIMEOUT
            elif name == "ended":
                if self.expected_end():
                    self.log("Native Queue: altes Streamende während Leserwechsel.")
                else:
                    self.unexpected_end = True
                    self.cancel("Kodi-Stream beendet")
                    detail()
            else:
                if self.jump:
                    # A deliberate Kodi stop/pause wins: do not resume Spotify.
                    self.jump["paused_by_us"] = False
                if detail == "Kodi-Stopp" and self.last_verified_context:
                    position, count, observed_at = self.last_verified_context
                    self.log("Native Queue: Kodi-Stopp; letzter Index={} von {} vor={:.0f}ms; "
                             "Auslöser nicht aus Callback ableitbar.".format(
                                 position, count, (time.monotonic() - observed_at) * 1000))
                self.cancel(detail)
                self.reader_deadline = None
                self.cached_candidate = None

    def busy(self):
        return bool(self.pending or self.actions or self.jump or self.resolver_waiter
                    or self.reader_deadline
                    or time.monotonic() < self.next_action_at
                    or self._request_value())

    def metadata_busy(self):
        # Confirming a Spotify command must not freeze actual current metadata.
        return bool(not self.state.get("av_ready") or self.reader_deadline
                    or self.cached_candidate is not None or not self.callbacks.empty()
                    or self._request_value())

    def _request_value(self):
        # Kodi Window getters also acquire the graphics lock; RPC timings alone
        # cannot identify a stalled request poll while VideoPlayer opens media.
        started = time.monotonic()
        try:
            return self.window.getProperty(REQUEST_PROPERTY)
        finally:
            elapsed_ms = (time.monotonic() - started) * 1000
            if elapsed_ms >= 100:
                self.log("Native Queue: langsame Fenster-Anforderungsabfrage: {:.1f}ms.".format(
                    elapsed_ms))

    def _rpc(self, method, **params):
        started = time.monotonic()
        try:
            response = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": method, "params": params,
            })))
        finally:
            elapsed_ms = (time.monotonic() - started) * 1000
            if elapsed_ms >= 100:
                self.log("Native Queue: langsame Kodi-RPC {}: {:.1f}ms.".format(
                    method, elapsed_ms))
        if not isinstance(response, dict) or "error" in response or "result" not in response:
            raise RuntimeError("Kodi queue request rejected: " + method)
        return response["result"]

    def _owned_source(self, require_av=True):
        player = self.state["player"]
        try:
            return bool(self.state.get("owned") and (self.state.get("av_ready") or not require_av)
                        and player.isPlaying()
                        and player.getPlayingFile() == self.state.get("playback_url"))
        except RuntimeError:
            return False  # A reader can disappear between these two public calls.

    def _context(self, require_current=True, require_av=True):
        if self._request_value() or not self._owned_source(require_av):
            return None
        players = self._rpc("Player.GetActivePlayers")
        active = [entry for entry in players if entry.get("type") == "audio"]
        if len(active) != 1:
            return None
        properties = self._rpc("Player.GetProperties", playerid=active[0]["playerid"],
                               properties=["playlistid", "position", "shuffled", "repeat"])
        if (properties.get("playlistid") != 0 or properties.get("shuffled") is not False
                or properties.get("repeat") != "off"):
            return None
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        count = playlist.size()
        if not 1 <= count <= 21:
            return None
        paths = [playlist[index].getPath() for index in range(count)]
        position = properties.get("position")
        if (isinstance(position, bool) or not isinstance(position, int)
                or not 0 <= position < len(paths) or len(set(paths)) != len(paths)):
            return None
        if paths != (self.paths or [self.state.get("metadata_item_path")]):
            return None
        if require_current and paths[position] != self.state.get("metadata_item_path"):
            return None
        self.last_verified_context = (position, len(paths), time.monotonic())
        return playlist, paths, position

    def _read_request(self):
        raw = self._request_value()
        if not raw:
            return None
        try:
            if len(raw) > 512:
                raise ValueError("oversized navigation request")
            request = json.loads(raw)
            if (not isinstance(request, dict)
                    or set(request) != {"operation", "entry", "session", "revision"}
                    or any(not isinstance(request[field], str)
                           or not TOKEN_PATTERN.fullmatch(request[field])
                           for field in ("operation", "entry", "session"))
                    or isinstance(request["revision"], bool)
                    or not isinstance(request["revision"], int)
                    or not 1 <= request["revision"] <= 2147483647):
                raise ValueError("invalid navigation request")
            return request
        except (ValueError, TypeError):
            self.window.clearProperty(REQUEST_PROPERTY)
            return None

    def _reply(self, request, payload):
        if request is not None and self._read_request() == request:
            self.window.setProperty(result_key(request["operation"]), json.dumps(payload))
            if request["operation"] not in self.finished_operations:
                self.finished_operations.append(request["operation"])

    def _active(self):
        playback = self.state.get("playback") or {}
        return bool(self.state.get("owned") and self.websocket.is_connected()
                    and playback.get("status") in ("playing", "buffering")
                    and playback.get("is_active") is True and item_uri(playback.get("item")))

    def _adopt(self, path):
        self.current_path = path
        self.state["metadata_item_path"] = path
        self.state["applied_info_tag_revision"] = None
        self.state["pending_info_tag"] = None
        self.state["pending_audio_recovery"] = None
        self.last_selection_at = time.monotonic()

    def _actual_payload(self):
        item = (self.state.get("playback") or {}).get("item")
        mbids = self.artist_mbids(item)
        payload = {"ok": True, "url": self.state["playback_url"], "item": item,
                   "artist_mbids": mbids, "artist_fanart": self.artist_fanart(item, mbids)}
        if len(json.dumps(payload).encode("utf-8")) > MAX_PAYLOAD_BYTES:
            raise ValueError("Queue metadata too large")
        return payload

    def _reject_unservable(self, request):
        """A row that cannot be served at all: stop Kodi's skip cascade at once.

        Kodi treats the rejected row as unplayable and resolves every
        following row; revoking all grants makes those fail without waiting.
        """
        self._reply(request, {"ok": False})
        for token in self.entries:
            self.window.clearProperty(PREFIX + token)
        self.dirty = True  # The next own sync republishes valid grants.
        now = time.monotonic()
        if now - self.last_unavailable_notice >= 5.0:
            self.last_unavailable_notice = now
            self.notify_unavailable()
        self.log("Native Queue: Auswahl nicht bedienbar (Soloist nicht aktiv, Sitzung oder "
                 "Verbindung fehlt); alle Einträge widerrufen, Kodi-Fehlerkette beendet.")

    def _release_ended_session(self):
        """Remove our rows once Spotify no longer plays on this device.

        Only when Kodi plays nothing and every row in the music playlist is
        ours; a paused session keeps its rows for stopped-state selection.
        """
        playback = self.state.get("playback") or {}
        ended = (playback.get("is_active") is False
                 or (self.websocket.is_connected() and playback.get("status") == "idle"))
        if not ended:
            self.playlist_released = False
            return
        if (self.playlist_released or self.state.get("owned") or self.busy()
                or not self.paths):
            return
        try:
            if self.state["player"].isPlaying():
                return
            playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
            paths = [playlist[index].getPath() for index in range(playlist.size())]
        except RuntimeError:
            return
        self.playlist_released = True
        if not paths or any(not path.startswith("plugin://service.soloist.native/")
                            for path in paths):
            return  # Never touch a playlist that holds other media.
        playlist.clear()
        self.close()
        self.paths = []
        self.current_path = None
        self.mutation = None
        self.log("Native Queue: Spotify spielt nicht mehr auf diesem Gerät; "
                 "eigene Playlist-Einträge entfernt.")
        # PlayList.clear does not notify an open playlist window either.
        self._refresh_playlist_window("Playlist geleert")

    def _stopped_selection(self, path, request):
        """Serve a row chosen while Kodi is stopped and Soloist is paused."""
        playback = self.state.get("playback") or {}
        if (self.state.get("owned") or not self.websocket.is_connected()
                or playback.get("status") != "paused" or playback.get("is_active") is not True
                or self.jump or self.pending or self.actions
                or path not in self.paths or self.current_path not in self.paths):
            return False
        offset = self.paths.index(path) - self.paths.index(self.current_path)
        entry = next((value for value in self.entries.values() if value.get("path") == path), {})
        target = entry.get("uri")
        if not target or offset < -1 or offset > MAX_JUMP_STEPS:
            return False
        direction = "next" if offset > 0 else "previous" if offset < 0 else "current"
        self._adopt(path)
        self.log("Native Queue: Auswahl bei gestoppter Wiedergabe Richtung={} Schritte={}.".format(
            direction, abs(offset)))
        self._start_jump(target, abs(offset), direction=direction, stopped=True)
        if not self.jump:
            return True  # Already answered/cancelled by the failure path.
        self.resolver_waiter = {
            "request": request, "path": path, "fallback": None, "remaining": 1,
            "deadline": (time.monotonic() + RESOLVE_TIMEOUT - 1.0
                         + max(0, abs(offset) - 1) * JUMP_STEP_SECONDS),
        }
        return True

    def _select(self, path, request=None):
        if self.controls_blocked_at is not None:
            now = time.monotonic()
            if now - self.controls_probe_at >= 5.0 and self.controls_probe_attempts < 3:
                self.controls_probe_at = now
                self.controls_probe_attempts += 1
                self.websocket.send_command("get_state")
            self._adopt(path)
            if time.monotonic() - self.last_busy_notice >= 1.0:
                self.last_busy_notice = time.monotonic()
                self.notify_failure()
            self.log("Native Queue: Steuerung gesperrt, frischer Soloist-Status fehlt.")
            return 0
        # During a posted Insert/Remove, native positions may already differ.
        # A grant may still be interpreted when the selected/current pair has
        # the same unique relative position in both snapshots. This uses only
        # the snapshots already recorded by the mutation; do not read Kodi here.
        if self.mutation:
            before = self.mutation.get("before")
            after = self.mutation.get("after")
            deadline = self.mutation.get("deadline")
            stable_pair = (
                isinstance(before, list) and isinstance(after, list)
                and all(isinstance(value, str) for value in before + after)
                and len(set(before)) == len(before)
                and len(set(after)) == len(after)
                and path in before and path in after
                and self.current_path in before and self.current_path in after
                and isinstance(deadline, (int, float))
                and time.monotonic() < deadline
            )
            if stable_pair:
                before_distance = before.index(path) - before.index(self.current_path)
                after_distance = after.index(path) - after.index(self.current_path)
                stable_pair = before_distance == after_distance
            if not stable_pair:
                allowed_before = before if isinstance(before, list) else []
                allowed_after = after if isinstance(after, list) else []
                allowed = allowed_before + allowed_after
                if path in allowed and self.current_path in allowed:
                    self._adopt(path)
                self.notify_failure()
                self.log("Native Queue: Auswahl während Playlist-Änderung abgelehnt; "
                         "Mutationspaar nicht eindeutig, nicht stabil oder abgelaufen.")
                return 0
            selected, old = after.index(path), after.index(self.current_path)
        else:
            if path not in self.paths or self.current_path not in self.paths:
                self.notify_failure()
                self.log("Native Queue: Auswahl abgelehnt; ausgewählter oder aktueller "
                         "Slot fehlt im bestätigten Playlistzustand.")
                return 0
            selected, old = self.paths.index(path), self.paths.index(self.current_path)
        direction = "previous" if selected < old else "next" if selected > old else "current"
        steps = abs(selected - old)
        if self.unexpected_end:
            self.unexpected_end = False
            steps = 0
            self.notify_failure()
        jump_target = None
        if (direction == "next" and steps > 1 and not self.actions and not self.pending
                and not self.jump):
            # One deliberate playlist selection, not a burst of key presses.
            jump_target = next((entry.get("uri") for entry in self.entries.values()
                                if entry.get("path") == path), None)
        if jump_target is not None and steps <= MAX_JUMP_STEPS:
            self._adopt(path)
            self.log("Native Queue: Auswahl Richtung=next Schritte={} (Sprung mit Pause); "
                     "Kodi-Leser und Soloist-Bestätigung getrennt.".format(steps))
            self._start_jump(jump_target, steps)
            return steps if self.jump else 0
        capacity = MAX_FOLLOWUP_ACTIONS + 1 - len(self.actions) - bool(self.pending)
        accepted = 0 if self.jump else min(steps, max(0, capacity))
        if accepted < steps:
            if time.monotonic() - self.last_busy_notice >= 1.0:
                self.last_busy_notice = time.monotonic()
                self.notify_busy()
            self.log("Native Queue: weitere schnelle Auswahl begrenzt; "
                     "höchstens eine Folgeaktion wird vorgemerkt.")
        self._adopt(path)
        self.actions.extend([direction] * accepted)
        self.log("Native Queue: Auswahl Richtung={} Schritte={} angenommen={} wartend={}; "
                 "Kodi-Leser und Soloist-Bestätigung getrennt.".format(
                     direction, steps, accepted, len(self.actions)))
        return accepted

    def _answer_waiter(self, confirmed, fallback_payload=None):
        waiter = self.resolver_waiter
        if waiter is None:
            return
        self.resolver_waiter = None
        request = waiter["request"]
        if self._read_request() != request:
            return
        self._adopt(waiter["path"])
        payload = fallback_payload if fallback_payload is not None else self._actual_payload()
        self.resolved_starts.append((waiter["path"], time.monotonic()))
        self.state["av_ready"] = False
        self.reader_deadline = time.monotonic() + RESOLVE_TIMEOUT
        self._reply(request, payload)
        self.log("Native Queue: Resolver freigegeben; {}.".format(
            "Soloist-Ziel und Wiedergabe bestätigt" if confirmed else
            "keine Zielbestätigung, zuletzt bestätigte Metadaten bleiben erhalten"))

    def _control_failed(self, reason):
        if self.pending and reason.startswith("Zeitlimit"):
            self.controls_blocked_at = time.monotonic()
            self.controls_blocked_cursor = self._event_cursor()
            self.controls_probe_at = self.controls_blocked_at
            self.controls_probe_attempts = 1
        # Report failure honestly, but do not turn an unchanged valid live
        # source into an unplayable row and Kodi's automatic skip cascade.
        if self.resolver_waiter and self._active():
            self._answer_waiter(confirmed=False, fallback_payload=self.resolver_waiter["fallback"])
        self.cancel(reason, notify=True)

    def _observe_cached_start(self):
        generation = self.cached_candidate
        if self.orphaned_reader:
            self.cached_candidate = None
            return
        if generation is None or self._request_value():
            return
        if generation != self.state.get("source_generation", 0):
            self.cached_candidate = None
            return
        if not self.paths or not self.current_path:
            self.cached_candidate = None
            return
        # Started does not imply Player.GetActivePlayers/GetProperties are ready.
        # Retry a transient read until the bounded reader deadline. Never Swap.
        if self.mutation and not self._settle_mutation(require_av=False):
            return
        started = time.monotonic()
        try:
            context = self._context(require_current=False, require_av=False)
        except RuntimeError:
            return
        finally:
            elapsed_ms = (time.monotonic() - started) * 1000
            if elapsed_ms >= 100:
                self.log("Native Queue: langsame Cache-Kontextprüfung: {:.1f}ms; "
                         "enthält Quellen-, RPC- und Playlist-Lesezugriffe.".format(elapsed_ms))
        if context is None:
            return
        _, paths, position = context
        path = paths[position]
        self.cached_candidate = None
        expected = next((index for index, (value, _) in enumerate(self.resolved_starts)
                         if value == path), None)
        if expected is not None:
            for _ in range(expected + 1):
                self.resolved_starts.popleft()
            # The resolver already recorded the intent. Bind metadata to the
            # reader actually observed, even if another open was queued later.
            self._adopt(path)
            if self.ambiguous_starts:
                self.notify_failure()
                self.log("Native Queue: Resolver-Echo nach mehreren Started-Ereignissen; "
                         "Zwischenaktionen nicht eindeutig, kein zusätzlicher Skip.")
            self.ambiguous_starts = False
            return
        if self.ambiguous_starts:
            self.ambiguous_starts = False
            self._adopt(path)
            self.notify_failure()
            self.log("Native Queue: mehrere Started-Ereignisse ohne eindeutige Zwischenposition; "
                     "keine Richtungsfolge erfunden.")
            return
        if self._active() and not self.disabled:
            self._select(path)
            self._begin_action()

    def _sync_session_path(self):
        path = self.state.get("metadata_item_path")
        if (not self.state.get("owned") or not path
                or path == self.current_path or path in self.paths):
            return
        if self._request_value():
            return
        source = urlsplit(path)
        if source.scheme != "plugin" or source.netloc != "service.soloist.native":
            return
        self._slot_token(path)
        deadline = self.reader_deadline
        self.close()  # Revoke only our previous session, never touch audio.
        self.session = uuid.uuid4().hex
        self.current_path = path
        self.paths = []
        self.disabled = False
        self.queue = None
        self.queue_uri = None
        self.requested_at = None
        self.queue_attempts = 0
        self.mutation = None
        self.dirty = True
        self.reader_deadline = deadline

    def _release_navigation(self, reason):
        self.cancel(reason)
        self.reader_deadline = None
        self.cached_candidate = None
        self.resolved_starts.clear()
        self.ambiguous_starts = False

    def poll_request(self, accept=True):
        self._drain_callbacks()
        self._sync_session_path()
        if not self._request_value():
            self._release_ended_session()
        # A fresh request alone is not navigation state: it may be a row chosen
        # while Kodi is stopped, which _stopped_selection serves below.
        stopped_jump = bool(self.jump and self.jump.get("stopped"))
        if (not self.state.get("owned") and not stopped_jump
                and (self.pending or self.actions or self.resolver_waiter
                     or self.reader_deadline or self.jump)):
            self._release_navigation("Kodi-Quelle nicht mehr im Add-on-Besitz")
        elif self.busy() and not self._request_value():
            try:
                player = self.state["player"]
                source = player.getPlayingFile() if player.isPlaying() else None
            except RuntimeError:
                source = None
            if source and source != self.state.get("playback_url"):
                self._release_navigation("Fremde Kodi-Quelle vor AV-Bestätigung")
        generation = self.websocket.control_generation()
        if generation != self.generation:
            self.generation = generation
            self.native_commands.clear()
            self.cancel("Verbindungswechsel oder Ereignisverlust")
            self.cached_candidate = None
            self.resolved_starts.clear()
        if (self.pending or self.actions) and not self._active():
            self.cancel("Steuerverbindung oder Soloist nicht aktiv")
        request = self._read_request()
        waiting_jump = bool(self.jump and self.resolver_waiter
                            and self.resolver_waiter["request"] == request)
        if (request and accept and request["operation"] not in self.finished_operations
                and not waiting_jump):
            # Our own jump pauses Soloist; that must not reject the request
            # whose resolver is deliberately waiting for the jump target.
            entry = self.entries.get(request["entry"])
            stopped = (entry and not self.disabled and request["session"] == self.session
                       and self.resolver_waiter is None
                       and request["revision"] == entry["revision"]
                       and self._stopped_selection(entry["path"], request))
            if stopped:
                pass
            elif (self.disabled or not entry or request["session"] != self.session
                    or not self._active()):
                self._reject_unservable(request)
            else:
                if self.resolver_waiter is None:
                    accepted = 0
                    if request["revision"] == entry["revision"]:
                        accepted = self._select(entry["path"], request)
                    else:
                        self._adopt(entry["path"])
                        self.notify_failure()
                        self.log("Native Queue: Auswahl abgelehnt; Revision stimmt nicht "
                                 "mit dem aktuellen Slot überein.")
                    extra_steps = max(0, self.jump["steps"] - 1) if self.jump else 0
                    self.resolver_waiter = {
                        "request": request, "path": entry["path"],
                        "fallback": self._actual_payload(),
                        "remaining": (1 if self.jump else len(self.actions) + bool(self.pending))
                                     if accepted else 0,
                        "deadline": (time.monotonic() + RESOLVE_TIMEOUT - 1.0
                                     + extra_steps * JUMP_STEP_SECONDS),
                    }
                    # WS only while Kodi waits in its resolver. No player or
                    # playlist read is allowed to delay these status requests.
                    self._begin_action()
                    if not accepted:
                        self._answer_waiter(confirmed=False)
                elif self.resolver_waiter["request"] != request:
                    self.cancel("Resolveranforderung inzwischen ersetzt", notify=True)
        elif request and request["operation"] in self.finished_operations:
            if not self.window.getProperty(result_key(request["operation"])):
                self._reply(request, {"ok": False})
        if self.resolver_waiter and self._read_request() != self.resolver_waiter["request"]:
            self.cancel("Wartender Resolver beendet")
        self._begin_action()  # WS only, including a follow-up while the resolver waits.
        if not self._request_value():
            self._observe_cached_start()
        if self.jump and time.monotonic() >= self.jump["deadline"]:
            self._jump_failed("Zeitlimit im Sprung ({})".format(self.jump["phase"]))
        if self.pending and time.monotonic() >= self.pending["deadline"]:
            phase = ("frischen Status-/Queueantwort" if self.pending["phase"] == "checking"
                     else "Skip-Zielbestätigung")
            self._control_failed("Zeitlimit der " + phase)
        if self.resolver_waiter and time.monotonic() >= self.resolver_waiter["deadline"]:
            self._control_failed("Zeitlimit der wartenden Medienfreigabe")
        if self.reader_deadline and time.monotonic() >= self.reader_deadline:
            self.reader_deadline = None
            self.cached_candidate = None
            self.resolved_starts.clear()
            self.cancel("Kodi-AV-Start nicht bestätigt", notify=True)
            self.state["kodi_error_reconnect_requested_at"] = time.monotonic()
            self.state["kodi_error_state_confirmed"] = False
            self.state["kodi_error_state_request_at"] = None
            self.state["kodi_error_state_request_attempts"] = 0
        while self.resolved_starts and time.monotonic() - self.resolved_starts[0][1] > RESOLVE_TIMEOUT:
            self.resolved_starts.popleft()

    def _event_cursor(self):
        cursor = getattr(self.websocket, "event_cursor", None)
        return cursor() if callable(cursor) else None

    def _fresh(self, event):
        cursor = self.pending.get("after_sequence")
        sequence = event.get("_soloist_event_sequence")
        return cursor is None or (isinstance(sequence, int) and not isinstance(sequence, bool)
                                  and sequence > cursor)

    def _begin_action(self):
        if (self.pending or self.jump or not self.actions or not self._active()
                or self.controls_blocked_at is not None
                or time.monotonic() < self.next_action_at):
            return
        direction = self.actions.popleft()
        self.pending = {"direction": direction, "phase": "checking", "state_seen": False,
                        "queue_seen": None, "deadline": time.monotonic() + COMMAND_TIMEOUT,
                        "after_sequence": self._event_cursor()}
        if not (self.websocket.send_command("get_state")
                and self.websocket.send_command("get_queue", limit=10)):
            self._control_failed("Steuerverbindung fehlt")

    def _send_if_checked(self):
        pending = self.pending
        if (not pending or pending["phase"] != "checking" or not pending["state_seen"]
                or pending["queue_seen"] is None):
            return
        if not self._active() or self.websocket.control_generation() != self.generation:
            self.cancel("Quelle oder Verbindung inzwischen beendet")
            return
        playback = self.state["playback"]
        current = item_uri(playback.get("item"))
        if pending.get("checked_current") != current or pending.get("queue_current") != current:
            if pending.get("rechecks", 0) >= 1:
                self._control_failed("Status und Queue gehören nicht zum selben Titel")
                return
            pending.update(state_seen=False, queue_seen=None, rechecks=1,
                           after_sequence=self._event_cursor())
            if not (self.websocket.send_command("get_state")
                    and self.websocket.send_command("get_queue", limit=10)):
                self._control_failed("Erneute Statusprüfung nicht möglich")
            return
        target = neighbor(pending["queue_seen"], pending["direction"], current)
        command = "skip_prev" if pending["direction"] == "previous" else "skip_next"
        actions = playback.get("available_actions")
        if not target or (isinstance(actions, dict) and actions.get(command) is False):
            self._control_failed("Kein bestätigter Nachbar oder Aktion nicht erlaubt")
            return
        pending.update(current=current, target=target["uri"], after_sequence=self._event_cursor(),
                       before_position=estimated_position_ms(playback.get("position")),
                       sent_at_ms=time.time() * 1000)
        if not self.websocket.send_command(command):
            self._control_failed("Skip nicht vorgemerkt")
            return
        self.native_commands.append((command, time.monotonic()))
        pending.update(command=command, phase="waiting", deadline=time.monotonic() + COMMAND_TIMEOUT)
        self.log("Native Queue: {} einmalig vorgemerkt; Position_vorher_geschätzt={}ms "
                 "Folgeaktionen={}; AV-Start wird nicht abgewartet.".format(
                     command, pending["before_position"], len(self.actions)))

    def _confirmed(self, restart=False):
        if self.resolver_waiter and not item_title((self.state.get("playback") or {}).get("item")):
            return  # Do not release an item that the music resolver cannot display.
        self.log("Native Queue: Soloist {} bestätigt; Folgeaktionen={}.".format(
            "Titelneustart" if restart else "Zieltitel", len(self.actions)))
        self.pending = None
        self.dirty = True
        self.next_action_at = time.monotonic() + SKIP_SETTLE_SECONDS
        if self.resolver_waiter:
            self.resolver_waiter["remaining"] -= 1
            if self.resolver_waiter["remaining"] <= 0:
                self._answer_waiter(confirmed=True)

    def loop_interval(self):
        """Poll faster only while a jump waits for Soloist's per-row reports."""
        return FAST_LOOP_SECONDS if self.jump else SLOW_LOOP_SECONDS

    def _start_jump(self, target, steps, direction="next", stopped=False):
        self.jump = {"target": target, "steps": steps, "phase": "checking",
                     "direction": direction, "stopped": stopped,
                     "command": "skip_prev" if direction == "previous" else "skip_next",
                     "state_seen": False, "queue_seen": None, "route": None, "index": 0,
                     "paused_by_us": False, "after_sequence": self._event_cursor(),
                     "started_at": time.monotonic(),
                     "deadline": time.monotonic() + COMMAND_TIMEOUT}
        if not (self.websocket.send_command("get_state")
                and self.websocket.send_command("get_queue", limit=MAX_UPCOMING_ROWS)):
            self._jump_failed("Steuerverbindung fehlt")

    def _jump_fresh(self, event):
        cursor = self.jump.get("after_sequence")
        sequence = event.get("_soloist_event_sequence")
        return cursor is None or (isinstance(sequence, int) and not isinstance(sequence, bool)
                                  and sequence > cursor)

    def _jump_send(self, command, phase, **fields):
        jump = self.jump
        if not self.websocket.send_command(command, **fields):
            self._jump_failed("{} nicht vorgemerkt".format(command))
            return False
        if command != "get_state":
            self.native_commands.append((command, time.monotonic()))
        jump.update(phase=phase, deadline=time.monotonic() + COMMAND_TIMEOUT,
                    after_sequence=self._event_cursor())
        return True

    def _jump_failed(self, reason):
        jump = self.jump
        self.log("Native Queue: Sprung abgebrochen ({}); kein Skip wiederholt.".format(reason))
        waiter = self.resolver_waiter
        if jump and jump.get("stopped"):
            # Nothing plays in Kodi: revoke every row so Kodi's automatic
            # "skip unplayable item" cascade ends at once instead of resolving
            # each remaining row against Soloist.
            for token in self.entries:
                self.window.clearProperty(PREFIX + token)
            self.jump = None
            self.cancel(reason, notify=True)
            return
        # The live stream stays valid; answer with what Soloist actually plays
        # instead of an unplayable row that would start Kodi's skip cascade.
        if waiter and self.websocket.is_connected():
            if jump and jump.get("paused_by_us"):
                self.websocket.send_command("play")
                jump["paused_by_us"] = False
            self.jump = None
            self._answer_waiter(confirmed=False)
        self.cancel(reason, notify=True)

    def _jump_event(self, event, playback, current, kind):
        jump = self.jump
        status = playback.get("status")
        if kind == "auth_state" and not event.get("logged_in"):
            self._jump_failed("Soloist abgemeldet")
            return
        if playback.get("is_active") is False:
            self._jump_failed("Spotify spielt auf einem anderen Gerät")
            return
        phase = jump["phase"]
        if phase == "checking":
            if not self._jump_fresh(event):
                return
            if kind == "playback_state":
                jump["state_seen"] = True
                jump["checked_current"] = current
            elif kind == "queue_changed":
                jump["queue_seen"] = event
                jump["queue_current"] = current
            if not jump["state_seen"] or jump["queue_seen"] is None:
                return
            if jump["checked_current"] != current or jump["queue_current"] != current:
                self._jump_failed("Status und Queue gehören nicht zum selben Titel")
                return
            actions = playback.get("available_actions")
            if isinstance(actions, dict) and actions.get(jump["command"]) is False:
                self._jump_failed("Aktion von Soloist nicht erlaubt")
                return
            if jump["direction"] == "current":
                route = [] if jump["target"] == current else None
            elif jump["direction"] == "previous":
                behind = neighbors(jump["queue_seen"], "previous", current, limit=1)
                route = [jump["target"]] if behind and behind[0]["uri"] == jump["target"] else None
            else:
                ahead = neighbors(jump["queue_seen"], "upcoming", current, limit=MAX_JUMP_STEPS)
                route = ([entry["uri"] for entry in ahead[:jump["steps"]]]
                         if len(ahead) >= jump["steps"]
                         and ahead[jump["steps"] - 1]["uri"] == jump["target"] else None)
            if route is None:
                self._jump_failed("Sprungziel nicht mehr an erwarteter Queueposition")
                return
            jump.update(route=route, origin=current)
            if not route:
                if status == "playing":
                    self._jump_done(playback, kind)
                else:
                    self._jump_send("play", "resuming")
            elif jump["direction"] == "previous":
                # Rewind first so Spotify's 3-second rule cannot turn the
                # selection into a restart of the paused title.
                self._jump_send("seek", "rewinding", position_ms=0)
            elif status == "paused":
                self._jump_send("skip_next", "skipping")
            elif self._jump_send("pause", "pausing"):
                jump["paused_by_us"] = True
            return
        if phase == "rewinding":
            position = estimated_position_ms(playback.get("position"))
            if (kind == "position_sync" and self._jump_fresh(event)
                    and isinstance(position, (int, float)) and not isinstance(position, bool)
                    and 0 <= position <= 1500):
                self._jump_send("skip_prev", "skipping")
            return
        if phase == "pausing":
            if status == "paused":
                self._jump_send(jump["command"], "skipping")
            return
        route, index = jump["route"], jump["index"]
        if phase == "skipping":
            expected = route[index]
            if current == expected:
                jump["index"] = index = index + 1
                if index < len(route):
                    self._jump_send(jump["command"], "skipping")
                elif status == "playing":
                    self._jump_done(playback, kind)
                else:
                    self._jump_send("play", "resuming")
                    jump["paused_by_us"] = False
            elif current not in (expected, route[index - 1] if index else jump["origin"]):
                self._jump_failed("Anderer Titel gestartet")
            return
        if phase == "resuming":
            if current != jump["target"]:
                self._jump_failed("Anderer Titel beim Fortsetzen")
            elif status == "playing":
                self._jump_done(playback, kind)

    def _jump_done(self, playback, kind):
        jump, self.jump = self.jump, None
        self.dirty = True
        self.next_action_at = time.monotonic() + SKIP_SETTLE_SECONDS
        self.log("Native Queue: {} über {} Titel abgeschlossen in {:.0f}ms{}.".format(
            "Sprung" if jump["direction"] == "next" else "Auswahl " + jump["direction"],
            jump["steps"], (time.monotonic() - jump["started_at"]) * 1000,
            " (aus gestoppter Wiedergabe)" if jump["stopped"] else ""))
        if self.resolver_waiter and item_title(playback.get("item")):
            if jump["stopped"]:
                self.adopt_stream()
            self._answer_waiter(confirmed=True)

    def handle_event(self, event):
        playback = self.state.get("playback") or {}
        current = item_uri(playback.get("item"))
        kind = event.get("type")
        if self.jump:
            if kind == "queue_changed":
                self.queue = event
                self.queue_uri = current
                self.dirty = True
            self._jump_event(event, playback, current, kind)
            # The service must neither stop Kodi on our own pause nor retag
            # intermediate titles while Kodi waits for the jump target.
            return True
        if kind == "playback_state" and self.controls_blocked_at is not None:
            sequence = event.get("_soloist_event_sequence")
            if (self.controls_blocked_cursor is None
                    or (isinstance(sequence, int) and not isinstance(sequence, bool)
                        and sequence > self.controls_blocked_cursor)):
                self.controls_blocked_at = None
                self.controls_blocked_cursor = None
                self.controls_probe_attempts = 0
                self.log("Native Queue: frischer Soloist-Vollstatus, Steuerung wieder verfügbar.")
        if kind == "queue_changed":
            self.queue = event
            self.queue_uri = current
            self.requested_at = None
            self.queue_attempts = 0
            self.dirty = True
            if self.pending and self.pending["phase"] == "checking" and self._fresh(event):
                self.pending["queue_seen"] = event
                self.pending["queue_current"] = current
                self._send_if_checked()
            return True
        if kind in ("track_changed", "playback_state") and current != self.observed_uri:
            self.observed_uri = current
            self.queue = None
            self.queue_uri = None
            self.requested_at = None
            self.queue_attempts = 0
            self.dirty = True
        if (playback.get("status") not in ("playing", "buffering")
                or playback.get("is_active") is not True
                or (kind == "auth_state" and not event.get("logged_in"))):
            if self.pending or self.actions:
                self.cancel("Soloist nicht mehr aktiv")
            return False
        pending = self.pending if self.pending and self._fresh(event) else None
        if pending and pending["phase"] == "checking" and kind == "playback_state":
            pending["state_seen"] = True
            pending["checked_current"] = current
            self._send_if_checked()
        elif pending and pending["phase"] == "waiting":
            if current == pending["target"]:
                # track_changed can precede buffering and audible playback. It
                # does not alone authorize opening the replacement Kodi reader.
                position = playback.get("position") or {}
                moving = (kind == "position_sync" and isinstance(position, dict)
                          and isinstance(position.get("speed"), (int, float))
                          and not isinstance(position["speed"], bool)
                          and estimated_position_ms(position) is not None
                          and position["speed"] > 0)
                if (playback.get("status") == "playing"
                        and (kind in ("playback_state", "playback_changed") or moving)):
                    self._confirmed()
            elif current != pending["current"]:
                self._control_failed("Anderer Titel gestartet; Folgeaktionen verworfen")
            elif kind == "position_sync" and pending["direction"] == "previous":
                position = playback.get("position") or {}
                before, after = pending["before_position"], estimated_position_ms(position)
                timestamp = position.get("timestamp_ms") if isinstance(position, dict) else None
                if (isinstance(before, (int, float)) and not isinstance(before, bool)
                        and isinstance(after, (int, float)) and not isinstance(after, bool)
                        and isinstance(timestamp, (int, float)) and not isinstance(timestamp, bool)
                        and timestamp >= pending["sent_at_ms"]
                        and before + timestamp - pending["sent_at_ms"] >= 3000
                        and 0 <= after <= 1500):
                    if pending.get("second_previous"):
                        # Never loop: a second restart is reported honestly.
                        self._confirmed(restart=True)
                    elif self.websocket.send_command("skip_prev"):
                        # Kodi plays 2-3 s behind Soloist, so Spotify's 3-second
                        # rule turns almost every Kodi Previous into a restart.
                        # Kodi shows the previous title: go there, once, while
                        # the restarted track is guaranteed under three seconds.
                        self.native_commands.append(("skip_prev", time.monotonic()))
                        pending.update(second_previous=True, before_position=0,
                                       sent_at_ms=time.time() * 1000,
                                       after_sequence=self._event_cursor(),
                                       deadline=time.monotonic() + COMMAND_TIMEOUT)
                        self.log("Native Queue: Soloist startete den Titel neu; zweites "
                                 "skip_prev einmalig gesendet, Ziel ist der vorherige Titel.")
                    else:
                        self._control_failed("Zweites skip_prev nicht vorgemerkt")
        # Window.getProperty itself takes Kodi's graphics lock. Do not put a
        # GUI read (or downstream tag work) between the two fresh WS replies
        # while Kodi opens a cached reader. The snapshot above remains current;
        # AV verification prepares its tag after the control has settled.
        if self.resolver_waiter or self.reader_deadline:
            return True
        # A newly posted resolver that poll_request has not adopted yet still
        # requires the existing GUI guard before downstream player work.
        if kind in ("track_changed", "playback_state") and not self.metadata_busy():
            self._prepare_actual_tag()
        return bool(self._request_value())

    def _prepare_actual_tag(self):
        playback = self.state.get("playback") or {}
        mbids = self.artist_mbids(playback.get("item"))
        fanart = self.artist_fanart(playback.get("item"), mbids)
        revision = music_item_revision(playback.get("item"), mbids, fanart)
        if self.state.get("applied_info_tag_revision") == revision:
            return
        tag = kodi_music_item(playback, self.state["playback_url"], xbmcgui.ListItem,
                              artist_mbids_by_uri=mbids, artist_fanart=fanart)
        if tag is not None:
            self.state.update(pending_info_tag=tag, info_tag_revision=revision,
                              info_tag_attempts=0, info_tag_retry_at=0)

    def av_started(self, source):
        if source is not None and source != self.state.get("playback_url"):
            self._release_navigation("Andere Kodi-AV-Quelle")
            return
        if self._request_value():
            return
        self._sync_session_path()
        self._observe_cached_start()
        if source != self.state.get("playback_url") or not self._owned_source():
            return
        if self.orphaned_reader:
            self.reader_deadline = None
            self._prepare_actual_tag()
            return
        # AV has no reader ID. Require a matching own playlist path; a delayed
        # AV for an intermediate reader must not mark an unknown item ready.
        try:
            context = self._context()
        except RuntimeError:
            return
        if context is None:
            return
        self.reader_deadline = None
        self._prepare_actual_tag()

    def expected_end(self):
        return bool(self.reader_deadline and not self.state.get("av_ready")
                    and self.state.get("owned") and time.monotonic() < self.reader_deadline)

    def cancel(self, reason, notify=False):
        pending, queued = self.pending, len(self.actions)
        jump, self.jump = self.jump, None
        if jump and jump.get("paused_by_us"):
            # Never leave Spotify paused because our own jump was interrupted.
            self.websocket.send_command("play")
            self.log("Native Queue: Sprung abgebrochen; Soloist wird fortgesetzt.")
        self.pending = None
        self.resolver_waiter = None
        self.next_action_at = 0.0
        self.actions.clear()
        request = self._read_request()
        if request and request["operation"] not in self.finished_operations:
            self._reply(request, {"ok": False})
        if pending or queued:
            self.log("Native Queue: Steuerung abgebrochen ({}); Folgeaktionen={} verworfen, "
                     "kein Skip wiederholt.".format(reason, queued))
        if notify:
            self.notify_failure()
        self.queue = None
        self.queue_uri = None
        self.dirty = True

    def close(self):
        self.cancel("Dienst beendet")
        self.native_commands.clear()
        for token in self.entries:
            self.window.clearProperty(PREFIX + token)
        self.entries.clear()
        self.tagged.clear()
        self.resolved_starts.clear()
        self.cached_candidate = None
        self.reader_deadline = None
        self.unexpected_end = False
        self.orphaned_reader = False

    def disable(self, reason):
        self.disabled = True
        self.cancel(reason, notify=True)
        self.mutation = None
        self.log("Native Queue deaktiviert: {}. Audioweg bleibt unverändert.".format(reason))

    def _remove(self, index, expected_path):
        context = self._context()
        if context is None:
            raise RuntimeError("Playlist ownership changed before removal")
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        if (not self._owned_source() or index >= playlist.size()
                or playlist[index].getPath() != expected_path):
            raise RuntimeError("Playlist ownership changed")
        self._rpc("Playlist.Remove", playlistid=0, position=index)
        after = list(self.paths)
        after.pop(index)
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0}

    def _tag_slot(self, index, path, item):
        self._apply_slot_tag(xbmc.PlayList(xbmc.PLAYLIST_MUSIC)[index], path, item)
        self.rows_retagged += 1

    def _refresh_playlist_window(self, reason):
        """An open playlist window shows copies of the rows.

        Neither PlayList.add nor retagging an existing row (e.g. after a
        natural track change) notifies it, so it kept stale titles until it
        was reopened. Refresh it only while it is shown.
        """
        try:
            window_id = xbmcgui.getCurrentWindowId()
            dialog_id = xbmcgui.getCurrentWindowDialogId()
        except (AttributeError, RuntimeError):
            window_id = dialog_id = None
        # Device log 0.3.73: IsActive(...) reported False while the user had
        # the playlist open; check every public way Kodi exposes it.
        window_open = bool(window_id == PLAYLIST_WINDOW_ID
                           or any(xbmc.getCondVisibility(condition)
                                  for condition in PLAYLIST_WINDOW_CONDITIONS))
        if window_open:
            xbmc.executebuiltin("Container.Refresh")
        self.log("Native Queue: {}; Playlist-Fenster offen={}, Neuladen angefordert={}, "
                 "aktives Fenster={} Dialog={}.".format(
                     reason, window_open, window_open, window_id, dialog_id))

    def _apply_slot_tag(self, slot, path, item):
        slot.getMusicInfoTag().setMusicBrainzArtistID([])
        # kodi_music_item sets thumb, icon and fanart together (empty when
        # unknown); clearing them first only produced a visible blank frame.
        mbids = self.artist_mbids(item)
        kodi_music_item({"item": item}, path, lambda **kwargs: slot,
                        artist_mbids_by_uri=mbids, artist_fanart=self.artist_fanart(item, mbids))
        tag = slot.getMusicInfoTag()
        title = tag.getTitle() or item_title(item)
        artist = tag.getArtist()
        # Kodi's playlist re-formats rows as "Artist - Title". Writing a bare
        # title made skins alternate between both forms; write the same text.
        slot.setLabel("{} - {}".format(artist, title) if artist else title)
        slot.setProperty("ForceResolvePlugin", "true")
        slot.setProperty("IsPlayable", "true")
        slot.setProperty("inputstream", "inputstream.ffmpegdirect")
        slot.setProperty("inputstream-player", "videodefaultplayer")

    def _slot_token(self, path):
        parameters = parse_qs(urlsplit(path).query)
        token = (parameters.get("queue") or parameters.get("request") or [""])[0]
        if not TOKEN_PATTERN.fullmatch(token):
            raise ValueError("Not an owned resolver slot")
        return token

    def _publish_slot(self, index, path, direction, target, current):
        token = self._slot_token(path)
        candidate = dict(target, direction=direction, current=current, path=path)
        old = self.entries.get(token) or {}
        if {key: value for key, value in old.items() if key != "revision"} != candidate:
            self.revision += 1
            candidate["revision"] = self.revision
        else:
            candidate["revision"] = old["revision"]
        if self.tagged.get(token) != candidate["revision"]:
            self._tag_slot(index, path, target["item"])
            self.tagged[token] = candidate["revision"]
        self.entries[token] = candidate
        self.window.setProperty(PREFIX + token, json.dumps({
            "session": self.session, "revision": candidate["revision"],
        }))

    def _new_entry(self, direction, target, current_uri):
        token = uuid.uuid4().hex
        path = "plugin://service.soloist.native/?queue={}&session={}".format(token, self.session)
        self.revision += 1
        self.entries[token] = dict(target, direction=direction, current=current_uri,
                                   path=path, revision=self.revision)
        # Kodi can expose the posted Insert before the service observes its ACK.
        # A selectable row must already have a valid session grant at that point.
        self.window.setProperty(PREFIX + token, json.dumps({
            "session": self.session, "revision": self.revision,
        }))
        return path

    def _insert(self, index, path, target):
        self._insert_rows([(index, path, target)])

    def _insert_rows(self, rows):
        """Insert tagged rows in one pass and settle them as one mutation.

        PlayList.add applies at once, unlike the former JSON insert that had
        to be acknowledged row by row (about 0.5 s each, ~5 s for a refill).
        rows are (index, path, target) in ascending index order.
        """
        if self._context() is None:
            raise RuntimeError("Playlist ownership changed before insertion")
        after = list(self.paths)
        for index, path, _ in rows:
            after.insert(index, path)
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0,
                         "inserted": list(rows)}
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        try:
            for index, path, target in rows:
                # A fully tagged ListItem: a bare {"file": path} row appeared
                # without title/art until a later sync tagged it (flicker).
                slot = xbmcgui.ListItem(path=path)
                self._apply_slot_tag(slot, path, target["item"])
                playlist.add(path, slot, index)
                token = self._slot_token(path)
                self.tagged[token] = self.entries[token]["revision"]
                self.rows_inserted_pending += 1
        except Exception:
            self.mutation = None
            raise

    def _settle_mutation(self, require_av=True):
        mutation = self.mutation
        if not mutation:
            return True
        if not self._owned_source(require_av=require_av):
            return False
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        paths = [playlist[index].getPath() for index in range(playlist.size())]
        if paths == mutation["after"] and len(set(paths)) == len(paths):
            self.paths = paths
            self.mutation = None
            for index, path, target in mutation.get("inserted") or []:
                token = self._slot_token(path)
                entry = self.entries[token]
                self._publish_slot(index, path, entry["direction"], target,
                                   item_uri((self.state.get("playback") or {}).get("item")))
            for token, entry in list(self.entries.items()):
                if entry["path"] not in paths:
                    self.window.clearProperty(PREFIX + token)
                    del self.entries[token]
                    self.tagged.pop(token, None)
            if self.current_path not in paths:
                # A posted Remove raced an already copied selection. The live
                # stream is still valid; never reopen it to repair a playlist.
                self.orphaned_reader = True
                self.reader_deadline = None
                self.cached_candidate = None
                self.resolved_starts.clear()
                self.disable("Ausgewählter Slot während Kantenabgleich entfernt; "
                             "eigener Audioleser bleibt erhalten")
            return True
        if paths != mutation["before"] or time.monotonic() >= mutation["deadline"]:
            self.disable("Playlist-Änderung nicht bestätigt")
        return False

    def _targets(self, current):
        playback = self.state.get("playback") or {}
        previous = neighbors(self.queue, "previous", current, limit=MAX_PREVIOUS_ROWS)
        upcoming = neighbors(self.queue, "upcoming", current, limit=MAX_UPCOMING_ROWS)
        actions = playback.get("available_actions")
        if isinstance(actions, dict):
            if actions.get("skip_prev") is False:
                previous = []
            if actions.get("skip_next") is False:
                upcoming = []
        return previous, upcoming

    def sync(self):
        """Fill real neighbours only on a stable, idle own reader; never Swap."""
        if self.busy() or self.cached_candidate is not None:
            return
        now = time.monotonic()
        if now - self.last_selection_at < 0.75:
            return
        if not self.dirty and now - self.last_poll < 0.5:
            return
        self.last_poll = now
        if not self.websocket.is_connected() or not self.state.get("owned"):
            self.cancel("Verbindung oder Playerbesitz beendet")
            return
        if not self.state.get("av_ready"):
            return
        self._sync_session_path()
        if not self._settle_mutation():
            return
        context = self._context()
        if context is None:
            return
        _, paths, position = context
        if not self.paths:
            self.paths = paths
        current = item_uri((self.state.get("playback") or {}).get("item"))
        if not current or self.disabled:
            return
        target = {"uid": current, "uri": current, "item": self.state["playback"]["item"]}
        self._publish_slot(position, self.current_path, "current", target, current)
        if self.queue is None or self.queue_uri != current:
            if (self.queue_attempts < 3
                    and (self.requested_at is None or now - self.requested_at >= 5.0)):
                if self.websocket.send_command("get_queue", limit=10):
                    self.requested_at = now
                    self.queue_attempts += 1
            return
        if not self.dirty:
            return
        previous, upcoming = self._targets(current)
        if not previous:
            # Diagnose once per queue snapshot why Kodi's Previous has no row.
            reason = previous_gap_reason(
                self.queue, current, (self.state.get("playback") or {}).get("available_actions"))
            if (id(self.queue), reason) != self.last_previous_gap:
                self.last_previous_gap = (id(self.queue), reason)
                self.log("Native Queue: kein vorheriger Eintrag; Grund: {}.".format(reason))
        # Trim an excess at an inactive edge before growing: at most 21 rows,
        # no placeholders, and never remove the playing row or clear the list.
        if position > len(previous):
            self._remove(0, self.paths[0])
            return
        after_count = len(self.paths) - position - 1
        if after_count > len(upcoming):
            self._remove(len(self.paths) - 1, self.paths[-1])
            return
        if (position < len(previous)
                and (after_count >= len(upcoming) or position <= after_count)):
            target = previous[position]
            self._insert(0, self._new_entry("previous", target, current), target)
            return
        if after_count < len(upcoming):
            # Append every missing upcoming row at once (one settle, one refresh).
            start = len(self.paths)
            rows = [(start + offset, self._new_entry("next", target, current), target)
                    for offset, target in enumerate(upcoming[after_count:])]
            self._insert_rows(rows)
            return
        ordered = ([("previous", target) for target in reversed(previous)]
                   + [("current", {"uid": current, "uri": current,
                                     "item": self.state["playback"]["item"]})]
                   + [("next", target) for target in upcoming])
        retagged_before = self.rows_retagged
        for index, (direction, target) in enumerate(ordered):
            self._publish_slot(index, self.paths[index], direction, target, current)
        retagged = self.rows_retagged - retagged_before
        inserted, self.rows_inserted_pending = self.rows_inserted_pending, 0
        if retagged or inserted:
            # One refresh for the finished playlist, not one per row.
            self._refresh_playlist_window("Playlist fertig: {} eingefügt, {} neu beschriftet".format(
                inserted, retagged))
        self.dirty = False
        self.log("Native Queue: {} vorherige / {} nächste echte Titel, aktueller Index={}; "
                 "kein Swap, kein zusätzliches Player.Open.".format(
                     len(previous), len(upcoming), position))
