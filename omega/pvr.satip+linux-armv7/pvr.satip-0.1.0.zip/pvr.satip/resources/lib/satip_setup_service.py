#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

import select_satip_server


ADDON_ID = "pvr.satip"
CHECK_INTERVAL_SECONDS = 1
PVR_WINDOW_ID_START = 10700
PVR_WINDOW_ID_END = 10711


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"{ADDON_ID}: setup service: {message}", level)


def _is_pvr_window(window_id: int) -> bool:
    return PVR_WINDOW_ID_START <= window_id <= PVR_WINDOW_ID_END


def _run_server_selection_once() -> None:
    _log("no SAT>IP server configured, opening server selection dialog")
    try:
        select_satip_server.run()
    except Exception as exc:
        _log(f"server selection dialog failed: {exc}", xbmc.LOGERROR)


def run() -> None:
    monitor = xbmc.Monitor()
    dialog_opened_this_session = False

    select_satip_server.ensure_default_instance_name()

    while not monitor.abortRequested():
        if select_satip_server.has_configured_satip_server():
            dialog_opened_this_session = False
        elif not dialog_opened_this_session:
            try:
                current_window_id = xbmcgui.getCurrentWindowId()
            except Exception as exc:
                _log(f"failed to read current window id: {exc}", xbmc.LOGDEBUG)
                current_window_id = 0

            if _is_pvr_window(current_window_id):
                dialog_opened_this_session = True
                _run_server_selection_once()

        if monitor.waitForAbort(CHECK_INTERVAL_SECONDS):
            break


if __name__ == "__main__":
    run()
