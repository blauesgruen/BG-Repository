#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

from addon_identity import get_addon_id
import select_satip_server


ADDON_ID = get_addon_id()
CHECK_INTERVAL_SECONDS = 3
PVR_WINDOW_ID_START = 10700
PVR_WINDOW_ID_END = 10711


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"{ADDON_ID}: setup service: {message}", level)


def _is_pvr_window(window_id: int) -> bool:
    return PVR_WINDOW_ID_START <= window_id <= PVR_WINDOW_ID_END


def _run_server_selection_once() -> None:
    _log("no SAT>IP server configured, opening addon settings")
    try:
        xbmcgui.Dialog().notification(
            ADDON_ID,
            "No SAT>IP server configured. Please configure the add-on settings.",
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
        xbmc.executebuiltin(f"Addon.OpenSettings({ADDON_ID})")
    except Exception as exc:
        _log(f"failed to open addon settings: {exc}", xbmc.LOGERROR)


def run() -> None:
    monitor = xbmc.Monitor()
    dialog_opened_this_session = False
    last_logged_state = None

    while not monitor.abortRequested():
        try:
            current_window_id = xbmcgui.getCurrentWindowId()
        except Exception as exc:
            _log(f"failed to read current window id: {exc}", xbmc.LOGDEBUG)
            current_window_id = 0

        configured = select_satip_server.has_configured_satip_server()
        state = (configured, dialog_opened_this_session, current_window_id)
        if state != last_logged_state:
            _log(
                f"state changed: configured={configured} dialog_opened_this_session={dialog_opened_this_session} "
                f"window_id={current_window_id} is_pvr_window={_is_pvr_window(current_window_id)}",
                xbmc.LOGINFO,
            )
            last_logged_state = state

        if configured:
            dialog_opened_this_session = False
        elif not dialog_opened_this_session:
            if _is_pvr_window(current_window_id):
                dialog_opened_this_session = True
                _run_server_selection_once()

        if monitor.waitForAbort(CHECK_INTERVAL_SECONDS):
            break


if __name__ == "__main__":
    run()
