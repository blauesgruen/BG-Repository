#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import glob
import json
import os
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

from addon_identity import get_addon_id


ADDON_ID = get_addon_id()
PENDING_SELECTION_FILE = f"special://userdata/addon_data/{ADDON_ID}/pending_satip_server_selection.json"
INSTANCE_SETTINGS_GLOB = f"special://userdata/addon_data/{ADDON_ID}/instance-settings-*.xml"
DEFAULT_INSTANCE_SETTINGS_FILE = f"special://userdata/addon_data/{ADDON_ID}/instance-settings-1.xml"
SETTING_ID_SATIP_SERVER_HOST = "satipServerHost"
SETTINGS_DIALOG_TIMEOUT_SECONDS = 90


def _log(message: str, level=xbmc.LOGINFO) -> None:
    xbmc.log(f"{ADDON_ID}: selected server apply: {message}", level)


def _translated(path: str) -> str:
    return xbmcvfs.translatePath(path)


def _wait_for_settings_dialog_closed() -> bool:
    monitor = xbmc.Monitor()
    deadline = time.time() + SETTINGS_DIALOG_TIMEOUT_SECONDS

    while time.time() < deadline and not monitor.abortRequested():
        if not xbmc.getCondVisibility("Window.IsVisible(DialogAddonSettings.xml)"):
            return True
        if monitor.waitForAbort(0.25):
            return False

    return False


def _read_pending_selection() -> dict:
    pending_path = _translated(PENDING_SELECTION_FILE)
    try:
        with open(pending_path, "r", encoding="utf-8") as pending_file:
            data = json.load(pending_file)
    except Exception as exc:
        _log(f"failed to read pending selection {pending_path}: {exc}", xbmc.LOGERROR)
        return {}

    host = str(data.get("host", "")).strip()
    if not host:
        _log("pending selection has no host", xbmc.LOGERROR)
        return {}

    return {"host": host, "location": str(data.get("location", "")).strip()}


def _remove_pending_selection() -> None:
    pending_path = _translated(PENDING_SELECTION_FILE)
    try:
        if os.path.exists(pending_path):
            os.remove(pending_path)
    except Exception as exc:
        _log(f"failed to remove pending selection {pending_path}: {exc}", xbmc.LOGDEBUG)


def _instance_settings_candidates() -> list:
    translated_glob = _translated(INSTANCE_SETTINGS_GLOB)
    candidates = sorted(glob.glob(translated_glob))
    if candidates:
        return candidates
    return [_translated(DEFAULT_INSTANCE_SETTINGS_FILE)]


def _find_or_create_setting(root: ET.Element, setting_id: str) -> ET.Element:
    for setting_node in root.findall("./setting"):
        if setting_node.get("id", "") == setting_id:
            return setting_node

    setting_node = ET.SubElement(root, "setting")
    setting_node.set("id", setting_id)
    return setting_node


def _load_settings_tree(settings_path: str) -> ET.ElementTree:
    if os.path.exists(settings_path):
        return ET.parse(settings_path)

    root = ET.Element("settings")
    root.set("version", "2")
    return ET.ElementTree(root)


def _write_host(settings_path: str, host: str) -> None:
    tree = _load_settings_tree(settings_path)
    root = tree.getroot()
    host_node = _find_or_create_setting(root, SETTING_ID_SATIP_SERVER_HOST)
    host_node.text = host
    if "default" in host_node.attrib:
        del host_node.attrib["default"]

    os.makedirs(os.path.dirname(settings_path), exist_ok=True)
    try:
        ET.indent(tree, space="    ")
    except AttributeError:
        pass
    tree.write(settings_path, encoding="utf-8", xml_declaration=False)


def run() -> None:
    if not _wait_for_settings_dialog_closed():
        _log("settings dialog did not close before timeout; keeping pending selection", xbmc.LOGWARNING)
        return

    pending = _read_pending_selection()
    if not pending:
        _remove_pending_selection()
        return

    host = pending["host"]
    settings_path = _instance_settings_candidates()[0]
    try:
        _log(f"applying selected SAT>IP server host={host} to {settings_path}")
        _write_host(settings_path, host)
    except Exception as exc:
        _log(f"failed to apply selected SAT>IP server host={host}: {exc}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_ID, "SAT>IP server could not be saved.", xbmcgui.NOTIFICATION_ERROR, 5000)
        return
    finally:
        _remove_pending_selection()

    _log(f"applied selected SAT>IP server host={host}")
    xbmcgui.Dialog().notification(ADDON_ID, f"SAT>IP server saved: {host}", xbmcgui.NOTIFICATION_INFO, 5000)


if __name__ == "__main__":
    run()
