"""Bridge Soloist's PulseAudio RTP output to Kodi over local TCP with timestamped Matroska PCM."""

import json
import hashlib
import math
import collections
import errno
import os
import random
import re
import select
import socket
import struct
import sys
import subprocess
import socketserver
import threading
import time
try:
    import fcntl
    import termios
except ImportError:
    fcntl = None
    termios = None
from urllib.parse import urlsplit


# Spotify delivers 44.1 kHz; keeping it end to end avoids a PulseAudio
# resampling step (was 48 kHz until 0.3.86). module-rtp-send carries any
# rate with 16-bit L16, Kodi passes 44.1 kHz on with "best match" output.
RATE = 44100
PA_VOLUME_NORM = 65536
CHANNELS = 2
SINK_NAME = "soloist_native"
TCP_SAMPLE_BYTES = 2
TCP_BYTES_PER_SECOND = RATE * CHANNELS * TCP_SAMPLE_BYTES
TCP_QUEUE_LIMIT = TCP_BYTES_PER_SECOND // 2
TCP_SILENCE_INTERVAL = 0.02
TCP_SILENCE_CHUNK = b"\x00" * (TCP_BYTES_PER_SECOND // 50)
TCP_WRITE_POLL_SECONDS = 0.1
TCP_DIAGNOSTIC_INTERVAL = 5.0
# Healthy flow is summarised once a minute; anomalies are logged at once and
# then every 30 seconds while they last, plus one line when the flow recovers.
TCP_DIAGNOSTIC_HEALTHY_INTERVAL = 60.0
TCP_DIAGNOSTIC_ANOMALY_INTERVAL = 30.0
TCP_DIAGNOSTIC_MIN_PACKET_RATE = 120.0  # RTP sends ~150 packets/s
TCP_DIAGNOSTIC_MAX_PACKET_AGE_MS = 500
AUDIO_MIME_TYPE = "audio/x-matroska"


def _decode_udp_ancillary(ancillary, drop_type, timestamp_type, now_ns):
    """Decode Linux socket metadata, never alter RTP bytes or invent missing data."""
    drops = None
    age_ms = None
    invalid = 0
    for level, kind, data in ancillary:
        if level != socket.SOL_SOCKET:
            continue
        if drop_type is not None and kind == drop_type:
            if len(data) == 4:
                drops = struct.unpack_from("=I", data)[0]
            else:
                invalid += 1
        elif timestamp_type is not None and kind == timestamp_type:
            # Linux NEW timestamp ABI uses two int64s; OLD uses native longs.
            layout = "=qq" if timestamp_type == 64 else "@ll"
            if len(data) != struct.calcsize(layout):
                invalid += 1
                continue
            seconds, nanoseconds = struct.unpack_from(layout, data)
            age = now_ns - (seconds * 1000000000 + nanoseconds)
            if 0 <= nanoseconds < 1000000000 and 0 <= age < 60000000000:
                age_ms = age // 1000000
            else:
                invalid += 1  # negative or excessive age; wall-clock steps remain a caveat
    return drops, age_ms, invalid


def _ebml_element(element_id, payload):
    """Encode a finite EBML element; reserve the all-ones size for unknown."""
    width = 1
    while len(payload) >= (1 << (7 * width)) - 1:
        width += 1
    size = ((1 << (7 * width)) | len(payload)).to_bytes(width, "big")
    identifier = element_id.to_bytes((element_id.bit_length() + 7) // 8, "big")
    return identifier + size + payload


def _ebml_uint(element_id, value):
    return _ebml_element(
        element_id, value.to_bytes(max(1, (value.bit_length() + 7) // 8), "big")
    )


# An unknown-length Segment is valid for a live stream. No duration, index,
# seeking or track-relative Spotify clock is advertised. Only one PCM track.
MATROSKA_HEADER = (
    _ebml_element(0x1A45DFA3,
        _ebml_uint(0x4286, 1) + _ebml_uint(0x42F7, 1)
        + _ebml_uint(0x42F2, 4) + _ebml_uint(0x42F3, 8)
        + _ebml_element(0x4282, b"matroska")
        + _ebml_uint(0x4287, 4) + _ebml_uint(0x4285, 2))
    + bytes.fromhex("1853806701ffffffffffffff")
    + _ebml_element(0x1549A966,
        _ebml_uint(0x2AD7B1, 1000)  # timestamp unit: one microsecond
        + _ebml_element(0x4D80, b"Soloist")
        + _ebml_element(0x5741, b"Soloist"))
    + _ebml_element(0x1654AE6B, _ebml_element(0xAE,
        _ebml_uint(0xD7, 1) + _ebml_uint(0x73C5, 1)
        + _ebml_uint(0x83, 2) + _ebml_uint(0x9C, 0)
        + _ebml_element(0x86, b"A_PCM/INT/LIT")
        + _ebml_element(0xE1,
            _ebml_element(0xB5, struct.pack(">d", RATE))
            + _ebml_uint(0x9F, CHANNELS) + _ebml_uint(0x6264, 16))))
)


def _pcm_cluster(payload, frames_sent):
    """Timestamp unchanged PCM by sample count, without cumulative rounding."""
    if not payload or len(payload) % (CHANNELS * TCP_SAMPLE_BYTES):
        raise ValueError("PCM-Block enthält keine vollständigen Stereo-Frames")
    timestamp_us = frames_sent * 1000000 // RATE
    next_frames = frames_sent + len(payload) // (CHANNELS * TCP_SAMPLE_BYTES)
    duration_us = next_frames * 1000000 // RATE - timestamp_us
    # One finite cluster per block: signed relative timestamp stays zero and
    # cannot overflow during long sessions. Every PCM block is independently
    # decodable, with no lacing, compression or ReferenceBlock. BlockGroup
    # declares the actual duration, including variable-sized coalesced chunks.
    block = _ebml_element(0xA1, b"\x81\x00\x00\x00" + payload)
    group = _ebml_element(0xA0, block + _ebml_uint(0x9B, duration_us))
    return _ebml_element(0x1F43B675, _ebml_uint(0xE7, timestamp_us) + group)



def _tcp_flow_anomaly(previous, current, elapsed, silence_bytes):
    """Name what deviates from healthy RTP->TCP flow since the last check."""
    reasons = []
    if elapsed > 0 and (current["received"] - previous["received"]) / elapsed < TCP_DIAGNOSTIC_MIN_PACKET_RATE:
        reasons.append("RTP-Paketrate={:.0f}/s".format(
            (current["received"] - previous["received"]) / elapsed))
    age = current["packet_age_ms"]
    if isinstance(age, int) and age > TCP_DIAGNOSTIC_MAX_PACKET_AGE_MS:
        reasons.append("letztes_RTP_vor={}ms".format(age))
    if silence_bytes > 0:
        reasons.append("Stillefüllung={}B".format(silence_bytes))
    for key, label in (("kernel_drops", "Kernel_verworfen"),
                       ("kernel_invalid", "Zusatzdaten_ungültig"),
                       ("kernel_truncated", "abgeschnitten"),
                       ("max_receive_gap_ms", "größte_Empfangspause"),
                       ("last_loss_sequence_delta", "RTP-Lücke")):
        if current[key] != previous[key]:
            reasons.append("{}={}".format(label, current[key]))
    return ", ".join(reasons) or None

class _AudioTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True


class _AudioTCPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        owner = self.server.owner
        connection_id = owner.next_tcp_connection_id()
        owner.logger(
            "TCP-PCM-Verbindung id={} angenommen; Matroska-PCM-Reader wird geöffnet.".format(
                connection_id
            )
        )
        owner._stream_tcp_audio(self.request, connection_id)


class AudioSetupError(Exception):
    """PulseAudio or Kodi audio setup failed safely."""


class PulseRtpAudio:
    def __init__(self, data_dir, logger, runner=None):
        self.data_dir = data_dir
        self.logger = logger
        self.runner = runner or subprocess.run
        self.module_ids = []
        self.sink_name = "{}_{}_{}".format(
            SINK_NAME,
            os.getpid(),
            random.randrange(100000, 1000000),
        )
        self.port = None
        self.tcp_server = None
        self.tcp_thread = None
        self.playback_url = None
        self.default_sink = None
        self.original_inputs = {}
        self._rtp_receiver = None
        self._udp_drop_type = None
        self._udp_timestamp_type = None
        self._udp_receive_buffer = None
        self._udp_last_drop_counter = 0
        self._rtp_thread = None
        self._rtp_stop = threading.Event()
        self._rtp_lock = threading.Lock()
        self._tcp_condition = threading.Condition()
        # Kodi may open more than one reader during probing or player startup.
        # Give every connection its own queue so readers cannot steal PCM.
        self._tcp_client_queues = {}
        self._tcp_clients = set()
        self._tcp_stop = threading.Event()
        self._playback_enabled = True
        self._tcp_connection_lock = threading.Lock()
        self._tcp_connection_sequence = 0
        self._diagnostic_cache_lock = threading.Lock()
        self._diagnostic_cache = "PulseAudio-Probe=noch nicht ausgeführt"
        self._diagnostic_cache_at = None
        self._diagnostic_worker = None
        self._sink_recovery_lock = threading.Lock()
        self._sink_recovery_thread = None
        self._sink_recovery_last_attempt = 0.0
        self._rtp_stats = {
            "received": 0,
            "bytes_received": 0,
            "sequence_gaps": 0,
            "duplicates": 0,
            "out_of_order": 0,
            "timestamp_jumps": 0,
            "silence_filled_frames": 0,
            "malformed": 0,
            "forward_errors": 0,
            "last_packet_at": None,
            "max_receive_gap_ms": 0,
            "last_loss_arrival_gap_ms": 0,
            "last_loss_sequence_delta": 0,
            "last_loss_timestamp_delta": 0,
            "kernel_dropped_packets": None,
            "max_kernel_queue_age_ms": None,
            "last_loss_kernel_queue_age_ms": None,
            "kernel_metadata_invalid": 0,
            "kernel_metadata_truncated": 0,
            "last_sequence": None,
            "last_timestamp": None,
            "last_payload_bytes": None,
            "stream_resets": 0,
            "tcp_connections": 0,
            "tcp_bytes_sent": 0,
            "tcp_dropped_bytes": 0,
            "pcm_nonzero_packets": 0,
            "pcm_zero_packets": 0,
            "zero_pcm_since": None,
            "last_nonzero_pcm_at": None,
        }
        self._rtp_reported = dict(self._rtp_stats)

    def _pactl(self, *arguments):
        try:
            result = self.runner(
                ["pactl"] + list(arguments),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=5,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise AudioSetupError("PulseAudio-Steuerung ist nicht erreichbar") from error
        if result.returncode != 0:
            raise AudioSetupError(self._pactl_failure(arguments, result))
        return (result.stdout or "").strip()

    @staticmethod
    def _pactl_failure(arguments, result):
        """Return a bounded diagnostic without logging an entire command result."""
        operation = " ".join(str(argument) for argument in arguments[:3])
        lines = (result.stdout or "").splitlines()
        detail = " ".join("".join(char for char in line if char.isprintable()) for line in lines[:1])
        detail = detail[:240].strip()
        message = "pactl {} fehlgeschlagen (Exit-Code {})".format(
            operation or "Befehl", result.returncode
        )
        if detail:
            message += ": {}".format(detail)
        return message

    @staticmethod
    def _free_rtp_port(exclude=()):
        for port in random.sample(range(30000, 50000, 2), 128):
            if port in exclude:
                continue
            probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                probe.bind(("127.0.0.1", port))
            except OSError:
                continue
            else:
                return port
            finally:
                probe.close()
        raise AudioSetupError("Kein freier lokaler RTP-Port gefunden")

    @staticmethod
    def _rtp_header(packet):
        """Parse the RTP sequence, timestamp and payload length if valid."""
        if len(packet) < 12 or packet[0] >> 6 != 2:
            return None
        header_length = 12 + (packet[0] & 0x0F) * 4
        if header_length > len(packet):
            return None
        if packet[0] & 0x10:
            if header_length + 4 > len(packet):
                return None
            extension_words = struct.unpack_from("!H", packet, header_length + 2)[0]
            header_length += 4 + extension_words * 4
            if header_length > len(packet):
                return None
        payload_end = len(packet)
        if packet[0] & 0x20:
            padding = packet[-1]
            if padding < 1 or padding > payload_end - header_length:
                return None
            payload_end -= padding
        sequence, timestamp = struct.unpack_from("!HI", packet, 2)
        return sequence, timestamp, payload_end - header_length

    @staticmethod
    def _rtp_payload(packet):
        parsed = PulseRtpAudio._rtp_header(packet)
        if parsed is None:
            return b""
        header_length = 12 + (packet[0] & 0x0F) * 4
        if packet[0] & 0x10:
            extension_words = struct.unpack_from("!H", packet, header_length + 2)[0]
            header_length += 4 + extension_words * 4
        payload_end = len(packet)
        if packet[0] & 0x20:
            payload_end -= packet[-1]
        return packet[header_length:payload_end]

    def _start_rtp_relay(self):
        receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._udp_drop_type = None
        self._udp_timestamp_type = None
        self._udp_receive_buffer = None
        try:
            receiver.bind(("127.0.0.1", self.port))
            receiver.settimeout(0.5)
        except OSError as error:
            receiver.close()
            raise AudioSetupError("Lokaler RTP-Empfang konnte nicht starten") from error
        # Read-only metadata on our own socket, not buffer tuning or sysctl.
        known_linux_abi = sys.platform == "linux" and os.uname().machine in (
            "aarch64", "arm64", "x86_64", "amd64"
        )
        if hasattr(receiver, "recvmsg"):
            for name, fallback, field in (
                ("SO_RXQ_OVFL", 40, "_udp_drop_type"),
                ("SO_TIMESTAMPNS", 35, "_udp_timestamp_type"),
            ):
                option = getattr(socket, name, fallback if known_linux_abi else None)
                if option is None:
                    continue
                try:
                    receiver.setsockopt(socket.SOL_SOCKET, option, 1)
                except OSError as error:
                    self.logger("RTP-Kerneldiagnose {} nicht verfügbar (errno={}).".format(
                        name, error.errno))
                else:
                    setattr(self, field, option)
        try:
            self._udp_receive_buffer = receiver.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
        except OSError as error:
            self.logger("RTP-Empfangspuffergröße nicht lesbar (errno={}).".format(error.errno))
        self._udp_last_drop_counter = 0
        with self._rtp_lock:
            initial_drops = 0 if self._udp_drop_type is not None else None
            self._rtp_stats["kernel_dropped_packets"] = initial_drops
            self._rtp_reported["kernel_dropped_packets"] = initial_drops
            self._rtp_stats["max_kernel_queue_age_ms"] = None
            self._rtp_stats["last_loss_kernel_queue_age_ms"] = None
        self.logger("RTP-Kerneldiagnose: Socketpuffer={}B Verlustzähler={} Zeitstempel={}; "
                    "Puffergröße unverändert.".format(self._udp_receive_buffer,
                    self._udp_drop_type is not None, self._udp_timestamp_type is not None))
        self._rtp_receiver = receiver
        self._rtp_stop.clear()
        self._rtp_thread = threading.Thread(
            target=self._rtp_relay_loop,
            name="soloist-rtp-to-tcp-bridge",
            daemon=True,
        )
        self._rtp_thread.start()

    def _start_transport(self):
        self._start_tcp_server()
        self._start_rtp_relay()

    def _stop_transport(self):
        self._tcp_stop.set()
        self.close_tcp_clients("Audioressourcen werden bereinigt")
        if self.tcp_server is not None:
            try:
                self.tcp_server.shutdown()
            except (OSError, RuntimeError) as error:
                self.logger("TCP-Server beim Beenden nicht erreichbar ({}).".format(type(error).__name__))
            self.tcp_server.server_close()
            self.tcp_server = None
        if self.tcp_thread is not None and self.tcp_thread.is_alive():
            self.tcp_thread.join(timeout=1.0)
        self.tcp_thread = None
        self._rtp_stop.set()
        if self._rtp_receiver is not None:
            try:
                self._rtp_receiver.close()
            except OSError:
                pass
        if self._rtp_thread is not None and self._rtp_thread.is_alive():
            self._rtp_thread.join(timeout=1.0)
        self._rtp_receiver = None
        self._rtp_thread = None

    def _start_tcp_server(self):
        with self._tcp_condition:
            self._playback_enabled = True
        try:
            server = _AudioTCPServer(("127.0.0.1", 0), _AudioTCPHandler)
        except OSError as error:
            raise AudioSetupError("Lokaler TCP-Audiostream konnte nicht starten") from error
        server.owner = self
        self.tcp_server = server
        self.playback_url = "tcp://127.0.0.1:{}?timeout=5000000".format(
            server.server_address[1]
        )
        self._tcp_stop.clear()
        self.tcp_thread = threading.Thread(
            target=server.serve_forever,
            name="soloist-audio-tcp",
            daemon=True,
        )
        self.tcp_thread.start()

    def next_tcp_connection_id(self):
        """Return a process-local ID for correlating TCP reader logs."""
        with self._tcp_connection_lock:
            self._tcp_connection_sequence += 1
            return self._tcp_connection_sequence

    def _send_pcm(self, connection, payload, client_state):
        """Write an ordered block, allowing backpressure without creating EOF.

        send() reports partial progress; unlike a timed-out sendall(), its
        returned offset lets us resume without duplicating PCM bytes. The
        socket is nonblocking and each wait is short so pause/stop can cancel.
        """
        remaining = memoryview(payload)
        blocked_since = None
        next_wait_log_at = None
        while remaining:
            if self._tcp_stop.is_set() or not self._playback_enabled:
                return False
            try:
                sent = connection.send(remaining)
            except (BlockingIOError, InterruptedError):
                now = time.monotonic()
                if blocked_since is None:
                    blocked_since = now
                    next_wait_log_at = now + 0.5
                if now >= next_wait_log_at:
                    self.logger(
                        "TCP-PCM-Leser id={} Rückstau={}ms Rest={}B; "
                        "Verbindung bleibt offen. {}".format(
                            client_state["request_id"],
                            int((now - blocked_since) * 1000), len(remaining),
                            self.buffer_snapshot(),
                        )
                    )
                    next_wait_log_at = now + TCP_DIAGNOSTIC_INTERVAL
                try:
                    select.select([], [connection], [], TCP_WRITE_POLL_SECONDS)
                except ValueError as error:
                    raise ConnectionAbortedError("TCP-Socket wurde geschlossen") from error
                continue
            if sent <= 0:
                raise ConnectionResetError("TCP-Leser hat die Verbindung beendet")
            if blocked_since is not None:
                elapsed = time.monotonic() - blocked_since
                if elapsed >= 0.5:
                    self.logger(
                        "TCP-PCM-Leser id={} Versand nach {}ms Rückstau "
                        "an derselben Byteposition fortgesetzt.".format(
                            client_state["request_id"], int(elapsed * 1000)
                        )
                    )
                blocked_since = None
            remaining = remaining[sent:]
            with self._tcp_condition:
                client_state["pending_bytes"] = len(remaining)
        return True

    def _stream_tcp_audio(self, connection, request_id):
        try:
            connection.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65536)
            connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        try:
            connection.setblocking(False)
        except OSError:
            self.logger(
                "TCP-PCM-Leser id={} beendet: nichtblockierender Modus "
                "nicht setzbar.".format(request_id)
            )
            return
        with self._tcp_condition:
            if not self._playback_enabled:
                self.logger(
                    "TCP-PCM-Leser id={} ohne Matroska-/Audiobody beendet: "
                    "Soloist-Pause sperrt die Ausgabe.".format(request_id)
                )
                return
            self._rtp_stats["tcp_connections"] += 1
            self._tcp_clients.add(connection)
            client_state = {
                "queue": collections.deque(),
                "bytes": 0,
                "dropped_bytes": 0,
                "request_id": request_id,
                "started_at": time.monotonic(),
                "pending_bytes": 0,
                "pcm_sent": 0,
                "silence_sent": 0,
                "max_send_ms": 0.0,
                "gap_fill_queued": 0,
                "queue_peak_bytes": 0,
                "last_send_at": None,
            }
            self._tcp_client_queues[connection] = client_state
        client_queue = client_state["queue"]
        pending = bytearray()
        started_at = time.monotonic()
        last_silence_at = started_at
        last_diagnostic_at = started_at
        last_diagnostic_stats = self._tcp_diagnostic_counters()
        last_logged_at = started_at
        last_logged_stats = dict(last_diagnostic_stats)
        last_check_silence = 0
        diagnostic_anomaly = None
        request_start_stats = dict(last_diagnostic_stats)
        first_body_ms = None
        first_pcm_ms = None
        stream_frames = 0
        container_bytes_sent = 0
        pcm_bytes_sent = 0
        silence_bytes_sent = 0
        close_reason = "Kodi hat den TCP-Stream getrennt"
        self.logger(
            "TCP-PCM-Leser id={} Handler=gestartet RTP={} Nichtnull-PCM={} "
            "Null-PCM={} Paketalter={}ms.".format(
                request_id,
                last_diagnostic_stats["received"],
                last_diagnostic_stats["nonzero"],
                last_diagnostic_stats["zero"],
                last_diagnostic_stats["packet_age_ms"],
            )
        )
        send_started = None
        try:
            if not self._send_pcm(connection, MATROSKA_HEADER, client_state):
                return
            container_bytes_sent = len(MATROSKA_HEADER)
            self.logger(
                "TCP-PCM-Leser id={} Matroska-Kopf gesendet: {}Hz {} Kanäle "
                "16bit PCM little-endian, {}B/s; explizite Sample-Zeitstempel "
                "in Mikrosekunden, erster PTS=0.".format(
                    request_id, RATE, CHANNELS, TCP_BYTES_PER_SECOND
                )
            )
            while not self._tcp_stop.is_set():
                with self._tcp_condition:
                    if not self._playback_enabled:
                        close_reason = "Soloist pausiert; Audioausgabe gesperrt"
                        break
                    if not client_queue:
                        elapsed = time.monotonic() - last_silence_at
                        self._tcp_condition.wait(
                            max(0.0, TCP_SILENCE_INTERVAL - elapsed)
                        )
                    if not self._playback_enabled:
                        close_reason = "Soloist pausiert; Audioausgabe gesperrt"
                        break
                    while client_queue and len(pending) < 32768:
                        payload = client_queue.popleft()
                        client_state["bytes"] -= len(payload)
                        pending.extend(payload)
                    client_state["pending_bytes"] = len(pending)
                if pending:
                    send_started = time.monotonic()
                    cluster = _pcm_cluster(bytes(pending), stream_frames)
                    if not self._send_pcm(connection, cluster, client_state):
                        break
                    stream_frames += len(pending) // (CHANNELS * TCP_SAMPLE_BYTES)
                    container_bytes_sent += len(cluster) - len(pending)
                    send_ms = (time.monotonic() - send_started) * 1000
                    send_started = None
                    with self._tcp_condition:
                        client_state["last_send_at"] = time.monotonic()
                        client_state["pcm_sent"] += len(pending)
                        client_state["pending_bytes"] = 0
                        client_state["max_send_ms"] = max(
                            client_state["max_send_ms"], send_ms
                        )
                    with self._rtp_lock:
                        self._rtp_stats["tcp_bytes_sent"] += len(pending)
                    pcm_bytes_sent += len(pending)
                    pending.clear()
                    last_silence_at = time.monotonic()
                    if first_pcm_ms is None:
                        first_pcm_ms = int((last_silence_at - started_at) * 1000)
                    if first_body_ms is None:
                        first_body_ms = first_pcm_ms
                        self.logger(
                            "TCP-PCM-Leser id={} erstes_PCM_sendall_nach={}ms.".format(
                                request_id, first_pcm_ms
                            )
                        )
                elif time.monotonic() - last_silence_at >= TCP_SILENCE_INTERVAL:
                    send_started = time.monotonic()
                    cluster = _pcm_cluster(TCP_SILENCE_CHUNK, stream_frames)
                    if not self._send_pcm(connection, cluster, client_state):
                        break
                    stream_frames += len(TCP_SILENCE_CHUNK) // (CHANNELS * TCP_SAMPLE_BYTES)
                    container_bytes_sent += len(cluster) - len(TCP_SILENCE_CHUNK)
                    send_ms = (time.monotonic() - send_started) * 1000
                    send_started = None
                    with self._tcp_condition:
                        client_state["last_send_at"] = time.monotonic()
                        client_state["silence_sent"] += len(TCP_SILENCE_CHUNK)
                        client_state["max_send_ms"] = max(
                            client_state["max_send_ms"], send_ms
                        )
                    with self._rtp_lock:
                        self._rtp_stats["tcp_bytes_sent"] += len(
                            TCP_SILENCE_CHUNK
                        )
                    silence_bytes_sent += len(TCP_SILENCE_CHUNK)
                    last_silence_at = time.monotonic()
                    if first_body_ms is None:
                        first_body_ms = int((last_silence_at - started_at) * 1000)
                        self.logger(
                            "TCP-PCM-Leser id={} erstes_Stillesample_sendall_nach={}ms.".format(
                                request_id, first_body_ms
                            )
                        )
                now = time.monotonic()
                if now - last_diagnostic_at >= TCP_DIAGNOSTIC_INTERVAL:
                    current = self._tcp_diagnostic_counters()
                    anomaly = _tcp_flow_anomaly(
                        last_diagnostic_stats, current, now - last_diagnostic_at,
                        silence_bytes_sent - last_check_silence,
                    )
                    last_diagnostic_at = now
                    last_diagnostic_stats = current
                    last_check_silence = silence_bytes_sent
                    if anomaly:
                        log_due = (diagnostic_anomaly is None or now - last_logged_at
                                   >= TCP_DIAGNOSTIC_ANOMALY_INTERVAL)
                    else:
                        log_due = (diagnostic_anomaly is not None or now - last_logged_at
                                   >= TCP_DIAGNOSTIC_HEALTHY_INTERVAL)
                    if anomaly and diagnostic_anomaly is None:
                        self.logger("TCP-PCM-Leser id={} AUFFÄLLIG: {}.".format(
                            request_id, anomaly))
                    elif not anomaly and diagnostic_anomaly is not None:
                        self.logger("TCP-PCM-Leser id={} wieder normal (zuvor: {}).".format(
                            request_id, diagnostic_anomaly))
                    diagnostic_anomaly = anomaly
                    if not log_due:
                        continue
                    span = now - last_logged_at
                    self.logger(
                        "TCP-PCM-Fluss id={} ({:.0f}s): Leser aktiv; gesendet={}B "
                        "(RTP-PCM={}B Stille={}B), RTP-Pakete_global=+{} "
                        "Nichtnull-PCM_global=+{} Null-PCM_global=+{} "
                        "letztes_RTP_vor={}ms.".format(
                            request_id, span,
                            pcm_bytes_sent + silence_bytes_sent,
                            pcm_bytes_sent,
                            silence_bytes_sent,
                            current["received"] - last_logged_stats["received"],
                            current["nonzero"] - last_logged_stats["nonzero"],
                            current["zero"] - last_logged_stats["zero"],
                            current["packet_age_ms"],
                        )
                    )
                    self.logger(
                        "Matroska-Zeitprobe id={}: nächster_PTS={}us Frames={} "
                        "Containerbytes={}B.".format(
                            request_id, stream_frames * 1000000 // RATE,
                            stream_frames, container_bytes_sent,
                        )
                    )
                    # Kernel ages use the kernel wall clock; they are no audible-latency measure.
                    self.logger(
                        "RTP-Probe: größte_Empfangspause={}ms letzte_Lücke_Ankunftsabstand={}ms "
                        "Sequenzdelta={} Timestampdelta={}Frames; Socketpuffer={}B "
                        "Kernel_verworfen={} max_Paketalter_bis_Python={}ms "
                        "letzte_Lücke_Paketalter_bis_Python={}ms Zusatzdaten_ungültig={} "
                        "abgeschnitten={}.".format(
                            current["max_receive_gap_ms"], current["last_loss_arrival_gap_ms"],
                            current["last_loss_sequence_delta"], current["last_loss_timestamp_delta"],
                            self._udp_receive_buffer,
                            current["kernel_drops"], current["kernel_age_ms"],
                            current["last_loss_kernel_age_ms"],
                            current["kernel_invalid"], current["kernel_truncated"],
                        )
                    )
                    self.logger("TCP-Pufferprobe: {}".format(self.buffer_snapshot()))
                    last_logged_at = now
                    last_logged_stats = current
        except (BrokenPipeError, ConnectionResetError, OSError) as error:
            close_reason = "TCP-PCM-Verbindung beendet ({})".format(
                type(error).__name__
            )
        except Exception as error:
            close_reason = "TCP-PCM-Handlerfehler ({})".format(
                type(error).__name__
            )
            self.logger(
                "TCP-PCM-Leser id={} Handlerfehler={}.".format(
                    request_id, type(error).__name__
                )
            )
            raise
        finally:
            if send_started is not None:
                with self._tcp_condition:
                    client_state["max_send_ms"] = max(
                        client_state["max_send_ms"],
                        (time.monotonic() - send_started) * 1000,
                    )
            if self._tcp_stop.is_set():
                close_reason = "Dienst hat den PCM-Stream beendet"
            elif not self._playback_enabled:
                close_reason = "Soloist pausiert; Audioausgabe gesperrt"
            finished_at = time.monotonic()
            final_stats = self._tcp_diagnostic_counters()
            self.logger(
                "TCP-PCM-Leser id={} Ende={}; Dauer={}ms erstes_Body_sendall={}ms "
                "erstes_PCM_sendall={}ms sendall_bytes={}B "
                "(RTP-PCM={}B Stille={}B) Queue_verworfen={}B "
                "RTP-Pakete_global_seit_Reader=+{} Nichtnull-PCM_global_seit_Reader=+{} "
                "Null-PCM_global_seit_Reader=+{} letztes_RTP_vor={}ms max_sendall={:.1f}ms.".format(
                    request_id,
                    close_reason,
                    int((finished_at - started_at) * 1000),
                    "nie" if first_body_ms is None else first_body_ms,
                    "nie" if first_pcm_ms is None else first_pcm_ms,
                    pcm_bytes_sent + silence_bytes_sent,
                    pcm_bytes_sent,
                    silence_bytes_sent,
                    client_state["dropped_bytes"],
                    final_stats["received"] - request_start_stats["received"],
                    final_stats["nonzero"] - request_start_stats["nonzero"],
                    final_stats["zero"] - request_start_stats["zero"],
                    final_stats["packet_age_ms"],
                    client_state["max_send_ms"],
                )
            )
            with self._tcp_condition:
                self._rtp_stats["tcp_connections"] = max(
                    0, self._rtp_stats["tcp_connections"] - 1
                )
                self._tcp_clients.discard(connection)
                self._tcp_client_queues.pop(connection, None)

    def buffer_snapshot(self):
        """Describe each reader's sender buffers, never claim audible latency."""
        now = time.monotonic()
        with self._tcp_condition:
            clients = [
                (connection, dict(state))
                for connection, state in self._tcp_client_queues.items()
            ]
        clients.sort(key=lambda entry: entry[1].get("request_id", 0))
        descriptions = []
        for connection, state in clients[:4]:
            tcp_bytes = None
            if fcntl is not None and termios is not None:
                try:
                    result = fcntl.ioctl(
                        connection.fileno(), termios.TIOCOUTQ, struct.pack("I", 0)
                    )
                    tcp_bytes = struct.unpack("I", result)[0]
                except (OSError, ValueError, AttributeError, struct.error):
                    pass
            # Linux TIOCOUTQ includes unsent/unacknowledged bytes. TCP ACKs
            # confirm receiver-kernel acceptance, not Kodi consumption.
            sent = state.get("pcm_sent", 0) + state.get("silence_sent", 0)
            descriptions.append(
                "Leser={} Alter={}ms Python_Queue={}B In_sendall={}B "
                "TCP_ausstehend={}B Audio_sendall={}B Audio_Datenmenge={}ms "
                "davon_Wanduhr_Stille={}B max_sendall={:.1f}ms letztes_sendall_vor={}ms "
                "verworfen={}B RTP_Lückenstille_eingereiht={}B Queue_Spitze={}B".format(
                    state.get("request_id", "unbekannt"),
                    int(max(0.0, now - state.get("started_at", now)) * 1000),
                    state["bytes"], state.get("pending_bytes", 0),
                    "unbekannt" if tcp_bytes is None else tcp_bytes,
                    sent, int(sent * 1000 / TCP_BYTES_PER_SECOND),
                    state.get("silence_sent", 0), state.get("max_send_ms", 0.0),
                    ("nie" if state.get("last_send_at") is None else
                     int(max(0.0, now - state["last_send_at"]) * 1000)),
                    state.get("dropped_bytes", 0),
                    state.get("gap_fill_queued", 0), state.get("queue_peak_bytes", 0),
                )
            )
        return "Leser={} [{}]; Zuordnung_zum_hörbaren_Player=unbekannt".format(
            len(clients), "; ".join(descriptions) or "keine"
        )

    def _tcp_diagnostic_counters(self):
        with self._rtp_lock:
            last_packet_at = self._rtp_stats["last_packet_at"]
            return {
                "received": self._rtp_stats["received"],
                "max_receive_gap_ms": self._rtp_stats["max_receive_gap_ms"],
                "last_loss_arrival_gap_ms": self._rtp_stats["last_loss_arrival_gap_ms"],
                "last_loss_sequence_delta": self._rtp_stats["last_loss_sequence_delta"],
                "last_loss_timestamp_delta": self._rtp_stats["last_loss_timestamp_delta"],
                "kernel_drops": (self._rtp_stats["kernel_dropped_packets"]
                                 if self._rtp_stats["kernel_dropped_packets"] is not None else "unbekannt"),
                "kernel_age_ms": (self._rtp_stats["max_kernel_queue_age_ms"]
                                  if self._rtp_stats["max_kernel_queue_age_ms"] is not None else "unbekannt"),
                "last_loss_kernel_age_ms": (self._rtp_stats["last_loss_kernel_queue_age_ms"]
                                            if self._rtp_stats["last_loss_kernel_queue_age_ms"] is not None else "unbekannt"),
                "kernel_invalid": self._rtp_stats["kernel_metadata_invalid"],
                "kernel_truncated": self._rtp_stats["kernel_metadata_truncated"],
                "nonzero": self._rtp_stats["pcm_nonzero_packets"],
                "zero": self._rtp_stats["pcm_zero_packets"],
                "packet_age_ms": (
                    "unbekannt"
                    if last_packet_at is None
                    else int(max(0.0, time.monotonic() - last_packet_at) * 1000)
                ),
            }

    def _queue_pcm(self, payload, is_gap_fill=False):
        if not payload:
            return
        with self._tcp_condition:
            if not self._playback_enabled:
                return
            for client_state in self._tcp_client_queues.values():
                client_queue = client_state["queue"]
                client_queue.append(payload)
                client_state["bytes"] += len(payload)
                client_state["queue_peak_bytes"] = max(
                    client_state.get("queue_peak_bytes", 0), client_state["bytes"]
                )
                if is_gap_fill:
                    client_state["gap_fill_queued"] = client_state.get("gap_fill_queued", 0) + len(payload)
                while client_state["bytes"] > TCP_QUEUE_LIMIT and client_queue:
                    discarded = client_queue.popleft()
                    client_state["bytes"] -= len(discarded)
                    client_state["dropped_bytes"] += len(discarded)
                    with self._rtp_lock:
                        self._rtp_stats["tcp_dropped_bytes"] += len(discarded)
            self._tcp_condition.notify_all()

    def _receive_rtp_packet(self):
        """Keep optional kernel metadata from disabling ordinary UDP reception."""
        if self._udp_drop_type is not None or self._udp_timestamp_type is not None:
            try:
                packet, ancillary, flags, sender = self._rtp_receiver.recvmsg(
                    65535, socket.CMSG_SPACE(4) + socket.CMSG_SPACE(16)
                )
                return packet, sender, ancillary, flags
            except (OSError, NotImplementedError) as error:
                if isinstance(error, OSError) and error.errno not in (
                    errno.ENOSYS, errno.EINVAL, errno.ENOTSUP, errno.EOPNOTSUPP
                ):
                    raise
                self.logger("RTP-Kerneldiagnose recvmsg nicht verfügbar ({}); "
                            "normaler UDP-Empfang bleibt aktiv.".format(type(error).__name__))
                self._udp_drop_type = None
                self._udp_timestamp_type = None
                with self._rtp_lock:
                    self._rtp_stats["kernel_dropped_packets"] = None
                    self._rtp_stats["max_kernel_queue_age_ms"] = None
                    self._rtp_stats["last_loss_kernel_queue_age_ms"] = None
        packet, sender = self._rtp_receiver.recvfrom(65535)
        return packet, sender, (), 0

    def _rtp_relay_loop(self):
        while not self._rtp_stop.is_set():
            try:
                packet, sender, ancillary, flags = self._receive_rtp_packet()
            except socket.timeout:
                continue
            except OSError:
                if not self._rtp_stop.is_set():
                    with self._rtp_lock:
                        self._rtp_stats["forward_errors"] += 1
                break

            if sender[0] != "127.0.0.1":
                continue
            metadata_truncated = bool(flags & getattr(socket, "MSG_CTRUNC", 0))
            if metadata_truncated:
                drops, kernel_age_ms, invalid = None, None, 0
            else:
                drops, kernel_age_ms, invalid = _decode_udp_ancillary(
                    ancillary, self._udp_drop_type, self._udp_timestamp_type, time.time_ns()
                )
            now = time.monotonic()
            parsed = self._rtp_header(packet)
            forward_pcm = False
            gap_silence = b""
            with self._rtp_lock:
                stats = self._rtp_stats
                stats["received"] += 1
                stats["kernel_metadata_invalid"] += invalid
                if metadata_truncated:
                    stats["kernel_metadata_truncated"] += 1
                if drops is not None:
                    stats["kernel_dropped_packets"] += (drops - self._udp_last_drop_counter) & 0xFFFFFFFF
                    self._udp_last_drop_counter = drops
                if kernel_age_ms is not None:
                    previous_age = stats["max_kernel_queue_age_ms"]
                    stats["max_kernel_queue_age_ms"] = max(previous_age or 0, kernel_age_ms)
                stats["bytes_received"] += len(packet)
                previous_packet_at = stats.get("last_packet_at")
                stats["last_packet_at"] = now
                arrival_gap_ms = (
                    0 if previous_packet_at is None else int((now - previous_packet_at) * 1000)
                )
                stats["max_receive_gap_ms"] = max(stats["max_receive_gap_ms"], arrival_gap_ms)
                if previous_packet_at is not None and now - previous_packet_at > 2.0:
                    stats["last_sequence"] = None
                    stats["last_timestamp"] = None
                    stats["last_payload_bytes"] = None
                    stats["stream_resets"] += 1
                    stats["zero_pcm_since"] = None
                if parsed is None:
                    stats["malformed"] += 1
                else:
                    sequence, timestamp, payload_bytes = parsed
                    previous_sequence = stats["last_sequence"]
                    previous_timestamp = stats["last_timestamp"]
                    previous_payload_bytes = stats["last_payload_bytes"]
                    if previous_sequence is None:
                        stats["last_sequence"] = sequence
                        stats["last_timestamp"] = timestamp
                        stats["last_payload_bytes"] = payload_bytes
                        forward_pcm = True
                    else:
                        sequence_delta = (sequence - previous_sequence) & 0xFFFF
                        if sequence_delta == 0:
                            stats["duplicates"] += 1
                        elif sequence_delta < 0x8000:
                            if sequence_delta > 1:
                                stats["sequence_gaps"] += sequence_delta - 1
                                stats["last_loss_arrival_gap_ms"] = arrival_gap_ms
                                stats["last_loss_sequence_delta"] = sequence_delta
                                stats["last_loss_kernel_queue_age_ms"] = kernel_age_ms
                            if previous_timestamp is not None:
                                timestamp_delta = (timestamp - previous_timestamp) & 0xFFFFFFFF
                                if sequence_delta > 1:
                                    stats["last_loss_timestamp_delta"] = timestamp_delta
                                expected_delta = (
                                    previous_payload_bytes // (CHANNELS * 2)
                                    if previous_payload_bytes is not None
                                    else 0
                                )
                                if expected_delta and timestamp_delta != expected_delta:
                                    stats["timestamp_jumps"] += 1
                                    missing_frames = timestamp_delta - expected_delta
                                    if (
                                        sequence_delta > 1
                                        and 0 < missing_frames <= RATE // 4
                                    ):
                                        gap_silence = b"\x00" * (
                                            missing_frames * CHANNELS * TCP_SAMPLE_BYTES
                                        )
                                        stats["silence_filled_frames"] += missing_frames
                            stats["last_sequence"] = sequence
                            stats["last_timestamp"] = timestamp
                            stats["last_payload_bytes"] = payload_bytes
                            forward_pcm = True
                        else:
                            stats["out_of_order"] += 1
            if forward_pcm:
                payload = self._rtp_payload(packet)
                if len(payload) % (CHANNELS * 2) == 0:
                    with self._rtp_lock:
                        if any(payload):
                            self._rtp_stats["pcm_nonzero_packets"] += 1
                            self._rtp_stats["last_nonzero_pcm_at"] = now
                            self._rtp_stats["zero_pcm_since"] = None
                        else:
                            self._rtp_stats["pcm_zero_packets"] += 1
                            if self._rtp_stats["zero_pcm_since"] is None:
                                self._rtp_stats["zero_pcm_since"] = now
                    if gap_silence:
                        self._queue_pcm(gap_silence, is_gap_fill=True)
                    # RTP L16 is big-endian; Matroska declares little-endian PCM.
                    # Change byte order only; preserve samples and channel order.
                    little_endian = bytearray(len(payload))
                    little_endian[0::2] = payload[1::2]
                    little_endian[1::2] = payload[0::2]
                    self._queue_pcm(bytes(little_endian))
                else:
                    with self._rtp_lock:
                        self._rtp_stats["malformed"] += 1

    def _load_module(self, module_name, *arguments):
        result = self._pactl("load-module", module_name, *arguments)
        if not result.isdigit():
            raise AudioSetupError("PulseAudio hat keine Modul-ID zurückgegeben")
        module_id = result
        self.module_ids.append(module_id)
        return module_id

    def _cleanup_stale_owned_sinks(self):
        """Remove unused virtual sinks left by a prior interrupted service run."""
        resource = "sinks"
        try:
            sinks = json.loads(self._pactl("--format=json", "list", resource))
            resource = "sink-inputs"
            inputs = json.loads(self._pactl("--format=json", "list", resource))
            resource = "modules"
            # PulseAudio 17's JSON module rows omit the numeric index.
            # The tabular short form contains the ID required by unload-module.
            modules = []
            for line in self._pactl("list", "short", "modules").splitlines():
                fields = line.split("\t", 2)
                if (
                    len(fields) < 2
                    or not fields[0].isascii()
                    or not fields[0].isdigit()
                    or not fields[1]
                    or any(char.isspace() for char in fields[1])
                ):
                    raise AudioSetupError("Ungültige PulseAudio-Modulkurzliste")
                modules.append({
                    "index": fields[0],
                    "name": fields[1],
                    "argument": fields[2].strip() if len(fields) > 2 else "",
                })
        except AudioSetupError as error:
            self.logger(
                "Alte Soloist-PulseAudio-Sinks bleiben bestehen: "
                "Statusabfrage {} fehlgeschlagen: {}.".format(resource, error)
            )
            return
        except json.JSONDecodeError as error:
            # Log only parser location, never the raw PulseAudio response,
            # which can contain application arguments and personal metadata.
            self.logger(
                "Alte Soloist-PulseAudio-Sinks bleiben bestehen: "
                "Statusabfrage {} lieferte ungültiges JSON "
                "(Zeile {}, Spalte {}).".format(resource, error.lineno, error.colno)
            )
            return
        if not all(isinstance(value, list) for value in (sinks, inputs, modules)):
            self.logger(
                "Alte Soloist-PulseAudio-Sinks bleiben bestehen: "
                "PulseAudio lieferte ungültige Modul-/Streamdaten."
            )
            return

        stale_names = {
            sink.get("name")
            for sink in sinks
            if isinstance(sink.get("name"), str)
            and sink.get("name") != self.sink_name
            and re.fullmatch(re.escape(SINK_NAME) + r"_\d+_\d+", sink.get("name"))
        }
        if not stale_names:
            return

        active_sink_indexes = {
            str(item.get("sink"))
            for item in inputs
            if item.get("sink") is not None
        }
        module_targets = {}
        for module in modules:
            argument = module.get("argument") or ""
            if not isinstance(argument, str):
                continue
            null_match = re.search(r"(?:^|\s)sink_name=([^\s]+)", argument)
            source_match = re.search(r"(?:^|\s)source=([^\s]+)", argument)
            if module.get("name") == "module-null-sink" and null_match:
                module_targets.setdefault(null_match.group(1), {"null": [], "rtp": []})[
                    "null"
                ].append(module.get("index"))
            elif module.get("name") == "module-rtp-send" and source_match:
                source_name = source_match.group(1)
                if source_name.endswith(".monitor"):
                    sink_name = source_name[:-len(".monitor")]
                    module_targets.setdefault(sink_name, {"null": [], "rtp": []})[
                        "rtp"
                    ].append(module.get("index"))

        removed = 0
        skipped_active = 0
        for sink in sinks:
            sink_name = sink.get("name")
            if sink_name not in stale_names:
                continue
            target = module_targets.get(sink_name)
            if not target or not target["null"]:
                continue
            if (
                str(sink.get("index")) in active_sink_indexes
                or sink_name == self.default_sink
            ):
                skipped_active += 1
                continue
            for module_id in target["rtp"] + target["null"]:
                if module_id is None:
                    continue
                try:
                    self._pactl("unload-module", str(module_id))
                except AudioSetupError:
                    self.logger(
                        "Alter Soloist-PulseAudio-Sink {} konnte nicht vollständig "
                        "entfernt werden.".format(sink_name)
                    )
                    break
            else:
                removed += 1

        if removed or skipped_active:
            self.logger(
                "Alte Soloist-PulseAudio-Sinks: {} entfernt, {} wegen aktiver "
                "Nutzung/Standardroute belassen.".format(removed, skipped_active)
            )

    def availability(self):
        """None if PulseAudio is usable, else "missing", "not_running" or "no_sink".

        Checked before downloading Soloist, so a system without PulseAudio
        (or PipeWire's PulseAudio layer) gets a clear message instead.
        """
        try:
            result = self.runner(["pactl", "info"], stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, timeout=5, check=False)
        except FileNotFoundError:
            return "missing"
        except (OSError, subprocess.TimeoutExpired):
            return "not_running"
        if result.returncode != 0:
            return "not_running"
        try:
            if not self._pactl("get-default-sink"):
                return "no_sink"
        except AudioSetupError:
            return "no_sink"
        return None

    def setup(self):
        if self.module_ids:
            return self.playback_url
        self.default_sink = self._pactl("get-default-sink")
        if not self.default_sink:
            raise AudioSetupError("PulseAudio meldet keinen aktiven Standard-Sink")
        self.original_inputs = self._sink_input_routes()
        self._cleanup_stale_owned_sinks()
        self.port = self._free_rtp_port()
        try:
            self._start_transport()
            self._load_module(
                "module-null-sink",
                "sink_name={}".format(self.sink_name),
                # Float keeps Soloist's volume attenuation lossless; the RTP
                # sender compensates it before converting to 16 bit.
                "format=float32le",
                "rate={}".format(RATE),
                "channels={}".format(CHANNELS),
                "sink_properties=device.description=Soloist_Capture_INTERNAL",
            )
            self._load_module(
                "module-rtp-send",
                "source={}.monitor".format(self.sink_name),
                "destination_ip=127.0.0.1",
                "port={}".format(self.port),
                "format=s16be",
                "rate={}".format(RATE),
                "channels={}".format(CHANNELS),
                "ttl=1",
                # A monitor source otherwise permits automatic suspension.
                # Keep this owned capture path alive across renderer gaps;
                # confirmed Spotify pause gates/closes TCP independently.
                "inhibit_auto_suspend=always",
            )
            # module-switch-on-connect can change the default when the new
            # null sink appears. Restore only the value observed before setup.
            current_sink = self._pactl("get-default-sink")
            if current_sink == self.sink_name:
                if self.default_sink in self._sink_names():
                    self._pactl("set-default-sink", self.default_sink)
                elif self.default_sink != "auto_null":
                    raise AudioSetupError(
                        "Der vorherige PulseAudio-Standardausgang ist nicht mehr vorhanden"
                    )
            self._restore_moved_inputs()
        except Exception:
            self.cleanup()
            raise
        self.logger(
            "PulseAudio-RTP zu lokalem direktem TCP-Matroska-PCM für Kodi eingerichtet "
            "({} Hz, UDP-Eingang Port {}, Quelle {}).".format(
                RATE,
                self.port,
                self.playback_url,
            )
        )
        return self.playback_url

    def compensate_stream_volume(self):
        """Undo Soloist's volume before the 16-bit RTP conversion.

        Soloist applies the Spotify app volume to its PulseAudio stream and
        follows changes made to it, so the stream is left alone. The capture
        sink mixes in float (lossless); the RTP sender's recording stream
        gets the inverse gain, so 16 bits carry the full level. Kodi applies
        the app volume instead. Returns the gain set (raw PA volume) or None.
        """
        if not self.module_ids:
            return None
        sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
        inputs = json.loads(self._pactl("--format=json", "list", "sink-inputs"))
        outputs = json.loads(self._pactl("--format=json", "list", "source-outputs"))
        sink = next((item for item in sinks if item.get("name") == self.sink_name), None)
        if sink is None:
            return None
        values = [channel.get("value") for item in inputs if item.get("sink") == sink.get("index")
                  for channel in (item.get("volume") or {}).values() if isinstance(channel, dict)]
        values = [value for value in values if isinstance(value, int) and value > 0]
        if not values:
            return None
        attenuation = max(values)
        gain = PA_VOLUME_NORM * PA_VOLUME_NORM // attenuation
        # The RTP sender is the second module we load (after the null sink).
        rtp_module = str(self.module_ids[-1])
        for item in outputs:
            if str(item.get("owner_module")) != rtp_module:
                continue
            current = [channel.get("value") for channel in (item.get("volume") or {}).values()
                       if isinstance(channel, dict)]
            if current and all(isinstance(value, int) and abs(value - gain) <= gain // 100
                               for value in current):
                return gain
            self._pactl("set-source-output-volume", str(item.get("index")), str(gain))
            return gain
        return None

    def _sink_input_routes(self):
        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
            inputs = json.loads(self._pactl("--format=json", "list", "sink-inputs"))
        except ValueError as error:
            raise AudioSetupError(
                "Vorhandene PulseAudio-Streams können nicht sicher geprüft werden"
            ) from error
        if not isinstance(sinks, list) or not isinstance(inputs, list):
            raise AudioSetupError("PulseAudio lieferte ungültige Streamdaten")
        names_by_index = {sink.get("index"): sink.get("name") for sink in sinks}
        return {
            str(item.get("index")): names_by_index.get(item.get("sink"))
            for item in inputs
            if item.get("index") is not None and names_by_index.get(item.get("sink"))
        }

    def diagnostic_snapshot(self):
        """Return the last PulseAudio snapshot and refresh it off the service loop."""
        with self._diagnostic_cache_lock:
            worker = self._diagnostic_worker
            if worker is None or not worker.is_alive():
                worker = threading.Thread(
                    target=self._refresh_diagnostic_snapshot,
                    name="soloist-audio-diagnostic",
                    daemon=True,
                )
                self._diagnostic_worker = worker
                worker.start()
            snapshot = self._diagnostic_cache
            captured_at = self._diagnostic_cache_at
        if captured_at is None:
            return "{} Snapshot=ausstehend".format(snapshot)
        age_ms = int(max(0.0, time.monotonic() - captured_at) * 1000)
        return "{} Snapshot_vor={}ms".format(snapshot, age_ms)

    def recovery_snapshot(self):
        """Expose live input and TCP progress for a conservative player recovery."""
        with self._rtp_lock:
            last_packet_at = self._rtp_stats["last_packet_at"]
            sent_bytes = self._rtp_stats["tcp_bytes_sent"]
            dropped_bytes = self._rtp_stats["tcp_dropped_bytes"]
            connections = self._rtp_stats["tcp_connections"]
            last_nonzero_pcm_at = self._rtp_stats["last_nonzero_pcm_at"]
            zero_pcm_since = self._rtp_stats["zero_pcm_since"]
            pcm_nonzero_packets = self._rtp_stats["pcm_nonzero_packets"]
            pcm_zero_packets = self._rtp_stats["pcm_zero_packets"]
        packet_age_ms = (
            None
            if last_packet_at is None
            else int(max(0.0, time.monotonic() - last_packet_at) * 1000)
        )
        nonzero_pcm_age_ms = (
            None
            if last_nonzero_pcm_at is None
            else int(
                max(0.0, time.monotonic() - last_nonzero_pcm_at) * 1000
            )
        )
        zero_pcm_run_ms = (
            0
            if zero_pcm_since is None
            else int(max(0.0, time.monotonic() - zero_pcm_since) * 1000)
        )
        return {
            "packet_age_ms": packet_age_ms,
            "nonzero_pcm_age_ms": nonzero_pcm_age_ms,
            "zero_pcm_run_ms": zero_pcm_run_ms,
            "nonzero_packets": pcm_nonzero_packets,
            "zero_packets": pcm_zero_packets,
            "sent_bytes": sent_bytes,
            "dropped_bytes": dropped_bytes,
            "connections": connections,
        }

    def request_zero_pcm_recovery(self, cooldown=300.0):
        """Briefly resume the add-on-owned PulseAudio sink after sustained silence.

        This never restarts Soloist or changes its queue/track position. The
        operation is asynchronous because pactl can block while PulseAudio is
        unhealthy. PCM telemetry, not this request, determines whether it worked.
        """
        with self._sink_recovery_lock:
            if self._sink_recovery_thread is not None and self._sink_recovery_thread.is_alive():
                return "already_running"
            now = time.monotonic()
            if now - self._sink_recovery_last_attempt < cooldown:
                return "cooldown"
            self._sink_recovery_last_attempt = now
            worker = threading.Thread(
                target=self._reset_owned_sink,
                name="soloist-pulseaudio-recovery",
                daemon=True,
            )
            self._sink_recovery_thread = worker
            worker.start()
        return "started"

    def _reset_owned_sink(self):
        """Suspend and resume only the virtual sink created by this add-on."""
        if not self.module_ids or not self.sink_name:
            self.logger("PulseAudio-Wiederherstellung übersprungen: Soloist-Sink fehlt.")
            return
        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
            inputs = json.loads(self._pactl("--format=json", "list", "sink-inputs"))
            sink = next(
                (entry for entry in sinks if entry.get("name") == self.sink_name),
                None,
            )
            if sink is None:
                raise AudioSetupError("Der add-on-eigene PulseAudio-Sink fehlt")
            sink_index = str(sink.get("index"))
            routed = [
                item for item in inputs
                if str(item.get("sink")) == sink_index
            ]
            active_inputs = [
                item for item in routed
                if str(item.get("corked", "false")).lower() not in ("true", "yes", "1")
            ]
            if not active_inputs:
                reason = ("Soloist-Eingang pausiert (corked)" if routed
                          else "kein Soloist-Eingang am virtuellen Sink")
                self.logger("PulseAudio-Wiederherstellung übersprungen: {}. "
                            "Kein Suspend/Resume ausgeführt.".format(reason))
                return

            self.logger(
                "PulseAudio-Wiederherstellung: add-on-eigenen Soloist-Sink "
                "kurz aus- und eingeschaltet; Queue und Track bleiben unangetastet."
            )
            suspend_error = None
            try:
                self._pactl("suspend-sink", self.sink_name, "1")
            except Exception as error:
                # A timeout can occur after PulseAudio applied the request, so
                # always issue the idempotent resume command below.
                suspend_error = error
            else:
                time.sleep(0.25)
            finally:
                try:
                    self._pactl("suspend-sink", self.sink_name, "0")
                except Exception:
                    self.logger(
                        "PulseAudio-Sink konnte nicht sicher fortgesetzt werden; "
                        "zweiter Fortsetzungsversuch läuft."
                    )
                    time.sleep(0.5)
                    self._pactl("suspend-sink", self.sink_name, "0")
            if suspend_error is not None:
                raise suspend_error
            self.logger(
                "PulseAudio-Sink-Neustart angefordert; Erfolg wird anhand "
                "erneut eintreffender Nichtnull-PCM-Pakete geprüft."
            )
        except Exception as error:
            self.logger(
                "PulseAudio-Wiederherstellung fehlgeschlagen ({}).".format(
                    type(error).__name__
                )
            )

    def _refresh_diagnostic_snapshot(self):
        try:
            snapshot = self._collect_diagnostic_snapshot()
        except Exception as error:
            snapshot = "PulseAudio-Probe=Fehler-{}".format(type(error).__name__)
        with self._diagnostic_cache_lock:
            self._diagnostic_cache = snapshot
            self._diagnostic_cache_at = time.monotonic()

    def _collect_diagnostic_snapshot(self):
        """Return PulseAudio state and optional RTP relay counters."""
        if not self.module_ids or self.port is None:
            return "RTP-Pfad=nicht eingerichtet"

        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
            sink_inputs = json.loads(
                self._pactl("--format=json", "list", "sink-inputs")
            )
        except (AudioSetupError, ValueError):
            return "RTP-Pfad=Statusabfrage fehlgeschlagen"

        if not isinstance(sinks, list) or not isinstance(sink_inputs, list):
            return "RTP-Pfad=ungültige PulseAudio-Antwort"

        sink = next(
            (entry for entry in sinks if entry.get("name") == self.sink_name),
            None,
        )
        if sink is None:
            return "RTP-Pfad=Soloist-Sink fehlt"

        sink_index = sink.get("index")
        routed_inputs = [
            entry
            for entry in sink_inputs
            if str(entry.get("sink")) == str(sink_index)
        ]
        corked_inputs = sum(
            1
            for entry in routed_inputs
            if entry.get("corked") is True
            or str(entry.get("corked", "")).lower() in ("yes", "true", "1")
        )
        with self._rtp_lock:
            stats = dict(self._rtp_stats)
            previous = dict(self._rtp_reported)
            self._rtp_reported = dict(stats)
        last_packet_at = stats.get("last_packet_at")
        packet_age_ms = (
            "unbekannt"
            if last_packet_at is None
            else str(int(max(0.0, time.monotonic() - last_packet_at) * 1000))
        )
        rtp = (
            "UDP_RTP_empfangen=+{received} Bytes=+{bytes_received} "
            "TCP_an_Kodi_gesendet=+{tcp_bytes_sent} TCP_Verbindungen={tcp_connections} "
            "TCP_Puffer_verworfen=+{tcp_dropped_bytes} Lücken=+{sequence_gaps} "
            "RTP_Neustarts=+{stream_resets} "
            "PCM_Nichtnullpakete=+{pcm_nonzero_packets} "
            "PCM_Nullpakete=+{pcm_zero_packets} "
            "Duplikate=+{duplicates} ungeordnet=+{out_of_order} "
            "Zeitstempelsprünge=+{timestamp_jumps} ungültig=+{malformed} "
            "Stille_bei_kleinen_Lücken=+{silence_filled_frames}Frames "
            "letztes_RTP_Paket_vor={packet_age_ms}ms "
            "letztes_Nichtnull_PCM_vor={nonzero_pcm_age_ms}ms "
            "Nullsignal_Dauer={zero_pcm_run_ms}ms"
        ).format(
            received=stats["received"] - previous["received"],
            bytes_received=stats["bytes_received"] - previous["bytes_received"],
            tcp_bytes_sent=stats["tcp_bytes_sent"] - previous["tcp_bytes_sent"],
            tcp_connections=stats["tcp_connections"],
            tcp_dropped_bytes=(
                stats["tcp_dropped_bytes"] - previous["tcp_dropped_bytes"]
            ),
            sequence_gaps=stats["sequence_gaps"] - previous["sequence_gaps"],
            stream_resets=stats["stream_resets"] - previous["stream_resets"],
            pcm_nonzero_packets=(
                stats["pcm_nonzero_packets"] - previous["pcm_nonzero_packets"]
            ),
            pcm_zero_packets=(stats["pcm_zero_packets"] - previous["pcm_zero_packets"]),
            duplicates=stats["duplicates"] - previous["duplicates"],
            out_of_order=stats["out_of_order"] - previous["out_of_order"],
            timestamp_jumps=stats["timestamp_jumps"] - previous["timestamp_jumps"],
            malformed=stats["malformed"] - previous["malformed"],
            silence_filled_frames=(
                stats["silence_filled_frames"] - previous["silence_filled_frames"]
            ),
            packet_age_ms=packet_age_ms,
            zero_pcm_run_ms=(
                0
                if stats["zero_pcm_since"] is None
                else int(
                    max(0.0, time.monotonic() - stats["zero_pcm_since"]) * 1000
                )
            ),
            nonzero_pcm_age_ms=(
                "unbekannt"
                if stats["last_nonzero_pcm_at"] is None
                else int(
                    max(0.0, time.monotonic() - stats["last_nonzero_pcm_at"])
                    * 1000
                )
            ),
        )
        return "PulseAudio-Sinkzustand={} Eingänge={} pausierte_Eingänge={} " \
            "RTP-Sendemodul=geladen RTP-Eingangsport={} {}".format(
                sink.get("state", "unbekannt"),
                len(routed_inputs),
                corked_inputs,
                self.port,
                rtp,
            )

    def _sink_names(self):
        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
        except ValueError as error:
            raise AudioSetupError(
                "Vorhandene PulseAudio-Ausgänge können nicht sicher geprüft werden"
            ) from error
        if not isinstance(sinks, list):
            raise AudioSetupError("PulseAudio lieferte ungültige Ausgangsdaten")
        return {sink.get("name") for sink in sinks if sink.get("name")}

    def _restore_moved_inputs(self):
        if not self.original_inputs:
            return
        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
            inputs = json.loads(self._pactl("--format=json", "list", "sink-inputs"))
        except ValueError as error:
            raise AudioSetupError(
                "Bestehende PulseAudio-Streams können nicht geprüft werden"
            ) from error
        if not isinstance(sinks, list) or not isinstance(inputs, list):
            raise AudioSetupError("PulseAudio lieferte ungültige Streamdaten")
        names_by_index = {sink.get("index"): sink.get("name") for sink in sinks}
        for item in inputs:
            input_id = str(item.get("index"))
            previous_sink = self.original_inputs.get(input_id)
            current_sink = names_by_index.get(item.get("sink"))
            if previous_sink and current_sink == self.sink_name:
                if previous_sink == "auto_null" and previous_sink not in names_by_index.values():
                    continue
                try:
                    self._pactl("move-sink-input", input_id, previous_sink)
                except AudioSetupError as error:
                    raise AudioSetupError(
                        "Ein bestehender PulseAudio-Stream konnte nicht zurückgesetzt werden"
                    ) from error

    def cleanup(self):
        recovery_thread = self._sink_recovery_thread
        if recovery_thread is not None and recovery_thread.is_alive():
            # At most four pactl calls can each consume their five-second
            # subprocess timeout, including the fallback resume attempt.
            recovery_thread.join(timeout=26.0)
        transport_error = None
        try:
            self._stop_transport()
        except (OSError, RuntimeError, ValueError, AudioSetupError, subprocess.TimeoutExpired) as error:
            transport_error = error
            self.logger("Audiotransport konnte nicht vollständig beendet werden ({}).".format(
                type(error).__name__))
        if self.default_sink:
            try:
                current_sink = self._pactl("get-default-sink")
                if current_sink == self.sink_name:
                    if self.default_sink in self._sink_names():
                        self._pactl("set-default-sink", self.default_sink)
                self._restore_moved_inputs()
            except AudioSetupError:
                pass
        for module_id in reversed(self.module_ids):
            try:
                self._pactl("unload-module", module_id)
            except AudioSetupError:
                self.logger("Ein vom Add-on angelegtes PulseAudio-Modul blieb geladen")
        self.module_ids = []
        self.original_inputs = {}
        self.playback_url = None
        with self._tcp_condition:
            self._tcp_client_queues.clear()
            self._tcp_clients.clear()
        self.port = None
        self.default_sink = None
        if transport_error is not None:
            raise AudioSetupError("Audioende konnte nicht bestätigt werden") from transport_error

    def set_playback_enabled(self, enabled):
        """End paused responses; never retain pause PCM for a later reader."""
        with self._tcp_condition:
            self._playback_enabled = bool(enabled)
            if not enabled:
                for state in self._tcp_client_queues.values():
                    state["queue"].clear()
                    state["bytes"] = 0
            self._tcp_condition.notify_all()
        if not enabled:
            self.close_tcp_clients("Bestätigte Soloist-Pause")

    def close_tcp_clients(self, reason="Kodi-Player wird beendet"):
        """Close local PCM readers before asking Kodi to stop its player."""
        with self._tcp_condition:
            tcp_clients = list(self._tcp_clients)
            self._tcp_condition.notify_all()
        for client in tcp_clients:
            try:
                client.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                client.close()
            except OSError:
                pass
        if tcp_clients:
            self.logger(
                "TCP-PCM-Verbindungen vor Playerstopp geschlossen: {}; Anzahl={}.".format(
                    reason, len(tcp_clients)
                )
            )
        return len(tcp_clients)


def playback_snapshot(event, previous=None):
    """Merge Soloist's full and incremental playback events safely."""
    state = dict(previous) if isinstance(previous, dict) else {}
    if not isinstance(event, dict):
        return state
    event_type = event.get("type")
    if event_type == "playback_state":
        return event
    if event_type == "track_changed":
        state["item"] = event.get("item")
        # position_sync has no track ID. Never carry the previous song's
        # anchor across this ordered track boundary; wait for the next sync.
        state.pop("position", None)
    elif event_type == "playback_changed":
        state["status"] = event.get("status")
    elif event_type == "position_sync":
        state["position"] = event.get("position")
    elif event_type == "device_changed":
        state["is_active"] = event.get("is_active")
    elif event_type == "auth_state":
        state["logged_in"] = event.get("logged_in")
        state["is_active"] = event.get("is_active")
    return state


def music_item_revision(item, artist_mbids=None, artist_fanart=""):
    """Fingerprint the exact metadata handed to Kodi, including library fanart."""
    return hashlib.sha256(json.dumps(
        [item, artist_mbids or {}, artist_fanart or ""],
        sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")).hexdigest()


def kodi_music_item(event, playback_url, list_item_factory, artist_mbids_by_uri=None,
                    diagnostic_logger=None, artist_fanart=""):
    """Map Soloist entity metadata to a Kodi music ListItem."""
    if not isinstance(event, dict):
        return None
    item = event.get("item")
    if not isinstance(item, dict):
        return None
    decorations = item.get("decorations") or {}
    if not isinstance(decorations, dict):
        return None
    identity = decorations.get("identity") or {}
    if not isinstance(identity, dict):
        return None
    title = _clean_text(identity.get("name"), 512)
    if not title:
        return None

    artist_entries = _creator_entries(decorations)
    artists = []
    for artist in artist_entries:
        if artist["name"] not in artists:
            artists.append(artist["name"])
    if not artists:
        artists = ["Unknown"]

    parent = decorations.get("parent") or {}
    if not isinstance(parent, dict):
        parent = {}
    album_entity = parent.get("entity") or {}
    if isinstance(album_entity, dict):
        album_decorations = album_entity.get("decorations") or {}
        if isinstance(album_decorations, dict):
            album_identity = album_decorations.get("identity") or {}
        else:
            album_identity = {}
        if isinstance(album_identity, dict):
            album = _clean_text(album_identity.get("name"), 512)
        else:
            album = ""
    else:
        album = ""
        album_decorations = {}
    album_artists = _creator_names(album_decorations)
    if not album_artists:
        album_artists = artists
    playback = decorations.get("playback") or {}
    if not isinstance(playback, dict):
        playback = {}
    content_ratings = playback.get("content_ratings") or []
    if not isinstance(content_ratings, list):
        content_ratings = []
    content_ratings = [
        _clean_text(rating, 64)
        for rating in content_ratings[:8]
        if _clean_text(rating, 64)
    ]
    build_started = time.monotonic()
    # This is a private metadata/resolve item, never an item owned by a GUI
    # control. Kodi propagates offscreen to InfoTagMusic and avoids GUI locks.
    build_completed = False
    try:
        list_item = list_item_factory(label=title, path=playback_url, offscreen=True)
        # Metadata updates run synchronously inside Kodi. Never let Kodi probe
        # this Python-served URL while the caller can hold the interpreter lock.
        # Every fresh item (including track/MBID updates) needs the known type.
        list_item.setMimeType(AUDIO_MIME_TYPE)
        list_item.setContentLookup(False)
        info_tag = list_item.getMusicInfoTag()
        info_tag.setTitle(title)
        info_tag.setArtist(" / ".join(artists))
        info_tag.setAlbum(album)
        info_tag.setAlbumArtist(" / ".join(album_artists))
        info_tag.setComment(", ".join(content_ratings))
        info_tag.setMediaType("song")
        # Kodi falls back to stream-time / MusicInfoTag.duration for progress
        # when the demuxer has no duration. That would combine different clocks.
        # Keep duration_ms in Soloist's state, not in this live stream's tag.
        artist_mbids_by_uri = artist_mbids_by_uri or {}
        artist_mbids = []
        # Kodi aligns artist IDs by position, so omit them until every artist is known.
        if len(artist_entries) == len(artists):
            for artist in artist_entries:
                mbid = artist_mbids_by_uri.get(artist["uri"])
                if not isinstance(mbid, str) or not mbid:
                    artist_mbids = []
                    break
                artist_mbids.append(mbid)
        if len(artist_mbids) == len(artists) and artist_mbids:
            info_tag.setMusicBrainzArtistID(artist_mbids)
        visual_identity = decorations.get("visual_identity") or {}
        if not isinstance(visual_identity, dict):
            visual_identity = {}
        covers = visual_identity.get("cover") or []
        if not isinstance(covers, list):
            covers = []
        size_rank = {"small": 0, "default": 1, "large": 2, "xlarge": 3}
        selected_cover = None
        selected_rank = -1
        for cover in covers[:32]:
            if not isinstance(cover, dict):
                continue
            url = cover.get("url", "")
            if _is_spotify_cover(url):
                rank = size_rank.get(str(cover.get("size", "")).lower(), -1)
                if selected_cover is None or rank > selected_rank:
                    selected_cover = url
                    selected_rank = rank
        # An explicit empty key clears the preceding artist's art on updates.
        # Track covers and artist backgrounds have different native art slots.
        if (not isinstance(artist_fanart, str) or len(artist_fanart) > 8192
                or any(ord(char) < 32 or 127 <= ord(char) <= 159 for char in artist_fanart)):
            artist_fanart = ""
        list_item.setArt({"thumb": selected_cover or "", "icon": selected_cover or "",
                          "fanart": artist_fanart})
        build_completed = True
        return list_item
    finally:
        if diagnostic_logger is not None:
            diagnostic_logger("Kodi-Metadatenaufbau: {:.1f}ms, Offscreen=true, abgeschlossen={}.".format(
                (time.monotonic() - build_started) * 1000, build_completed
            ))


def _creator_names(decorations):
    names = []
    for artist in _creator_entries(decorations):
        if artist["name"] not in names:
            names.append(artist["name"])
    return names


def creator_artists(item):
    """Return validated Spotify artist URIs and names from a Soloist item."""
    if not isinstance(item, dict):
        return []
    decorations = item.get("decorations") or {}
    if not isinstance(decorations, dict):
        return []
    return _creator_entries(decorations)


def _creator_entries(decorations):
    if not isinstance(decorations, dict):
        return []
    creators = decorations.get("creators") or []
    if not isinstance(creators, list):
        return []
    artists = []
    seen = set()
    for creator in creators[:32]:
        if not isinstance(creator, dict):
            continue
        entity = creator.get("entity") or {}
        if not isinstance(entity, dict):
            continue
        entity_decorations = entity.get("decorations") or {}
        if not isinstance(entity_decorations, dict):
            continue
        identity = entity_decorations.get("identity") or {}
        if not isinstance(identity, dict):
            continue
        name = _clean_text(identity.get("name"), 256)
        uri = entity.get("uri")
        if not isinstance(uri, str):
            uri = ""
        key = (uri, name)
        if name and key not in seen:
            seen.add(key)
            artists.append({"uri": uri, "name": name})
    return artists


def _clean_text(value, maximum):
    if not isinstance(value, str):
        return ""
    clean = " ".join(value.split())
    return clean[:maximum]


def _is_spotify_cover(value):
    if not isinstance(value, str):
        return False
    return value.startswith("https://i.scdn.co/") or value.startswith("https://mosaic.scdn.co/")


def estimated_position_ms(position):
    """Estimate only from Soloist's position anchor; never from Kodi's stream clock."""
    if not isinstance(position, dict):
        return None
    anchor = position.get("position_ms")
    timestamp = position.get("timestamp_ms")
    speed = position.get("speed")
    try:
        if not all(
            not isinstance(value, bool) and isinstance(value, (int, float))
            and math.isfinite(value) for value in (anchor, timestamp, speed)
        ) or anchor < 0:
            return None
        anchor += max(0.0, time.time() * 1000 - timestamp) * speed
        return max(0, int(anchor)) if math.isfinite(anchor) else None
    except OverflowError:
        return None
