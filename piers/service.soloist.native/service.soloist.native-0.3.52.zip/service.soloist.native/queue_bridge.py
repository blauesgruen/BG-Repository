"""Native Kodi neighbours and serialized Soloist controls for a live stream."""

import hashlib
import json
import queue
import re
import threading
import time
import uuid
from collections import deque
from urllib.parse import parse_qs, urlsplit

import xbmc
import xbmcgui

from audio import estimated_position_ms, kodi_music_item

PREFIX = "service.soloist.native.queue."
REQUEST_PROPERTY = PREFIX + "request"
RESOLVE_TIMEOUT = 10.0
COMMAND_TIMEOUT = 7.0
MAX_PAYLOAD_BYTES = 262144
TOKEN_PATTERN = re.compile(r"[0-9a-f]{32}")
URI_PATTERN = re.compile(r"spotify:(?:track|episode):[A-Za-z0-9]{22}")


def item_uri(item):
    uri = item.get("uri") if isinstance(item, dict) else None
    return uri if isinstance(uri, str) and URI_PATTERN.fullmatch(uri) else None


def item_title(item):
    decorations = item.get("decorations") if isinstance(item, dict) else None
    identity = decorations.get("identity") if isinstance(decorations, dict) else None
    title = identity.get("name") if isinstance(identity, dict) else None
    return " ".join(title.split())[:512] if isinstance(title, str) else ""


def neighbor(event, direction, current_uri):
    """Reject ambiguous URI occurrences: playback events do not expose queue UIDs."""
    if not isinstance(event, dict):
        return None
    entries = event.get("previous" if direction == "previous" else "upcoming")
    if not isinstance(entries, list) or not entries:
        return None
    entry = entries[0]
    if not isinstance(entry, dict) or not item_uri(entry.get("item")):
        return None
    uri = item_uri(entry["item"])
    decorations = entry["item"].get("decorations")
    identity = decorations.get("identity") if isinstance(decorations, dict) else None
    title = identity.get("name") if isinstance(identity, dict) else None
    if not isinstance(title, str) or not title.strip():
        return None
    uid = entry.get("uid") or uri
    if not isinstance(uid, str) or len(uid) > 1024 or uri == current_uri:
        return None
    all_entries = []
    for field in ("previous", "upcoming"):
        values = event.get(field)
        if not isinstance(values, list) or len(values) > 10:
            return None
        all_entries.extend(values)
    if sum(isinstance(value, dict) and item_uri(value.get("item")) == uri
           for value in all_entries) != 1:
        return None
    if sum(isinstance(value, dict) and (value.get("uid") or item_uri(value.get("item"))) == uid
           for value in all_entries) != 1:
        return None
    return {"uid": uid, "uri": uri, "item": entry["item"]}


def neighbors(event, direction, current_uri, limit=10):
    """Return consecutive unambiguous queue neighbours, nearest first."""
    if (not isinstance(event, dict) or direction not in ("previous", "upcoming")
            or isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0):
        return []
    limit = min(limit, 10)
    previous = event.get("previous")
    upcoming = event.get("upcoming")
    if (not isinstance(previous, list) or not isinstance(upcoming, list)
            or len(previous) > 10 or len(upcoming) > 10):
        return []

    entries = previous + upcoming
    uri_counts = {}
    uid_counts = {}
    normalized = {}
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        item = entry.get("item")
        uri = item_uri(item)
        uid = entry.get("uid") or uri
        if uri is not None:
            uri_counts[uri] = uri_counts.get(uri, 0) + 1
        if isinstance(uid, str) and uid:
            uid_counts[uid] = uid_counts.get(uid, 0) + 1
        if (uri is not None and item_title(item) and isinstance(uid, str) and uid and len(uid) <= 1024):
            normalized[id(entry)] = {"uid": uid, "uri": uri, "item": item}

    result = []
    for entry in event[direction]:
        candidate = normalized.get(id(entry))
        if candidate is None:
            break
        uri = candidate["uri"]
        uid = candidate["uid"]
        if (uri == current_uri or uri_counts[uri] != 1 or uid_counts[uid] != 1):
            break
        result.append(candidate)
        if len(result) >= limit:
            break
    return result


def result_key(operation):
    return PREFIX + operation + ".result"


def registry_data(raw):
    """A slot URL is stable; each published target has an immutable revision."""
    if not raw or len(raw) > 512:
        raise ValueError("Missing slot grant")
    value = json.loads(raw)
    if (not isinstance(value, dict) or set(value) != {"session", "revision"}
            or not isinstance(value["session"], str)
            or not TOKEN_PATTERN.fullmatch(value["session"])
            or isinstance(value["revision"], bool) or not isinstance(value["revision"], int)
            or not 1 <= value["revision"] <= 2147483647):
        raise ValueError("Invalid slot grant")
    return value


class SoloistQueueBridge:
    """Serialize Soloist controls independently of Kodi's live reader opens.

    A Kodi slot selection is an intent, not proof that its labelled song plays.
    Resolve promptly with actual metadata; only Soloist events confirm a command.
    Never reorder the playlist while a reader or a control is starting.
    """

    def __init__(self, websocket, player_state, logger, notify_failure, artist_mbids):
        self.websocket = websocket
        self.state = player_state
        self.log = logger
        self.notify_failure = notify_failure
        self.artist_mbids = artist_mbids
        self.window = xbmcgui.Window(10000)
        self.session = uuid.uuid4().hex
        self.entries = {}
        self.paths = []
        self.current_path = None
        self.queue = None
        self.queue_uri = None
        self.dirty = False
        self.pending = None
        self.actions = deque()
        self.disabled = False
        self.orphaned_reader = False
        self.last_poll = 0.0
        self.requested_at = None
        self.mutation = None
        self.generation = websocket.control_generation()
        self.callbacks = queue.Queue(maxsize=32)
        self.callback_overflow = threading.Event()
        self.queue_attempts = 0
        self.observed_uri = item_uri((player_state.get("playback") or {}).get("item"))
        self.revision = 0
        self.finished_operations = deque(maxlen=32)
        self.native_commands = deque(maxlen=32)
        self.resolved_starts = deque(maxlen=32)
        self.cached_candidate = None
        self.ambiguous_starts = False
        self.reader_deadline = None
        self.last_verified_context = None
        self.unexpected_end = False
        self.last_selection_at = 0.0

    def accept_result(self, command):
        now = time.monotonic()
        while self.native_commands and now - self.native_commands[0][1] > COMMAND_TIMEOUT + 2:
            self.native_commands.popleft()
        for index, (name, _) in enumerate(self.native_commands):
            if name == command:
                del self.native_commands[index]
                return True
        return False

    def callback(self, name, detail=None):
        # Callbacks have no immutable item/reader identity. Do not read GUI state
        # here: Kodi may be synchronously waiting for a plugin resolver.
        try:
            self.callbacks.put_nowait((name, detail))
        except queue.Full:
            self.callback_overflow.set()

    def _drain_callbacks(self):
        if self.callback_overflow.is_set():
            self.callback_overflow.clear()
            self.cancel("Kodi-Callbackverlust", notify=True)
            self.ambiguous_starts = True
        while True:
            try:
                name, detail = self.callbacks.get_nowait()
            except queue.Empty:
                return
            if name == "av_started":
                self.av_started(detail)
            elif name == "started":
                if self.cached_candidate is not None and self.cached_candidate != detail:
                    self.ambiguous_starts = True
                self.cached_candidate = detail
                if not self.orphaned_reader:
                    self.reader_deadline = time.monotonic() + RESOLVE_TIMEOUT
            elif name == "ended":
                if self.expected_end():
                    self.log("Native Queue: altes Streamende während Leserwechsel.")
                else:
                    self.unexpected_end = True
                    self.cancel("Kodi-Stream beendet")
                    detail()
            else:
                if detail == "Kodi-Stopp" and self.last_verified_context:
                    position, count, observed_at = self.last_verified_context
                    self.log("Native Queue: Kodi-Stopp; letzter Index={} von {} vor={:.0f}ms; "
                             "Auslöser nicht aus Callback ableitbar.".format(
                                 position, count, (time.monotonic() - observed_at) * 1000))
                self.cancel(detail)
                self.reader_deadline = None
                self.cached_candidate = None

    def busy(self):
        return bool(self.pending or self.actions or self.reader_deadline
                    or self.window.getProperty(REQUEST_PROPERTY))

    def metadata_busy(self):
        # Confirming a Spotify command must not freeze actual current metadata.
        return not self.state.get("av_ready") or bool(self.window.getProperty(REQUEST_PROPERTY))

    def _rpc(self, method, **params):
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": method, "params": params,
        })))
        if not isinstance(response, dict) or "error" in response or "result" not in response:
            raise RuntimeError("Kodi queue request rejected: " + method)
        return response["result"]

    def _owned_source(self, require_av=True):
        player = self.state["player"]
        try:
            return bool(self.state.get("owned") and (self.state.get("av_ready") or not require_av)
                        and player.isPlaying()
                        and player.getPlayingFile() == self.state.get("playback_url"))
        except RuntimeError:
            return False  # A reader can disappear between these two public calls.

    def _context(self, require_current=True, require_av=True):
        if self.window.getProperty(REQUEST_PROPERTY) or not self._owned_source(require_av):
            return None
        players = self._rpc("Player.GetActivePlayers")
        active = [entry for entry in players if entry.get("type") == "audio"]
        if len(active) != 1:
            return None
        properties = self._rpc("Player.GetProperties", playerid=active[0]["playerid"],
                               properties=["playlistid", "position", "shuffled", "repeat"])
        if (properties.get("playlistid") != 0 or properties.get("shuffled") is not False
                or properties.get("repeat") != "off"):
            return None
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        count = playlist.size()
        if not 1 <= count <= 21:
            return None
        paths = [playlist[index].getPath() for index in range(count)]
        position = properties.get("position")
        if (isinstance(position, bool) or not isinstance(position, int)
                or not 0 <= position < len(paths) or len(set(paths)) != len(paths)):
            return None
        if paths != (self.paths or [self.state.get("metadata_item_path")]):
            return None
        if require_current and paths[position] != self.state.get("metadata_item_path"):
            return None
        self.last_verified_context = (position, len(paths), time.monotonic())
        return playlist, paths, position

    def _read_request(self):
        raw = self.window.getProperty(REQUEST_PROPERTY)
        if not raw:
            return None
        try:
            if len(raw) > 512:
                raise ValueError("oversized navigation request")
            request = json.loads(raw)
            if (not isinstance(request, dict)
                    or set(request) != {"operation", "entry", "session", "revision"}
                    or any(not isinstance(request[field], str)
                           or not TOKEN_PATTERN.fullmatch(request[field])
                           for field in ("operation", "entry", "session"))
                    or isinstance(request["revision"], bool)
                    or not isinstance(request["revision"], int)
                    or not 1 <= request["revision"] <= 2147483647):
                raise ValueError("invalid navigation request")
            return request
        except (ValueError, TypeError):
            self.window.clearProperty(REQUEST_PROPERTY)
            return None

    def _reply(self, request, payload):
        if request is not None and self._read_request() == request:
            self.window.setProperty(result_key(request["operation"]), json.dumps(payload))
            if request["operation"] not in self.finished_operations:
                self.finished_operations.append(request["operation"])

    def _active(self):
        playback = self.state.get("playback") or {}
        return bool(self.state.get("owned") and self.websocket.is_connected()
                    and playback.get("status") in ("playing", "buffering")
                    and playback.get("is_active") is True and item_uri(playback.get("item")))

    def _adopt(self, path):
        self.current_path = path
        self.state["metadata_item_path"] = path
        self.state["applied_info_tag_revision"] = None
        self.state["pending_info_tag"] = None
        self.state["pending_audio_recovery"] = None
        self.last_selection_at = time.monotonic()

    def _actual_payload(self):
        item = (self.state.get("playback") or {}).get("item")
        payload = {"ok": True, "url": self.state["playback_url"], "item": item,
                   "artist_mbids": self.artist_mbids(item)}
        if len(json.dumps(payload).encode("utf-8")) > MAX_PAYLOAD_BYTES:
            raise ValueError("Queue metadata too large")
        return payload

    def _select(self, path, request=None):
        # During a posted Insert/Remove, native positions may already differ.
        # Its stored grant remains playable, but no ambiguous action is inferred.
        if self.mutation:
            allowed = self.mutation["before"] + self.mutation["after"]
            if path in allowed and self.current_path in allowed:
                self._adopt(path)
            self.notify_failure()
            return False
        if path not in self.paths or self.current_path not in self.paths:
            self.notify_failure()
            return False
        selected, old = self.paths.index(path), self.paths.index(self.current_path)
        direction = "previous" if selected < old else "next" if selected > old else "current"
        steps = abs(selected - old)
        if self.unexpected_end:
            self.unexpected_end = False
            steps = 0
            self.notify_failure()
        if len(self.actions) + steps + bool(self.pending) > 20:
            steps = 0
            self.notify_failure()
            self.log("Native Queue: Folgeauswahlgrenze erreicht; keine unbegrenzten Steuerbefehle.")
        self._adopt(path)
        self.actions.extend([direction] * steps)
        self.log("Native Queue: Auswahl Richtung={} Schritte={} wartend={}; "
                 "Kodi-Leser und Soloist-Bestätigung getrennt.".format(
                     direction, steps, len(self.actions)))
        return True

    def _observe_cached_start(self):
        generation = self.cached_candidate
        if self.orphaned_reader:
            self.cached_candidate = None
            return
        if generation is None or self.window.getProperty(REQUEST_PROPERTY):
            return
        if generation != self.state.get("source_generation", 0):
            self.cached_candidate = None
            return
        if not self.paths or not self.current_path:
            self.cached_candidate = None
            return
        # Started does not imply Player.GetActivePlayers/GetProperties are ready.
        # Retry a transient read until the bounded reader deadline. Never Swap.
        if self.mutation and not self._settle_mutation(require_av=False):
            return
        try:
            context = self._context(require_current=False, require_av=False)
        except RuntimeError:
            return
        if context is None:
            return
        _, paths, position = context
        path = paths[position]
        self.cached_candidate = None
        expected = next((index for index, (value, _) in enumerate(self.resolved_starts)
                         if value == path), None)
        if expected is not None:
            for _ in range(expected + 1):
                self.resolved_starts.popleft()
            # The resolver already recorded the intent. Bind metadata to the
            # reader actually observed, even if another open was queued later.
            self._adopt(path)
            if self.ambiguous_starts:
                self.notify_failure()
                self.log("Native Queue: Resolver-Echo nach mehreren Started-Ereignissen; "
                         "Zwischenaktionen nicht eindeutig, kein zusätzlicher Skip.")
            self.ambiguous_starts = False
            return
        if self.ambiguous_starts:
            self.ambiguous_starts = False
            self._adopt(path)
            self.notify_failure()
            self.log("Native Queue: mehrere Started-Ereignisse ohne eindeutige Zwischenposition; "
                     "keine Richtungsfolge erfunden.")
            return
        if self._active() and not self.disabled:
            self._select(path)
            self._begin_action()

    def poll_request(self, accept=True):
        self._drain_callbacks()
        generation = self.websocket.control_generation()
        if generation != self.generation:
            self.generation = generation
            self.native_commands.clear()
            self.cancel("Verbindungswechsel oder Ereignisverlust")
            self.cached_candidate = None
            self.resolved_starts.clear()
        if (self.pending or self.actions) and not self._active():
            self.cancel("Steuerverbindung oder Soloist nicht aktiv")
        request = self._read_request()
        if request and accept and request["operation"] not in self.finished_operations:
            entry = self.entries.get(request["entry"])
            if (self.disabled or not entry or request["session"] != self.session
                    or not self._active()):
                self._reply(request, {"ok": False})
            else:
                # Returning actual current media now removes status/AV roundtrips
                # from the native resolver. The selected label is never fabricated.
                payload = self._actual_payload()
                if request["revision"] == entry["revision"]:
                    self._select(entry["path"], request)
                else:
                    self._adopt(entry["path"])
                    self.notify_failure()
                self.resolved_starts.append((entry["path"], time.monotonic()))
                self.state["av_ready"] = False
                self.reader_deadline = time.monotonic() + RESOLVE_TIMEOUT
                self._reply(request, payload)
                self.log("Native Queue: Resolver sofort mit tatsächlichen Metadaten beantwortet.")
        elif request and request["operation"] in self.finished_operations:
            if not self.window.getProperty(result_key(request["operation"])):
                self._reply(request, {"ok": False})
        if not self.window.getProperty(REQUEST_PROPERTY):
            self._observe_cached_start()
            self._begin_action()
        if self.pending and time.monotonic() >= self.pending["deadline"]:
            self.cancel("Zeitlimit der Soloist-Zielbestätigung", notify=True)
        if self.reader_deadline and time.monotonic() >= self.reader_deadline:
            self.reader_deadline = None
            self.cached_candidate = None
            self.resolved_starts.clear()
            self.cancel("Kodi-AV-Start nicht bestätigt", notify=True)
            self.state["kodi_error_reconnect_requested_at"] = time.monotonic()
            self.state["kodi_error_state_confirmed"] = False
            self.state["kodi_error_state_request_at"] = None
            self.state["kodi_error_state_request_attempts"] = 0
        while self.resolved_starts and time.monotonic() - self.resolved_starts[0][1] > RESOLVE_TIMEOUT:
            self.resolved_starts.popleft()

    def _event_cursor(self):
        cursor = getattr(self.websocket, "event_cursor", None)
        return cursor() if callable(cursor) else None

    def _fresh(self, event):
        cursor = self.pending.get("after_sequence")
        sequence = event.get("_soloist_event_sequence")
        return cursor is None or (isinstance(sequence, int) and not isinstance(sequence, bool)
                                  and sequence > cursor)

    def _begin_action(self):
        if self.pending or not self.actions or not self._active():
            return
        direction = self.actions.popleft()
        self.pending = {"direction": direction, "phase": "checking", "state_seen": False,
                        "queue_seen": None, "deadline": time.monotonic() + COMMAND_TIMEOUT,
                        "after_sequence": self._event_cursor()}
        if not (self.websocket.send_command("get_state")
                and self.websocket.send_command("get_queue", limit=10)):
            self.cancel("Steuerverbindung fehlt", notify=True)

    def _send_if_checked(self):
        pending = self.pending
        if (not pending or pending["phase"] != "checking" or not pending["state_seen"]
                or pending["queue_seen"] is None):
            return
        if not self._active() or self.websocket.control_generation() != self.generation:
            self.cancel("Quelle oder Verbindung inzwischen beendet")
            return
        playback = self.state["playback"]
        current = item_uri(playback.get("item"))
        if pending.get("checked_current") != current or pending.get("queue_current") != current:
            if pending.get("rechecks", 0) >= 1:
                self.cancel("Status und Queue gehören nicht zum selben Titel", notify=True)
                return
            pending.update(state_seen=False, queue_seen=None, rechecks=1,
                           after_sequence=self._event_cursor())
            if not (self.websocket.send_command("get_state")
                    and self.websocket.send_command("get_queue", limit=10)):
                self.cancel("Erneute Statusprüfung nicht möglich", notify=True)
            return
        target = neighbor(pending["queue_seen"], pending["direction"], current)
        command = "skip_prev" if pending["direction"] == "previous" else "skip_next"
        actions = playback.get("available_actions")
        if not target or (isinstance(actions, dict) and actions.get(command) is False):
            self.cancel("Kein bestätigter Nachbar oder Aktion nicht erlaubt", notify=True)
            return
        pending.update(current=current, target=target["uri"], after_sequence=self._event_cursor(),
                       before_position=estimated_position_ms(playback.get("position")),
                       sent_at_ms=time.time() * 1000)
        if not self.websocket.send_command(command):
            self.cancel("Skip nicht vorgemerkt", notify=True)
            return
        self.native_commands.append((command, time.monotonic()))
        pending.update(command=command, phase="waiting", deadline=time.monotonic() + COMMAND_TIMEOUT)
        self.log("Native Queue: {} einmalig vorgemerkt; Position_vorher_geschätzt={}ms "
                 "Folgeaktionen={}; AV-Start wird nicht abgewartet.".format(
                     command, pending["before_position"], len(self.actions)))

    def _confirmed(self, restart=False):
        self.log("Native Queue: Soloist {} bestätigt; Folgeaktionen={}.".format(
            "Titelneustart" if restart else "Zieltitel", len(self.actions)))
        self.pending = None
        self.dirty = True
        self._begin_action()

    def handle_event(self, event):
        playback = self.state.get("playback") or {}
        current = item_uri(playback.get("item"))
        kind = event.get("type")
        if kind == "queue_changed":
            self.queue = event
            self.queue_uri = current
            self.requested_at = None
            self.queue_attempts = 0
            self.dirty = True
            if self.pending and self.pending["phase"] == "checking" and self._fresh(event):
                self.pending["queue_seen"] = event
                self.pending["queue_current"] = current
                self._send_if_checked()
            return True
        if kind in ("track_changed", "playback_state") and current != self.observed_uri:
            self.observed_uri = current
            self.queue = None
            self.queue_uri = None
            self.requested_at = None
            self.queue_attempts = 0
            self.dirty = True
        if (playback.get("status") not in ("playing", "buffering")
                or playback.get("is_active") is not True
                or (kind == "auth_state" and not event.get("logged_in"))):
            if self.pending or self.actions:
                self.cancel("Soloist nicht mehr aktiv")
            return False
        pending = self.pending if self.pending and self._fresh(event) else None
        if pending and pending["phase"] == "checking" and kind == "playback_state":
            pending["state_seen"] = True
            pending["checked_current"] = current
            self._send_if_checked()
        elif pending and pending["phase"] == "waiting":
            if kind in ("track_changed", "playback_state"):
                if current == pending["target"]:
                    self._confirmed()
                elif current != pending["current"]:
                    self.cancel("Anderer Titel gestartet; Folgeaktionen verworfen", notify=True)
            elif (kind == "position_sync" and pending["direction"] == "previous"
                  and current == pending["current"]):
                position = playback.get("position") or {}
                before, after = pending["before_position"], estimated_position_ms(position)
                timestamp = position.get("timestamp_ms") if isinstance(position, dict) else None
                if (isinstance(before, (int, float)) and not isinstance(before, bool)
                        and isinstance(after, (int, float)) and not isinstance(after, bool)
                        and isinstance(timestamp, (int, float)) and not isinstance(timestamp, bool)
                        and timestamp >= pending["sent_at_ms"]
                        and before + timestamp - pending["sent_at_ms"] >= 3000
                        and 0 <= after <= 1500):
                    self._confirmed(restart=True)
        # While a resolver blocks Kodi, no downstream GUI calls are safe. Once
        # it returns, real playback/metadata processing continues during controls.
        if kind in ("track_changed", "playback_state") and not self.metadata_busy():
            self._prepare_actual_tag()
        return bool(self.window.getProperty(REQUEST_PROPERTY))

    def _prepare_actual_tag(self):
        playback = self.state.get("playback") or {}
        mbids = self.artist_mbids(playback.get("item"))
        revision = hashlib.sha256(json.dumps(
            [playback.get("item"), mbids], sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")).hexdigest()
        if self.state.get("applied_info_tag_revision") == revision:
            return
        tag = kodi_music_item(playback, self.state["playback_url"], xbmcgui.ListItem,
                              artist_mbids_by_uri=mbids)
        if tag is not None:
            self.state.update(pending_info_tag=tag, info_tag_revision=revision,
                              info_tag_attempts=0, info_tag_retry_at=0)

    def av_started(self, source):
        if self.window.getProperty(REQUEST_PROPERTY):
            return
        self._observe_cached_start()
        if source != self.state.get("playback_url") or not self._owned_source():
            return
        if self.orphaned_reader:
            self.reader_deadline = None
            self._prepare_actual_tag()
            return
        # AV has no reader ID. Require a matching own playlist path; a delayed
        # AV for an intermediate reader must not mark an unknown item ready.
        try:
            context = self._context()
        except RuntimeError:
            return
        if context is None:
            return
        self.reader_deadline = None
        self._prepare_actual_tag()

    def expected_end(self):
        return bool(self.reader_deadline and not self.state.get("av_ready")
                    and self.state.get("owned") and time.monotonic() < self.reader_deadline)

    def cancel(self, reason, notify=False):
        pending, queued = self.pending, len(self.actions)
        self.pending = None
        self.actions.clear()
        request = self._read_request()
        if request and request["operation"] not in self.finished_operations:
            self._reply(request, {"ok": False})
        if pending or queued:
            self.log("Native Queue: Steuerung abgebrochen ({}); Folgeaktionen={} verworfen, "
                     "kein Skip wiederholt.".format(reason, queued))
        if notify:
            self.notify_failure()
        self.queue = None
        self.queue_uri = None
        self.dirty = True

    def close(self):
        self.cancel("Dienst beendet")
        self.native_commands.clear()
        for token in self.entries:
            self.window.clearProperty(PREFIX + token)
        self.entries.clear()
        self.resolved_starts.clear()
        self.cached_candidate = None
        self.reader_deadline = None
        self.unexpected_end = False
        self.orphaned_reader = False

    def disable(self, reason):
        self.disabled = True
        self.cancel(reason, notify=True)
        self.mutation = None
        self.log("Native Queue deaktiviert: {}. Audioweg bleibt unverändert.".format(reason))

    def _remove(self, index, expected_path):
        context = self._context()
        if context is None:
            raise RuntimeError("Playlist ownership changed before removal")
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        if (not self._owned_source() or index >= playlist.size()
                or playlist[index].getPath() != expected_path):
            raise RuntimeError("Playlist ownership changed")
        self._rpc("Playlist.Remove", playlistid=0, position=index)
        after = list(self.paths)
        after.pop(index)
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0}

    def _tag_slot(self, index, path, item):
        slot = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)[index]
        slot.setLabel(item_title(item))
        slot.getMusicInfoTag().setMusicBrainzArtistID([])
        slot.setArt({"thumb": "", "icon": ""})
        kodi_music_item({"item": item}, path, lambda **kwargs: slot,
                        artist_mbids_by_uri=self.artist_mbids(item))
        slot.setProperty("ForceResolvePlugin", "true")
        slot.setProperty("IsPlayable", "true")
        slot.setProperty("inputstream", "inputstream.ffmpegdirect")
        slot.setProperty("inputstream-player", "videodefaultplayer")

    def _slot_token(self, path):
        parameters = parse_qs(urlsplit(path).query)
        token = (parameters.get("queue") or parameters.get("request") or [""])[0]
        if not TOKEN_PATTERN.fullmatch(token):
            raise ValueError("Not an owned resolver slot")
        return token

    def _publish_slot(self, index, path, direction, target, current):
        token = self._slot_token(path)
        candidate = dict(target, direction=direction, current=current, path=path)
        old = self.entries.get(token) or {}
        if {key: value for key, value in old.items() if key != "revision"} != candidate:
            self.revision += 1
            candidate["revision"] = self.revision
        else:
            candidate["revision"] = old["revision"]
        self._tag_slot(index, path, target["item"])
        self.entries[token] = candidate
        self.window.setProperty(PREFIX + token, json.dumps({
            "session": self.session, "revision": candidate["revision"],
        }))

    def _new_entry(self, direction, target, current_uri):
        token = uuid.uuid4().hex
        path = "plugin://service.soloist.native/?queue={}&session={}".format(token, self.session)
        self.revision += 1
        self.entries[token] = dict(target, direction=direction, current=current_uri,
                                   path=path, revision=self.revision)
        # Kodi can expose the posted Insert before the service observes its ACK.
        # A selectable row must already have a valid session grant at that point.
        self.window.setProperty(PREFIX + token, json.dumps({
            "session": self.session, "revision": self.revision,
        }))
        return path

    def _insert(self, index, path, target):
        if self._context() is None:
            raise RuntimeError("Playlist ownership changed before insertion")
        after = list(self.paths)
        after.insert(index, path)
        self.mutation = {"before": list(self.paths), "after": after,
                         "deadline": time.monotonic() + 3.0,
                         "inserted": (index, path, target)}
        try:
            self._rpc("Playlist.Insert", playlistid=0, position=index, item={"file": path})
        except Exception:
            self.mutation = None
            raise

    def _settle_mutation(self, require_av=True):
        mutation = self.mutation
        if not mutation:
            return True
        if not self._owned_source(require_av=require_av):
            return False
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        paths = [playlist[index].getPath() for index in range(playlist.size())]
        if paths == mutation["after"] and len(set(paths)) == len(paths):
            self.paths = paths
            self.mutation = None
            inserted = mutation.get("inserted")
            if inserted:
                index, path, target = inserted
                token = self._slot_token(path)
                entry = self.entries[token]
                self._publish_slot(index, path, entry["direction"], target,
                                   item_uri((self.state.get("playback") or {}).get("item")))
            for token, entry in list(self.entries.items()):
                if entry["path"] not in paths:
                    self.window.clearProperty(PREFIX + token)
                    del self.entries[token]
            if self.current_path not in paths:
                # A posted Remove raced an already copied selection. The live
                # stream is still valid; never reopen it to repair a playlist.
                self.orphaned_reader = True
                self.reader_deadline = None
                self.cached_candidate = None
                self.resolved_starts.clear()
                self.disable("Ausgewählter Slot während Kantenabgleich entfernt; "
                             "eigener Audioleser bleibt erhalten")
            return True
        if paths != mutation["before"] or time.monotonic() >= mutation["deadline"]:
            self.disable("Playlist-Änderung nicht bestätigt")
        return False

    def _targets(self, current):
        playback = self.state.get("playback") or {}
        previous = neighbors(self.queue, "previous", current)
        upcoming = neighbors(self.queue, "upcoming", current)
        actions = playback.get("available_actions")
        if isinstance(actions, dict):
            if actions.get("skip_prev") is False:
                previous = []
            if actions.get("skip_next") is False:
                upcoming = []
        return previous, upcoming

    def sync(self):
        """Fill real neighbours only on a stable, idle own reader; never Swap."""
        if self.busy() or self.cached_candidate is not None:
            return
        now = time.monotonic()
        if now - self.last_selection_at < 0.75:
            return
        if not self.dirty and now - self.last_poll < 0.5:
            return
        self.last_poll = now
        if not self.websocket.is_connected() or not self.state.get("owned"):
            self.cancel("Verbindung oder Playerbesitz beendet")
            return
        if not self.state.get("av_ready"):
            return
        path = self.state.get("metadata_item_path")
        if path != self.current_path:
            if path in self.paths:
                return
            self.close()
            self.session = uuid.uuid4().hex
            self.paths = []
            self.current_path = path
            self.disabled = False
            self.queue = None
            self.queue_uri = None
            self.requested_at = None
            self.mutation = None
            self.dirty = True
        if not self._settle_mutation():
            return
        context = self._context()
        if context is None:
            return
        _, paths, position = context
        if not self.paths:
            self.paths = paths
        current = item_uri((self.state.get("playback") or {}).get("item"))
        if not current or self.disabled:
            return
        target = {"uid": current, "uri": current, "item": self.state["playback"]["item"]}
        self._publish_slot(position, self.current_path, "current", target, current)
        if self.queue is None or self.queue_uri != current:
            if (self.queue_attempts < 3
                    and (self.requested_at is None or now - self.requested_at >= 5.0)):
                if self.websocket.send_command("get_queue", limit=10):
                    self.requested_at = now
                    self.queue_attempts += 1
            return
        if not self.dirty:
            return
        previous, upcoming = self._targets(current)
        # Trim an excess at an inactive edge before growing: at most 21 rows,
        # no placeholders, and never remove the playing row or clear the list.
        if position > len(previous):
            self._remove(0, self.paths[0])
            return
        after_count = len(self.paths) - position - 1
        if after_count > len(upcoming):
            self._remove(len(self.paths) - 1, self.paths[-1])
            return
        if (position < len(previous)
                and (after_count >= len(upcoming) or position <= after_count)):
            target = previous[position]
            self._insert(0, self._new_entry("previous", target, current), target)
            return
        if after_count < len(upcoming):
            target = upcoming[after_count]
            self._insert(len(self.paths), self._new_entry("next", target, current), target)
            return
        ordered = ([("previous", target) for target in reversed(previous)]
                   + [("current", {"uid": current, "uri": current,
                                     "item": self.state["playback"]["item"]})]
                   + [("next", target) for target in upcoming])
        for index, (direction, target) in enumerate(ordered):
            self._publish_slot(index, self.paths[index], direction, target, current)
        self.dirty = False
        self.log("Native Queue: {} vorherige / {} nächste echte Titel, aktueller Index={}; "
                 "kein Swap, kein zusätzliches Player.Open.".format(
                     len(previous), len(upcoming), position))
