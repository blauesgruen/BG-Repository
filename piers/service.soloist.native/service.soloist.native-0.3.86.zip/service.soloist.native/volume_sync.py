"""Spotify volume slider drives Kodi's volume instead of attenuating Soloist.

Soloist applies the Spotify app volume as the PulseAudio volume of its own
stream (measured: app ~40 % -> stream 41 % / -23.5 dB). That attenuation
happens before the 16-bit capture, so it costs resolution. Instead the
stream is kept at 100 %, the app value is applied to Kodi's volume (float
pipeline, 24-bit output) and Kodi volume changes are reported back to
Soloist so the app slider follows. Kodi's previous volume is restored when
Soloist stops being the active source.
"""

import time

STREAM_CHECK_SECONDS = 2.0
KODI_CHECK_SECONDS = 0.5


def _volume(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if value != value or value < 0 or value > 100:
        return None
    return int(round(value))


class VolumeSync:
    def __init__(self, get_kodi_volume, set_kodi_volume, send_soloist_volume,
                 reset_stream_volume, enabled=None, logger=None, clock=None):
        self.get_kodi_volume = get_kodi_volume
        self.set_kodi_volume = set_kodi_volume
        self.send_soloist_volume = send_soloist_volume
        self.reset_stream_volume = reset_stream_volume
        self.enabled = enabled or (lambda: True)
        self.logger = logger or (lambda message: None)
        self.clock = clock or time.monotonic
        self.soloist_volume = None
        self.saved_kodi_volume = None
        self.expected_kodi_volume = None
        self.last_stream_check = None
        self.last_kodi_check = None

    @property
    def engaged(self):
        return self.saved_kodi_volume is not None

    def on_soloist_volume(self, value, active):
        """Soloist reported its volume (app slider or our own set_volume)."""
        volume = _volume(value)
        if volume is None:
            return
        self.soloist_volume = volume
        if active and self.enabled():
            self._engage()
            self._apply_to_kodi(volume)
            self._reset_stream(force=True)

    def tick(self, active):
        """Called from the service loop; keeps stream, Kodi and Soloist in step."""
        if not self.enabled() or not active:
            self._release()
            return
        if not self.engaged and self.soloist_volume is not None:
            self._engage()
            self._apply_to_kodi(self.soloist_volume)
        if not self.engaged:
            return
        self._reset_stream()
        now = self.clock()
        if self.last_kodi_check is not None and now - self.last_kodi_check < KODI_CHECK_SECONDS:
            return
        self.last_kodi_check = now
        current = _volume(self.get_kodi_volume())
        if current is None or current == self.expected_kodi_volume:
            return
        # Changed in Kodi (remote, skin): let the Spotify slider follow.
        self.expected_kodi_volume = current
        self.soloist_volume = current
        self.send_soloist_volume(current)
        self.logger("Kodi-Lautstärke {} an Spotify gemeldet.".format(current))

    def _engage(self):
        if self.saved_kodi_volume is None:
            saved = _volume(self.get_kodi_volume())
            self.saved_kodi_volume = 100 if saved is None else saved
            self.logger("Spotify-Lautstärke steuert jetzt Kodi (vorher {}).".format(
                self.saved_kodi_volume))

    def _apply_to_kodi(self, volume):
        if volume != self.expected_kodi_volume:
            self.expected_kodi_volume = volume
            self.set_kodi_volume(volume)

    def _reset_stream(self, force=False):
        now = self.clock()
        if (not force and self.last_stream_check is not None
                and now - self.last_stream_check < STREAM_CHECK_SECONDS):
            return
        self.last_stream_check = now
        try:
            self.reset_stream_volume()
        except Exception as error:  # diagnostics only; playback continues
            self.logger("Soloist-Stream-Lautstärke nicht zurückgesetzt ({}).".format(
                type(error).__name__))

    def _release(self):
        if self.saved_kodi_volume is None:
            return
        restore, self.saved_kodi_volume = self.saved_kodi_volume, None
        self.expected_kodi_volume = None
        self.set_kodi_volume(restore)
        self.logger("Kodi-Lautstärke auf {} zurückgesetzt.".format(restore))
