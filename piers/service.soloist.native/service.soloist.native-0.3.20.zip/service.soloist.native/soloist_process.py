"""Own and supervise the Soloist process started by this Kodi service."""

import os
import subprocess
import threading


class SoloistProcess:
    def __init__(self, binary_path, data_dir, cache_dir, logger, popen_factory=None):
        self.binary_path = binary_path
        self.data_dir = data_dir
        self.cache_dir = cache_dir
        self.logger = logger
        self.popen_factory = popen_factory or subprocess.Popen
        self.process = None
        self.api_key = None
        self.output_thread = None

    def is_running(self):
        return self.process is not None and self.process.poll() is None

    def start(self, device_name, api_key, audio_sink=None):
        if self.is_running():
            return "already_running"
        if not os.path.isfile(self.binary_path) or not os.access(self.binary_path, os.X_OK):
            return "binary_missing"
        if not device_name or not api_key:
            return "configuration_missing"

        os.makedirs(self.data_dir, mode=0o700, exist_ok=True)
        os.makedirs(self.cache_dir, mode=0o700, exist_ok=True)
        os.chmod(self.data_dir, 0o700)
        os.chmod(self.cache_dir, 0o700)
        for filename in ("ws.addr", "ws.port"):
            try:
                os.unlink(os.path.join(self.data_dir, filename))
            except FileNotFoundError:
                pass
        self.api_key = api_key
        arguments = [
            self.binary_path,
            "--device-name",
            device_name,
            "--api-key",
            api_key,
            "--data-dir",
            self.data_dir,
            "--cache-dir",
            self.cache_dir,
            "--ws",
            "127.0.0.1:0",
        ]
        if audio_sink and (not audio_sink.replace("_", "").isalnum()):
            return "invalid_audio_sink"
        environment = os.environ.copy()
        if audio_sink:
            environment["PULSE_SINK"] = audio_sink
        try:
            self.process = self.popen_factory(
                arguments,
                cwd=os.path.dirname(self.binary_path),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=1,
                universal_newlines=True,
                close_fds=True,
                env=environment,
            )
        except OSError as error:
            self.process = None
            self.api_key = None
            self.logger(
                "Soloist konnte nicht gestartet werden ({})".format(
                    type(error).__name__
                )
            )
            return "start_failed"

        self.output_thread = threading.Thread(
            target=self._read_output,
            name="soloist-log-reader",
            daemon=True,
        )
        try:
            self.output_thread.start()
        except RuntimeError:
            try:
                self.process.terminate()
                self.process.wait(timeout=1)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    self.process.kill()
                    self.process.wait()
                except OSError:
                    pass
            self.process = None
            self.api_key = None
            self.output_thread = None
            return "start_failed"
        return "started"

    def _read_output(self):
        process = self.process
        if process is None or process.stdout is None:
            return
        try:
            for line in process.stdout:
                message = line.rstrip()
                if self.api_key:
                    message = message.replace(self.api_key, "[redacted]")
                if len(message) > 2000:
                    message = message[:2000] + "…"
                lowered = message.lower()
                if any(word in lowered for word in ("error", "failed", "failure", "expired")):
                    self.logger("Soloist: {}".format(message))
        except (OSError, ValueError):
            return

    def poll_exit(self):
        if not self.is_running():
            if self.process is None:
                return None
            return_code = self.process.poll()
            if self.output_thread is not None and self.output_thread.ident is not None:
                self.output_thread.join()
            self.process = None
            self.api_key = None
            self.output_thread = None
            self.logger("Soloist-Prozess beendet (Exit-Code {}).".format(return_code))
            return return_code
        return None

    def stop(self, timeout=5):
        if self.process is None:
            return "not_running"
        process = self.process
        if process.poll() is None:
            try:
                process.terminate()
            except OSError:
                pass
            try:
                process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        return_code = process.poll()
        if self.output_thread is not None and self.output_thread.ident is not None:
            self.output_thread.join()
        self.process = None
        self.api_key = None
        self.output_thread = None
        return "stopped:{}".format(return_code)
