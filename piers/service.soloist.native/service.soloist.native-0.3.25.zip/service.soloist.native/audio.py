"""Bridge Soloist's PulseAudio RTP output to Kodi over local HTTP/TCP PCM."""

import json
import collections
import http.server
import os
import random
import socket
import struct
import subprocess
import socketserver
import threading
import time


RATE = 48000
CHANNELS = 2
SINK_NAME = "soloist_native"
HTTP_QUEUE_LIMIT = RATE * CHANNELS * 2 // 2


class _AudioHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _AudioHTTPHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def do_GET(self):
        if self.path != "/soloist.pcm":
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header(
            "Content-Type",
            "audio/L16;rate={};channels={}".format(RATE, CHANNELS),
        )
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.server.owner._stream_http_audio(self.connection)

    def log_message(self, format_string, *args):
        return


class AudioSetupError(Exception):
    """PulseAudio or Kodi audio setup failed safely."""


class PulseRtpAudio:
    def __init__(self, data_dir, logger, runner=None):
        self.data_dir = data_dir
        self.logger = logger
        self.runner = runner or subprocess.run
        self.module_ids = []
        self.sink_name = "{}_{}_{}".format(
            SINK_NAME,
            os.getpid(),
            random.randrange(100000, 1000000),
        )
        self.port = None
        self.relay_port = None
        self.http_server = None
        self.http_thread = None
        self.playback_url = None
        self.default_sink = None
        self.original_inputs = {}
        self._rtp_receiver = None
        self._rtp_forwarder = None
        self._rtp_thread = None
        self._rtp_stop = threading.Event()
        self._rtp_lock = threading.Lock()
        self._http_condition = threading.Condition()
        self._http_queue = collections.deque()
        self._http_queued_bytes = 0
        self._http_clients = set()
        self._http_stop = threading.Event()
        self._diagnostic_cache_lock = threading.Lock()
        self._diagnostic_cache = "PulseAudio-Probe=noch nicht ausgeführt"
        self._diagnostic_cache_at = None
        self._diagnostic_worker = None
        self._rtp_stats = {
            "received": 0,
            "forwarded": 0,
            "bytes_received": 0,
            "sequence_gaps": 0,
            "duplicates": 0,
            "out_of_order": 0,
            "timestamp_jumps": 0,
            "silence_filled_frames": 0,
            "malformed": 0,
            "forward_errors": 0,
            "last_packet_at": None,
            "last_sequence": None,
            "last_timestamp": None,
            "last_payload_bytes": None,
            "stream_resets": 0,
            "http_connections": 0,
            "http_bytes_sent": 0,
            "http_dropped_bytes": 0,
        }
        self._rtp_reported = dict(self._rtp_stats)

    def _pactl(self, *arguments, check=True):
        try:
            result = self.runner(
                ["pactl"] + list(arguments),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=5,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise AudioSetupError("PulseAudio-Steuerung ist nicht erreichbar") from error
        if check and result.returncode != 0:
            raise AudioSetupError(self._pactl_failure(arguments, result))
        if not check and result.returncode != 0:
            raise AudioSetupError(self._pactl_failure(arguments, result))
        return (result.stdout or "").strip()

    @staticmethod
    def _pactl_failure(arguments, result):
        """Return a bounded diagnostic without logging an entire command result."""
        operation = " ".join(str(argument) for argument in arguments[:3])
        lines = (result.stdout or "").splitlines()
        detail = " ".join("".join(char for char in line if char.isprintable()) for line in lines[:1])
        detail = detail[:240].strip()
        message = "pactl {} fehlgeschlagen (Exit-Code {})".format(
            operation or "Befehl", result.returncode
        )
        if detail:
            message += ": {}".format(detail)
        return message

    @staticmethod
    def _free_rtp_port(exclude=()):
        for port in random.sample(range(30000, 50000, 2), 128):
            if port in exclude:
                continue
            probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                probe.bind(("127.0.0.1", port))
            except OSError:
                continue
            else:
                return port
            finally:
                probe.close()
        raise AudioSetupError("Kein freier lokaler RTP-Port gefunden")

    @staticmethod
    def _rtp_header(packet):
        """Parse the RTP sequence, timestamp and payload length if valid."""
        if len(packet) < 12 or packet[0] >> 6 != 2:
            return None
        header_length = 12 + (packet[0] & 0x0F) * 4
        if header_length > len(packet):
            return None
        if packet[0] & 0x10:
            if header_length + 4 > len(packet):
                return None
            extension_words = struct.unpack_from("!H", packet, header_length + 2)[0]
            header_length += 4 + extension_words * 4
            if header_length > len(packet):
                return None
        payload_end = len(packet)
        if packet[0] & 0x20:
            padding = packet[-1]
            if padding < 1 or padding > payload_end - header_length:
                return None
            payload_end -= padding
        sequence, timestamp = struct.unpack_from("!HI", packet, 2)
        return sequence, timestamp, payload_end - header_length

    @staticmethod
    def _rtp_payload(packet):
        parsed = PulseRtpAudio._rtp_header(packet)
        if parsed is None:
            return b""
        header_length = 12 + (packet[0] & 0x0F) * 4
        if packet[0] & 0x10:
            extension_words = struct.unpack_from("!H", packet, header_length + 2)[0]
            header_length += 4 + extension_words * 4
        payload_end = len(packet)
        if packet[0] & 0x20:
            payload_end -= packet[-1]
        return packet[header_length:payload_end]

    def _start_rtp_relay(self):
        receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            receiver.bind(("127.0.0.1", self.relay_port))
            receiver.settimeout(0.5)
        except OSError as error:
            receiver.close()
            raise AudioSetupError("Lokaler RTP-Empfang konnte nicht starten") from error
        self._rtp_receiver = receiver
        self._rtp_stop.clear()
        self._rtp_thread = threading.Thread(
            target=self._rtp_relay_loop,
            name="soloist-rtp-to-http-bridge",
            daemon=True,
        )
        self._rtp_thread.start()

    def _start_http_server(self):
        try:
            server = _AudioHTTPServer(("127.0.0.1", 0), _AudioHTTPHandler)
        except OSError as error:
            raise AudioSetupError("Lokaler TCP-Audiostream konnte nicht starten") from error
        server.owner = self
        self.http_server = server
        self.playback_url = "http://127.0.0.1:{}/soloist.pcm".format(
            server.server_address[1]
        )
        self._http_stop.clear()
        self.http_thread = threading.Thread(
            target=server.serve_forever,
            name="soloist-audio-http",
            daemon=True,
        )
        self.http_thread.start()

    def _stream_http_audio(self, connection):
        try:
            connection.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65536)
        except OSError:
            pass
        with self._http_condition:
            self._rtp_stats["http_connections"] += 1
            self._http_clients.add(connection)
            self._http_queue.clear()
            self._http_queued_bytes = 0
        pending = bytearray()
        try:
            while not self._http_stop.is_set():
                with self._http_condition:
                    if not self._http_queue:
                        self._http_condition.wait(0.5)
                    while self._http_queue and len(pending) < 32768:
                        payload = self._http_queue.popleft()
                        self._http_queued_bytes -= len(payload)
                        pending.extend(payload)
                if pending:
                    connection.sendall(pending)
                    with self._rtp_lock:
                        self._rtp_stats["http_bytes_sent"] += len(pending)
                    pending.clear()
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            with self._http_condition:
                self._rtp_stats["http_connections"] = max(
                    0, self._rtp_stats["http_connections"] - 1
                )
                self._http_clients.discard(connection)

    def _queue_pcm(self, payload):
        if not payload:
            return
        with self._http_condition:
            self._http_queue.append(payload)
            self._http_queued_bytes += len(payload)
            while self._http_queued_bytes > HTTP_QUEUE_LIMIT and self._http_queue:
                discarded = self._http_queue.popleft()
                self._http_queued_bytes -= len(discarded)
                with self._rtp_lock:
                    self._rtp_stats["http_dropped_bytes"] += len(discarded)
            self._http_condition.notify_all()

    def _rtp_relay_loop(self):
        while not self._rtp_stop.is_set():
            try:
                packet, sender = self._rtp_receiver.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                if not self._rtp_stop.is_set():
                    with self._rtp_lock:
                        self._rtp_stats["forward_errors"] += 1
                break

            if sender[0] != "127.0.0.1":
                continue
            now = time.monotonic()
            parsed = self._rtp_header(packet)
            forward_pcm = False
            gap_silence = b""
            with self._rtp_lock:
                stats = self._rtp_stats
                stats["received"] += 1
                stats["bytes_received"] += len(packet)
                previous_packet_at = stats.get("last_packet_at")
                stats["last_packet_at"] = now
                if previous_packet_at is not None and now - previous_packet_at > 2.0:
                    stats["last_sequence"] = None
                    stats["last_timestamp"] = None
                    stats["last_payload_bytes"] = None
                    stats["stream_resets"] += 1
                if parsed is None:
                    stats["malformed"] += 1
                else:
                    sequence, timestamp, payload_bytes = parsed
                    previous_sequence = stats["last_sequence"]
                    previous_timestamp = stats["last_timestamp"]
                    previous_payload_bytes = stats["last_payload_bytes"]
                    if previous_sequence is None:
                        stats["last_sequence"] = sequence
                        stats["last_timestamp"] = timestamp
                        stats["last_payload_bytes"] = payload_bytes
                        forward_pcm = True
                    else:
                        sequence_delta = (sequence - previous_sequence) & 0xFFFF
                        if sequence_delta == 0:
                            stats["duplicates"] += 1
                        elif sequence_delta < 0x8000:
                            if sequence_delta > 1:
                                stats["sequence_gaps"] += sequence_delta - 1
                            if previous_timestamp is not None:
                                timestamp_delta = (timestamp - previous_timestamp) & 0xFFFFFFFF
                                expected_delta = (
                                    previous_payload_bytes // (CHANNELS * 2)
                                    if previous_payload_bytes is not None
                                    else 0
                                )
                                if expected_delta and timestamp_delta != expected_delta:
                                    stats["timestamp_jumps"] += 1
                                    missing_frames = timestamp_delta - expected_delta
                                    if (
                                        sequence_delta > 1
                                        and 0 < missing_frames <= RATE // 4
                                    ):
                                        gap_silence = b"\x00" * (
                                            missing_frames * CHANNELS * 2
                                        )
                                        stats["silence_filled_frames"] += missing_frames
                            stats["last_sequence"] = sequence
                            stats["last_timestamp"] = timestamp
                            stats["last_payload_bytes"] = payload_bytes
                            forward_pcm = True
                        else:
                            stats["out_of_order"] += 1
            if forward_pcm:
                payload = self._rtp_payload(packet)
                if len(payload) % (CHANNELS * 2) == 0:
                    if gap_silence:
                        self._queue_pcm(gap_silence)
                    self._queue_pcm(payload)
                else:
                    with self._rtp_lock:
                        self._rtp_stats["malformed"] += 1

    def _load_module(self, module_name, *arguments):
        result = self._pactl("load-module", module_name, *arguments)
        if not result.isdigit():
            raise AudioSetupError("PulseAudio hat keine Modul-ID zurückgegeben")
        module_id = result
        self.module_ids.append(module_id)
        return module_id

    def setup(self):
        if self.module_ids:
            return self.playback_url
        self.default_sink = self._pactl("get-default-sink")
        if not self.default_sink:
            raise AudioSetupError("PulseAudio meldet keinen aktiven Standard-Sink")
        self.original_inputs = self._sink_input_routes()
        self.port = self._free_rtp_port()
        self.relay_port = self.port
        try:
            self._start_http_server()
            self._start_rtp_relay()
            self._load_module(
                "module-null-sink",
                "sink_name={}".format(self.sink_name),
                "format=s16le",
                "rate={}".format(RATE),
                "channels={}".format(CHANNELS),
                "sink_properties=device.description=Soloist_Kodi",
            )
            self._load_module(
                "module-rtp-send",
                "source={}.monitor".format(self.sink_name),
                "destination_ip=127.0.0.1",
                "port={}".format(self.relay_port),
                "format=s16be",
                "rate={}".format(RATE),
                "channels={}".format(CHANNELS),
                "ttl=1",
            )
            # module-switch-on-connect can change the default when the new
            # null sink appears. Restore only the value observed before setup.
            current_sink = self._pactl("get-default-sink")
            if current_sink == self.sink_name:
                if self.default_sink in self._sink_names():
                    self._pactl("set-default-sink", self.default_sink)
                elif self.default_sink != "auto_null":
                    raise AudioSetupError(
                        "Der vorherige PulseAudio-Standardausgang ist nicht mehr vorhanden"
                    )
            self._restore_moved_inputs()
        except Exception:
            self.cleanup()
            raise
        self.logger(
            "PulseAudio-RTP zu lokalem HTTP/TCP-L16 für Kodi eingerichtet "
            "({} Hz, UDP-Eingang Port {}, Quelle {}).".format(
                RATE,
                self.relay_port,
                self.playback_url,
            )
        )
        return self.playback_url

    def _sink_input_routes(self):
        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
            inputs = json.loads(self._pactl("--format=json", "list", "sink-inputs"))
        except ValueError as error:
            raise AudioSetupError(
                "Vorhandene PulseAudio-Streams können nicht sicher geprüft werden"
            ) from error
        if not isinstance(sinks, list) or not isinstance(inputs, list):
            raise AudioSetupError("PulseAudio lieferte ungültige Streamdaten")
        names_by_index = {sink.get("index"): sink.get("name") for sink in sinks}
        return {
            str(item.get("index")): names_by_index.get(item.get("sink"))
            for item in inputs
            if item.get("index") is not None and names_by_index.get(item.get("sink"))
        }

    def diagnostic_snapshot(self):
        """Return the last PulseAudio snapshot and refresh it off the service loop."""
        with self._diagnostic_cache_lock:
            worker = self._diagnostic_worker
            if worker is None or not worker.is_alive():
                worker = threading.Thread(
                    target=self._refresh_diagnostic_snapshot,
                    name="soloist-audio-diagnostic",
                    daemon=True,
                )
                self._diagnostic_worker = worker
                worker.start()
            snapshot = self._diagnostic_cache
            captured_at = self._diagnostic_cache_at
        if captured_at is None:
            return "{} Snapshot=ausstehend".format(snapshot)
        age_ms = int(max(0.0, time.monotonic() - captured_at) * 1000)
        return "{} Snapshot_vor={}ms".format(snapshot, age_ms)

    def recovery_snapshot(self):
        """Expose live input and TCP progress for a conservative player recovery."""
        with self._rtp_lock:
            last_packet_at = self._rtp_stats["last_packet_at"]
            sent_bytes = self._rtp_stats["http_bytes_sent"]
            dropped_bytes = self._rtp_stats["http_dropped_bytes"]
            connections = self._rtp_stats["http_connections"]
        packet_age_ms = (
            None
            if last_packet_at is None
            else int(max(0.0, time.monotonic() - last_packet_at) * 1000)
        )
        return {
            "packet_age_ms": packet_age_ms,
            "sent_bytes": sent_bytes,
            "dropped_bytes": dropped_bytes,
            "connections": connections,
        }

    def _refresh_diagnostic_snapshot(self):
        try:
            snapshot = self._collect_diagnostic_snapshot()
        except Exception as error:
            snapshot = "PulseAudio-Probe=Fehler-{}".format(type(error).__name__)
        with self._diagnostic_cache_lock:
            self._diagnostic_cache = snapshot
            self._diagnostic_cache_at = time.monotonic()

    def _collect_diagnostic_snapshot(self):
        """Return PulseAudio state and optional RTP relay counters."""
        if not self.module_ids or self.port is None:
            return "RTP-Pfad=nicht eingerichtet"

        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
            sink_inputs = json.loads(
                self._pactl("--format=json", "list", "sink-inputs")
            )
        except (AudioSetupError, ValueError):
            return "RTP-Pfad=Statusabfrage fehlgeschlagen"

        if not isinstance(sinks, list) or not isinstance(sink_inputs, list):
            return "RTP-Pfad=ungültige PulseAudio-Antwort"

        sink = next(
            (entry for entry in sinks if entry.get("name") == self.sink_name),
            None,
        )
        if sink is None:
            return "RTP-Pfad=Soloist-Sink fehlt"

        sink_index = sink.get("index")
        routed_inputs = [
            entry
            for entry in sink_inputs
            if str(entry.get("sink")) == str(sink_index)
        ]
        corked_inputs = sum(
            1
            for entry in routed_inputs
            if entry.get("corked") is True
            or str(entry.get("corked", "")).lower() in ("yes", "true", "1")
        )
        with self._rtp_lock:
            stats = dict(self._rtp_stats)
            previous = dict(self._rtp_reported)
            self._rtp_reported = dict(stats)
        last_packet_at = stats.get("last_packet_at")
        packet_age_ms = (
            "unbekannt"
            if last_packet_at is None
            else str(int(max(0.0, time.monotonic() - last_packet_at) * 1000))
        )
        rtp = (
            "UDP_RTP_empfangen=+{received} Bytes=+{bytes_received} "
            "TCP_an_Kodi_gesendet=+{http_bytes_sent} HTTP_Verbindungen={http_connections} "
            "TCP_Puffer_verworfen=+{http_dropped_bytes} Lücken=+{sequence_gaps} "
            "RTP_Neustarts=+{stream_resets} "
            "Duplikate=+{duplicates} ungeordnet=+{out_of_order} "
            "Zeitstempelsprünge=+{timestamp_jumps} ungültig=+{malformed} "
            "Stille_bei_kleinen_Lücken=+{silence_filled_frames}Frames "
            "letztes_RTP_Paket_vor={packet_age_ms}ms"
        ).format(
            received=stats["received"] - previous["received"],
            bytes_received=stats["bytes_received"] - previous["bytes_received"],
            http_bytes_sent=stats["http_bytes_sent"] - previous["http_bytes_sent"],
            http_connections=stats["http_connections"],
            http_dropped_bytes=(
                stats["http_dropped_bytes"] - previous["http_dropped_bytes"]
            ),
            sequence_gaps=stats["sequence_gaps"] - previous["sequence_gaps"],
            stream_resets=stats["stream_resets"] - previous["stream_resets"],
            duplicates=stats["duplicates"] - previous["duplicates"],
            out_of_order=stats["out_of_order"] - previous["out_of_order"],
            timestamp_jumps=stats["timestamp_jumps"] - previous["timestamp_jumps"],
            malformed=stats["malformed"] - previous["malformed"],
            silence_filled_frames=(
                stats["silence_filled_frames"] - previous["silence_filled_frames"]
            ),
            packet_age_ms=packet_age_ms,
        )
        return "PulseAudio-Sinkzustand={} Eingänge={} pausierte_Eingänge={} " \
            "RTP-Sendemodul=geladen RTP-Eingangsport={} {}".format(
                sink.get("state", "unbekannt"),
                len(routed_inputs),
                corked_inputs,
                self.port,
                rtp,
            )

    def _sink_names(self):
        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
        except ValueError as error:
            raise AudioSetupError(
                "Vorhandene PulseAudio-Ausgänge können nicht sicher geprüft werden"
            ) from error
        if not isinstance(sinks, list):
            raise AudioSetupError("PulseAudio lieferte ungültige Ausgangsdaten")
        return {sink.get("name") for sink in sinks if sink.get("name")}

    def _restore_moved_inputs(self):
        if not self.original_inputs:
            return
        try:
            sinks = json.loads(self._pactl("--format=json", "list", "sinks"))
            inputs = json.loads(self._pactl("--format=json", "list", "sink-inputs"))
        except ValueError as error:
            raise AudioSetupError(
                "Bestehende PulseAudio-Streams können nicht geprüft werden"
            ) from error
        if not isinstance(sinks, list) or not isinstance(inputs, list):
            raise AudioSetupError("PulseAudio lieferte ungültige Streamdaten")
        names_by_index = {sink.get("index"): sink.get("name") for sink in sinks}
        for item in inputs:
            input_id = str(item.get("index"))
            previous_sink = self.original_inputs.get(input_id)
            current_sink = names_by_index.get(item.get("sink"))
            if previous_sink and current_sink == self.sink_name:
                if previous_sink == "auto_null" and previous_sink not in names_by_index.values():
                    continue
                try:
                    self._pactl("move-sink-input", input_id, previous_sink)
                except AudioSetupError as error:
                    raise AudioSetupError(
                        "Ein bestehender PulseAudio-Stream konnte nicht zurückgesetzt werden"
                    ) from error

    def cleanup(self):
        self._http_stop.set()
        with self._http_condition:
            self._http_condition.notify_all()
            http_clients = list(self._http_clients)
        for client in http_clients:
            try:
                client.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                client.close()
            except OSError:
                pass
        if self.http_server is not None:
            try:
                self.http_server.shutdown()
            except Exception:
                pass
            self.http_server.server_close()
            self.http_server = None
        if self.http_thread is not None and self.http_thread.is_alive():
            self.http_thread.join(timeout=1.0)
        self.http_thread = None
        if self.default_sink:
            try:
                current_sink = self._pactl("get-default-sink")
                if current_sink == self.sink_name:
                    if self.default_sink in self._sink_names():
                        self._pactl("set-default-sink", self.default_sink)
                self._restore_moved_inputs()
            except AudioSetupError:
                pass
        for module_id in reversed(self.module_ids):
            try:
                self._pactl("unload-module", module_id, check=False)
            except AudioSetupError:
                self.logger("Ein vom Add-on angelegtes PulseAudio-Modul blieb geladen")
        self.module_ids = []
        self._rtp_stop.set()
        for rtp_socket in (self._rtp_receiver, self._rtp_forwarder):
            if rtp_socket is not None:
                try:
                    rtp_socket.close()
                except OSError:
                    pass
        if self._rtp_thread is not None and self._rtp_thread.is_alive():
            self._rtp_thread.join(timeout=1.0)
        self._rtp_receiver = None
        self._rtp_forwarder = None
        self._rtp_thread = None
        self.original_inputs = {}
        self.playback_url = None
        with self._http_condition:
            self._http_queue.clear()
            self._http_queued_bytes = 0
            self._http_clients.clear()
        self.port = None
        self.relay_port = None
        self.default_sink = None


def playback_snapshot(event, previous=None):
    """Merge Soloist's full and incremental playback events safely."""
    state = dict(previous) if isinstance(previous, dict) else {}
    if not isinstance(event, dict):
        return state
    event_type = event.get("type")
    if event_type == "playback_state":
        return event
    if event_type == "track_changed":
        state["item"] = event.get("item")
    elif event_type == "playback_changed":
        state["status"] = event.get("status")
    elif event_type == "position_sync":
        state["position"] = event.get("position")
    elif event_type == "device_changed":
        state["is_active"] = event.get("is_active")
    elif event_type == "auth_state":
        state["logged_in"] = event.get("logged_in")
        state["is_active"] = event.get("is_active")
    return state


def kodi_music_item(event, playback_url, list_item_factory, artist_mbids_by_uri=None):
    """Map Soloist entity metadata to a Kodi music ListItem."""
    if not isinstance(event, dict):
        return None
    item = event.get("item")
    if not isinstance(item, dict):
        return None
    decorations = item.get("decorations") or {}
    if not isinstance(decorations, dict):
        return None
    identity = decorations.get("identity") or {}
    if not isinstance(identity, dict):
        return None
    title = _clean_text(identity.get("name"), 512)
    if not title:
        return None

    artist_entries = _creator_entries(decorations)
    artists = []
    for artist in artist_entries:
        if artist["name"] not in artists:
            artists.append(artist["name"])
    if not artists:
        artists = ["Unknown"]

    parent = decorations.get("parent") or {}
    if not isinstance(parent, dict):
        parent = {}
    album_entity = parent.get("entity") or {}
    if isinstance(album_entity, dict):
        album_decorations = album_entity.get("decorations") or {}
        if isinstance(album_decorations, dict):
            album_identity = album_decorations.get("identity") or {}
        else:
            album_identity = {}
        if isinstance(album_identity, dict):
            album = _clean_text(album_identity.get("name"), 512)
        else:
            album = ""
    else:
        album = ""
        album_decorations = {}
    album_artists = _creator_names(album_decorations)
    if not album_artists:
        album_artists = artists
    playback = decorations.get("playback") or {}
    if not isinstance(playback, dict):
        playback = {}
    content_ratings = playback.get("content_ratings") or []
    if not isinstance(content_ratings, list):
        content_ratings = []
    content_ratings = [
        _clean_text(rating, 64)
        for rating in content_ratings[:8]
        if _clean_text(rating, 64)
    ]
    list_item = list_item_factory(label=title, path=playback_url)
    info_tag = list_item.getMusicInfoTag()
    info_tag.setTitle(title)
    info_tag.setArtist(" / ".join(artists))
    info_tag.setAlbum(album)
    info_tag.setAlbumArtist(" / ".join(album_artists))
    info_tag.setComment(", ".join(content_ratings))
    info_tag.setMediaType("song")
    artist_mbids_by_uri = artist_mbids_by_uri or {}
    artist_mbids = []
    # Kodi aligns artist IDs by position, so omit them until every artist is known.
    if len(artist_entries) == len(artists):
        for artist in artist_entries:
            mbid = artist_mbids_by_uri.get(artist["uri"])
            if not isinstance(mbid, str) or not mbid:
                artist_mbids = []
                break
            artist_mbids.append(mbid)
    if len(artist_mbids) == len(artists) and artist_mbids:
        info_tag.setMusicBrainzArtistID(artist_mbids)
    visual_identity = decorations.get("visual_identity") or {}
    if not isinstance(visual_identity, dict):
        visual_identity = {}
    covers = visual_identity.get("cover") or []
    if not isinstance(covers, list):
        covers = []
    size_rank = {"small": 0, "default": 1, "large": 2, "xlarge": 3}
    selected_cover = None
    selected_rank = -1
    for cover in covers[:32]:
        if not isinstance(cover, dict):
            continue
        url = cover.get("url", "")
        if _is_spotify_cover(url):
            rank = size_rank.get(str(cover.get("size", "")).lower(), -1)
            if selected_cover is None or rank > selected_rank:
                selected_cover = url
                selected_rank = rank
    if selected_cover:
        list_item.setArt({"thumb": selected_cover, "icon": selected_cover})
    return list_item


def _creator_names(decorations):
    names = []
    for artist in _creator_entries(decorations):
        if artist["name"] not in names:
            names.append(artist["name"])
    return names


def creator_artists(item):
    """Return validated Spotify artist URIs and names from a Soloist item."""
    if not isinstance(item, dict):
        return []
    decorations = item.get("decorations") or {}
    if not isinstance(decorations, dict):
        return []
    return _creator_entries(decorations)


def _creator_entries(decorations):
    if not isinstance(decorations, dict):
        return []
    creators = decorations.get("creators") or []
    if not isinstance(creators, list):
        return []
    artists = []
    seen = set()
    for creator in creators[:32]:
        if not isinstance(creator, dict):
            continue
        entity = creator.get("entity") or {}
        if not isinstance(entity, dict):
            continue
        entity_decorations = entity.get("decorations") or {}
        if not isinstance(entity_decorations, dict):
            continue
        identity = entity_decorations.get("identity") or {}
        if not isinstance(identity, dict):
            continue
        name = _clean_text(identity.get("name"), 256)
        uri = entity.get("uri")
        if not isinstance(uri, str):
            uri = ""
        key = (uri, name)
        if name and key not in seen:
            seen.add(key)
            artists.append({"uri": uri, "name": name})
    return artists


def _clean_text(value, maximum):
    if not isinstance(value, str):
        return ""
    clean = " ".join(value.split())
    return clean[:maximum]


def _is_spotify_cover(value):
    if not isinstance(value, str):
        return False
    return value.startswith("https://i.scdn.co/") or value.startswith("https://mosaic.scdn.co/")
