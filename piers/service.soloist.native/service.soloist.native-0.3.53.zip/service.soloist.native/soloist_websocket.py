"""Small loopback-only WebSocket client for Soloist's JSON API."""

import base64
import hashlib
import json
import os
import queue
import socket
import struct
import threading
import time


MAX_FRAME_BYTES = 1024 * 1024
MAX_HANDSHAKE_BYTES = 16 * 1024
WEBSOCKET_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


class SoloistWebSocket:
    def __init__(self, data_dir, logger):
        self.data_dir = data_dir
        self.logger = logger
        self.events = queue.Queue(maxsize=200)
        self.commands = queue.Queue(maxsize=100)
        self.resync_requested = threading.Event()
        self.stop_event = threading.Event()
        self.connection_ready = threading.Event()
        self._resync_lock = threading.Lock()
        self._last_resync_requested_at = None
        self.thread = None
        self._command_lock = threading.Lock()
        self._diagnostic_lock = threading.Lock()
        self._connected_since = None
        self._connection_count = 0
        self._event_loss_count = 0
        self._event_sequence = 0
        self._last_received_at = None
        self._last_received_type = None
        self._last_command_queued_at = None
        self._last_command_queued = None
        self._last_command_sent_at = None
        self._last_command_sent = None
        self._last_disconnect_type = None

    def start(self):
        if self.thread is not None and self.thread.is_alive():
            return
        for event_queue in (self.events, self.commands):
            while True:
                try:
                    event_queue.get_nowait()
                except queue.Empty:
                    break
        self.stop_event.clear()
        self.resync_requested.clear()
        with self._resync_lock:
            self._last_resync_requested_at = None
        with self._command_lock:
            self.connection_ready.clear()
        self.thread = threading.Thread(
            target=self._run,
            name="soloist-websocket",
            daemon=True,
        )
        self.thread.start()

    def stop(self, timeout=3):
        self.stop_event.set()
        with self._command_lock:
            self.connection_ready.clear()
        if self.thread is not None:
            self.thread.join(timeout=timeout)
            if not self.thread.is_alive():
                self.thread = None
        if self.thread is None:
            for event_queue in (self.events, self.commands):
                while True:
                    try:
                        event_queue.get_nowait()
                    except queue.Empty:
                        break
        self.resync_requested.clear()
        return self.thread is None

    def is_connected(self):
        return self.connection_ready.is_set()

    def control_generation(self):
        """Invalidate queue selections after reconnect or an overflowing event queue."""
        with self._diagnostic_lock:
            return self._connection_count, self._event_loss_count

    def event_cursor(self):
        """Local receive order only; not a Soloist request/response identifier."""
        with self._diagnostic_lock:
            return self._event_sequence

    def wait_until_connected(self, timeout):
        return self.connection_ready.wait(max(0.0, float(timeout)))

    def send_command(self, command, **fields):
        if not isinstance(command, str) or not command:
            return False
        message = {"type": "command", "command": command}
        message.update(fields)
        queued_at = time.monotonic()
        with self._command_lock:
            if not self.connection_ready.is_set():
                self.logger(
                    "Soloist-WebSocket-Befehl {} verworfen: Steuerverbindung getrennt.".format(
                        command
                    )
                )
                return False
            try:
                self.commands.put_nowait((message, queued_at))
            except queue.Full:
                self.logger("Soloist-WebSocket-Befehlswarteschlange ist voll")
                return False
            with self._diagnostic_lock:
                self._last_command_queued = command
                self._last_command_queued_at = queued_at
            return True

    @staticmethod
    def _drain_queue(event_queue):
        discarded = []
        while True:
            try:
                discarded.append(event_queue.get_nowait())
            except queue.Empty:
                return discarded

    def _discard_disconnected_commands(self):
        with self._command_lock:
            self.connection_ready.clear()
            discarded = self._drain_queue(self.commands)
        if discarded:
            names = [
                command.get("command", "unknown")
                for command, _queued_at in discarded
                if isinstance(command, dict)
            ]
            self.logger(
                "Soloist-WebSocket-Verbindung getrennt; {} nicht gesendete "
                "Steuerbefehle verworfen ({}). Sie werden nach Reconnect nicht "
                "nachträglich ausgeführt.".format(
                    len(discarded), ", ".join(names[:5]) or "unbekannt"
                )
            )
        return len(discarded)

    def _log_uncertain_command_send(self, inflight_command):
        command, queued_at = inflight_command
        name = command.get("command", "unknown")
        detail = ""
        if name == "seek" and isinstance(command.get("position_ms"), int):
            detail = " position_ms={}".format(command["position_ms"])
        self.logger(
            "Soloist-WebSocket-Sendestatus unsicher: Befehl {}{} wurde beim "
            "Verbindungsabbruch nicht bestätigt; keine automatische "
            "Wiederholung (Wartedauer={}ms).".format(
                name,
                detail,
                int(max(0.0, time.monotonic() - queued_at) * 1000),
            )
        )

    def get_event(self):
        try:
            return self.events.get_nowait()
        except queue.Empty:
            return None

    def diagnostic_snapshot(self):
        """Return bounded connection/command telemetry without message contents."""
        now = time.monotonic()
        with self._diagnostic_lock:
            connected_since = self._connected_since
            received_at = self._last_received_at
            received_type = self._last_received_type
            queued_at = self._last_command_queued_at
            queued_command = self._last_command_queued
            sent_at = self._last_command_sent_at
            sent_command = self._last_command_sent
            disconnect_type = self._last_disconnect_type
            connection_count = self._connection_count
        thread_alive = bool(self.thread and self.thread.is_alive())
        connected_age = (
            "unbekannt" if connected_since is None
            else "{}s".format(int(max(0.0, now - connected_since)))
        )
        receive_age = (
            "nie" if received_at is None
            else "{}ms".format(int(max(0.0, now - received_at) * 1000))
        )
        queued_age = (
            "keine" if queued_at is None
            else "{}ms".format(int(max(0.0, now - queued_at) * 1000))
        )
        sent_age = (
            "nie" if sent_at is None
            else "{}ms".format(int(max(0.0, now - sent_at) * 1000))
        )
        return (
            "WebSocket={} Thread={} Verbindungen={} verbunden_seit={}s "
            "letztes_Ereignis={} vor={} letzter_Befehl_eingereiht={}_vor={} "
            "wartende_Befehle={} wartende_Ereignisse={} zuletzt_gesendet={}_vor={} "
            "Trennung={}"
        ).format(
            "verbunden" if self.is_connected() else "getrennt",
            "läuft" if thread_alive else "steht",
            connection_count,
            connected_age,
            received_type or "keins",
            receive_age,
            queued_command or "keiner",
            queued_age,
            self.commands.qsize(),
            self.events.qsize(),
            sent_command or "keiner",
            sent_age,
            disconnect_type or "keine",
        )

    def _endpoint(self):
        try:
            with open(
                os.path.join(self.data_dir, "ws.addr"), "r", encoding="ascii"
            ) as address_file:
                address = address_file.read(128).strip()
            with open(os.path.join(self.data_dir, "ws.port"), "r", encoding="ascii") as port_file:
                port_text = port_file.read(16).strip()
            port = int(port_text)
        except (OSError, UnicodeError, ValueError):
            return None
        if address not in ("127.0.0.1", "::1", "localhost") or not 1 <= port <= 65535:
            self.logger("Soloist-WebSocket-Endpunkt ist nicht auf Loopback gebunden")
            return None
        return address, port

    @staticmethod
    def _receive_exact(connection, size):
        chunks = []
        remaining = size
        while remaining:
            chunk = connection.recv(remaining)
            if not chunk:
                raise ConnectionError("WebSocket closed")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    @classmethod
    def _handshake(cls, connection, host, port):
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            "GET / HTTP/1.1\r\n"
            "Host: {}:{}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            "Sec-WebSocket-Key: {}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        ).format(host, port, key).encode("ascii")
        connection.sendall(request)
        response = bytearray()
        while not response.endswith(b"\r\n\r\n"):
            chunk = connection.recv(1)
            if not chunk or len(response) >= MAX_HANDSHAKE_BYTES:
                raise ConnectionError("Invalid WebSocket handshake")
            response.extend(chunk)
        lines = response.decode("latin-1").split("\r\n")
        if not lines or " 101 " not in lines[0]:
            raise ConnectionError("WebSocket upgrade rejected")
        headers = {}
        for line in lines[1:]:
            if ":" in line:
                name, value = line.split(":", 1)
                headers[name.strip().lower()] = value.strip()
        expected = base64.b64encode(
            hashlib.sha1((key + WEBSOCKET_GUID).encode("ascii")).digest()
        ).decode("ascii")
        if headers.get("sec-websocket-accept") != expected:
            raise ConnectionError("Invalid WebSocket accept header")

    @classmethod
    def _send_frame(cls, connection, payload, opcode=1):
        payload = payload.encode("utf-8") if isinstance(payload, str) else payload
        if len(payload) > MAX_FRAME_BYTES:
            raise ValueError("WebSocket message is too large")
        mask = os.urandom(4)
        length = len(payload)
        header = bytearray((0x80 | opcode,))
        if length < 126:
            header.append(0x80 | length)
        elif length < 65536:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))
        masked = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
        connection.sendall(bytes(header) + mask + masked)

    @classmethod
    def _receive_frame(cls, connection):
        first, second = cls._receive_exact(connection, 2)
        final = bool(first & 0x80)
        opcode = first & 0x0F
        masked = bool(second & 0x80)
        length = second & 0x7F
        if length == 126:
            length = struct.unpack("!H", cls._receive_exact(connection, 2))[0]
        elif length == 127:
            length = struct.unpack("!Q", cls._receive_exact(connection, 8))[0]
        if length > MAX_FRAME_BYTES:
            raise ValueError("WebSocket frame is too large")
        if opcode >= 0x8 and (not final or length > 125):
            raise ValueError("Invalid WebSocket control frame")
        mask = cls._receive_exact(connection, 4) if masked else None
        payload = cls._receive_exact(connection, length)
        if mask:
            payload = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
        return opcode, payload, final

    @classmethod
    def _receive_message(cls, connection):
        opcode, payload, final = cls._receive_frame(connection)
        if opcode in (0x8, 0x9, 0xA):
            return opcode, payload
        if opcode not in (0x1, 0x2):
            raise ValueError("Invalid WebSocket data opcode")
        if final:
            return opcode, payload

        fragments = [payload]
        total_size = len(payload)
        while True:
            next_opcode, fragment, final = cls._receive_frame(connection)
            if next_opcode == 0x8:
                return next_opcode, fragment
            if next_opcode == 0x9:
                cls._send_frame(connection, fragment, opcode=0xA)
                continue
            if next_opcode == 0xA:
                continue
            if next_opcode != 0x0:
                raise ValueError("Invalid WebSocket continuation frame")
            total_size += len(fragment)
            if total_size > MAX_FRAME_BYTES:
                raise ValueError("WebSocket message is too large")
            fragments.append(fragment)
            if final:
                return opcode, b"".join(fragments)

    def _queue_event(self, event):
        if not isinstance(event, dict) or not isinstance(event.get("type"), str):
            return
        with self._diagnostic_lock:
            self._last_received_at = time.monotonic()
            self._last_received_type = event.get("type")
            self._event_sequence += 1
            event = dict(event, _soloist_event_sequence=self._event_sequence)
        try:
            self.events.put_nowait(event)
        except queue.Full:
            with self._diagnostic_lock:
                self._event_loss_count += 1
            try:
                dropped = self.events.get_nowait()
            except queue.Empty:
                dropped = None
            dropped_type = (
                dropped.get("type")
                if isinstance(dropped, dict) and isinstance(dropped.get("type"), str)
                else "unknown"
            )
            self.logger(
                "Soloist-WebSocket-Ereigniswarteschlange voll; "
                "ältestes Ereignis verworfen (type={})".format(dropped_type)
            )
            if not self._request_resync():
                self.logger(
                    "Soloist-WebSocket-Vollstatusanforderung wegen jüngstem "
                    "Ereignisverlust gedrosselt."
                )
            try:
                self.events.put_nowait(event)
            except queue.Full:
                pass

    def _request_resync(self):
        now = time.monotonic()
        with self._resync_lock:
            if (
                self._last_resync_requested_at is not None
                and now - self._last_resync_requested_at < 5.0
            ):
                return False
            self._last_resync_requested_at = now
            self.resync_requested.set()
            return True

    def _run(self):
        retry_delay = 1
        while not self.stop_event.is_set():
            endpoint = self._endpoint()
            if endpoint is None:
                self.stop_event.wait(retry_delay)
                continue
            connection = None
            inflight_command = None
            try:
                host, port = endpoint
                connection = socket.create_connection((host, port), timeout=3)
                connection.settimeout(0.5)
                self._handshake(connection, host, port)
                # The fresh auth/state request below supersedes any resync
                # request left behind by the connection that just failed.
                self.resync_requested.clear()
                with self._resync_lock:
                    self._last_resync_requested_at = None
                stale_events = self._drain_queue(self.events)
                if stale_events:
                    event_types = [
                        event.get("type", "unknown")
                        for event in stale_events
                        if isinstance(event, dict)
                    ]
                    self.logger(
                        "Soloist-WebSocket-Reconnect: {} veraltete Ereignisse "
                        "vor neuem Zustandsabruf verworfen ({}).".format(
                            len(stale_events),
                            ", ".join(event_types[:5]) or "unbekannt",
                        )
                    )
                with self._command_lock:
                    self.connection_ready.set()
                with self._diagnostic_lock:
                    self._connection_count += 1
                    self._connected_since = time.monotonic()
                    self._last_disconnect_type = None
                self.logger("Soloist-WebSocket verbunden (Verbindung {}).".format(
                    self._connection_count
                ))
                self._send_frame(
                    connection,
                    json.dumps({"type": "command", "command": "get_auth_state"}),
                )
                self._send_frame(
                    connection,
                    json.dumps({"type": "command", "command": "get_state"}),
                )
                retry_delay = 1
                while not self.stop_event.is_set():
                    while True:
                        try:
                            command, queued_at = self.commands.get_nowait()
                        except queue.Empty:
                            break
                        inflight_command = (command, queued_at)
                        self._send_frame(connection, json.dumps(command, separators=(",", ":")))
                        inflight_command = None
                        name = command.get("command", "unknown")
                        sent_at = time.monotonic()
                        with self._diagnostic_lock:
                            self._last_command_sent = name
                            self._last_command_sent_at = sent_at
                        detail = ""
                        if name == "seek" and isinstance(command.get("position_ms"), int):
                            detail = " position_ms={}".format(command["position_ms"])
                        self.logger(
                            "Soloist-WebSocket-Steuerbefehl gesendet: {}{} Wartedauer={}ms".format(
                                name,
                                detail,
                                int(max(0.0, sent_at - queued_at) * 1000),
                            )
                        )
                    if self.resync_requested.is_set():
                        self.resync_requested.clear()
                        self._send_frame(
                            connection,
                            json.dumps(
                                {"type": "command", "command": "get_state"},
                                separators=(",", ":"),
                            ),
                        )
                        self.logger(
                            "Soloist-WebSocket-Ereignisverlust erkannt; "
                            "vollständigen playback_state zur Synchronisierung angefordert."
                        )
                    try:
                        opcode, payload = self._receive_message(connection)
                    except socket.timeout:
                        continue
                    if opcode == 0x8:
                        break
                    if opcode == 0x9:
                        self._send_frame(connection, payload, opcode=0xA)
                        continue
                    if opcode != 0x1:
                        continue
                    try:
                        self._queue_event(json.loads(payload.decode("utf-8")))
                    except (UnicodeError, ValueError):
                        self.logger("Soloist-WebSocket-Nachricht ist ungültig")
            except (OSError, ConnectionError, ValueError) as error:
                with self._diagnostic_lock:
                    self._last_disconnect_type = type(error).__name__
                if not self.stop_event.is_set():
                    detail = " ".join(
                        char for char in str(error) if char.isprintable()
                    )[:120]
                    message = "Soloist-WebSocket getrennt ({})".format(
                        type(error).__name__
                    )
                    if detail:
                        message += ": {}".format(detail)
                    self.logger(message)
            finally:
                if inflight_command is not None:
                    self._log_uncertain_command_send(inflight_command)
                self._discard_disconnected_commands()
                with self._diagnostic_lock:
                    self._connected_since = None
                if connection is not None:
                    try:
                        connection.close()
                    except OSError:
                        pass
            self.stop_event.wait(retry_delay)
            retry_delay = min(retry_delay * 2, 15)
