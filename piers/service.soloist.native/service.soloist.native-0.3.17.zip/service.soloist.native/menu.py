"""Kodi controls for status, API-key storage, and the Soloist service."""

import json
import os
import uuid

import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs

from credentials import delete_api_key, load_api_key, save_api_key


ADDON_ID = "service.soloist.native"
COMMAND_PROPERTY = "service.soloist.native.command"
RESULT_PROPERTY = "service.soloist.native.result"
WINDOW_ID = 10000
REQUEST_TIMEOUT_SECONDS = 90


RESULT_STRINGS = {
    "started": 32017,
    "already_running": 32018,
    "stopped:0": 32019,
    "not_running": 32020,
    "binary_missing": 32021,
    "configuration_missing": 32022,
    "install_failed": 32023,
    "audio_setup_failed": 32035,
    "start_failed": 32024,
    "download_consent_required": 32025,
    "invalid_command": 32026,
    "command_failed": 32026,
    "request_timeout": 32030,
    "control_queued": 32039,
}


def _data_path(addon):
    return xbmcvfs.translatePath(addon.getAddonInfo("profile"))


def _request_service(
    action, allow_download=False, control=None, timeout=REQUEST_TIMEOUT_SECONDS
):
    window = xbmcgui.Window(WINDOW_ID)
    monitor = xbmc.Monitor()
    request_id = uuid.uuid4().hex
    payload = {
        "action": action,
        "allow_download": bool(allow_download),
        "request_id": request_id,
    }
    if control is not None:
        payload["control"] = control
    window.setProperty(COMMAND_PROPERTY, json.dumps(payload))
    for _ in range(int(timeout / 0.25)):
        if monitor.waitForAbort(0.25):
            return "invalid_command"
        raw_result = window.getProperty(RESULT_PROPERTY)
        if not raw_result:
            continue
        try:
            result = json.loads(raw_result)
        except ValueError:
            continue
        if result.get("request_id") == request_id:
            window.clearProperty(RESULT_PROPERTY)
            return result.get("code", "invalid_command")
    return "request_timeout"


def show_status():
    """Show the current runtime status without exposing credentials."""
    addon = xbmcaddon.Addon()
    data_path = _data_path(addon)
    binary_path = os.path.join(data_path, "soloist", "bin", "soloist")
    installed = os.path.isfile(binary_path)
    runtime = _request_service("status", timeout=3)
    runtime_string = {
        "ready": 32048,
        "running_disconnected": 32049,
        "not_running": 32050,
        "configuration_missing": 32042,
        "binary_missing": 32043,
        "request_timeout": 32051,
        "invalid_command": 32051,
    }.get(runtime, 32051)
    xbmcgui.Dialog().ok(
        addon.getLocalizedString(32002),
        "{}\n{}".format(
            addon.getLocalizedString(runtime_string),
            addon.getLocalizedString(32015 if installed else 32014),
        ),
    )


def _save_key(addon):
    data_path = _data_path(addon)
    dialog = xbmcgui.Dialog()
    value = dialog.input(
        addon.getLocalizedString(32010),
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT,
    )
    if not value:
        return
    try:
        save_api_key(data_path, value)
    except (OSError, ValueError):
        dialog.notification(
            addon.getLocalizedString(32000),
            addon.getLocalizedString(32027),
            xbmcgui.NOTIFICATION_ERROR,
        )
        return
    dialog.notification(addon.getLocalizedString(32000), addon.getLocalizedString(32011))


def _start(addon):
    dialog = xbmcgui.Dialog()
    data_path = _data_path(addon)
    if load_api_key(data_path) is None:
        _save_key(addon)
        if load_api_key(data_path) is None:
            return

    device_name = addon.getSetting("device_name").strip()
    if not device_name:
        device_name = dialog.input(
            addon.getLocalizedString(32008),
            defaultt="Kodi Soloist",
            type=xbmcgui.INPUT_ALPHANUM,
        ).strip()
        if not device_name or len(device_name) > 80 or any(ord(char) < 32 for char in device_name):
            return
        addon.setSetting("device_name", device_name)

    binary_path = os.path.join(data_path, "soloist", "bin", "soloist")
    allow_download = False
    if not os.path.isfile(binary_path):
        allow_download = dialog.yesno(
            addon.getLocalizedString(32000),
            addon.getLocalizedString(32012),
            yeslabel=addon.getLocalizedString(32028),
            nolabel=addon.getLocalizedString(32029),
        )
        if not allow_download:
            return

    result = _request_service("start", allow_download=allow_download)
    message_id = RESULT_STRINGS.get(result)
    if message_id is None:
        message_id = 32030 if result == "request_timeout" else 32026
    icon = (
        xbmcgui.NOTIFICATION_INFO
        if result in ("started", "already_running")
        else xbmcgui.NOTIFICATION_ERROR
    )
    dialog.notification(
        addon.getLocalizedString(32000), addon.getLocalizedString(message_id), icon
    )


def _stop(addon):
    result = _request_service("stop")
    if result.startswith("stopped:"):
        result = "stopped:0"
    message_id = RESULT_STRINGS.get(result, 32026)
    icon = (
        xbmcgui.NOTIFICATION_INFO
        if result.startswith("stopped") or result == "not_running"
        else xbmcgui.NOTIFICATION_ERROR
    )
    xbmcgui.Dialog().notification(
        addon.getLocalizedString(32000), addon.getLocalizedString(message_id), icon
    )


def _control(addon, control):
    result = _request_service("control", control=control)
    message_id = RESULT_STRINGS.get(result, 32026)
    icon = xbmcgui.NOTIFICATION_INFO if result == "control_queued" else xbmcgui.NOTIFICATION_ERROR
    xbmcgui.Dialog().notification(
        addon.getLocalizedString(32000), addon.getLocalizedString(message_id), icon
    )


def _delete_key(addon):
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(addon.getLocalizedString(32000), addon.getLocalizedString(32009)):
        return
    result = _request_service("stop")
    if result != "not_running" and not result.startswith("stopped:"):
        dialog.notification(
            addon.getLocalizedString(32000),
            addon.getLocalizedString(32026),
            xbmcgui.NOTIFICATION_ERROR,
        )
        return
    delete_api_key(_data_path(addon))
    dialog.notification(addon.getLocalizedString(32000), addon.getLocalizedString(32034))


def show_menu():
    addon = xbmcaddon.Addon()
    dialog = xbmcgui.Dialog()
    choices = [
        addon.getLocalizedString(32002),
        addon.getLocalizedString(32007),
        addon.getLocalizedString(32037),
        addon.getLocalizedString(32038),
        addon.getLocalizedString(32040),
        addon.getLocalizedString(32031),
        addon.getLocalizedString(32032),
        addon.getLocalizedString(32033),
    ]
    selected = dialog.select(addon.getLocalizedString(32000), choices)
    if selected == 0:
        show_status()
    elif selected == 1:
        _start(addon)
    elif selected == 2:
        _control(addon, "toggle")
    elif selected == 3:
        _control(addon, "previous")
    elif selected == 4:
        _control(addon, "next")
    elif selected == 5:
        _stop(addon)
    elif selected == 6:
        _save_key(addon)
    elif selected == 7:
        _delete_key(addon)


if __name__ == "__main__":
    show_menu()
