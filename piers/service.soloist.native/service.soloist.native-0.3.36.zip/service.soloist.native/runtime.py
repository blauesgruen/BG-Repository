"""Download and validate the official Spotify Soloist Linux AArch64 build."""

import os
import ssl
import struct
import subprocess
import tarfile
import tempfile
import urllib.request
import zlib
from urllib.parse import urlparse


DOWNLOAD_URL = "https://soloist-builds.spotifycdn.com/soloist_release_arm64.tar.gz"
MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
MAX_BINARY_BYTES = 128 * 1024 * 1024
DOWNLOAD_TIMEOUT_SECONDS = 30
VERSION_TIMEOUT_SECONDS = 10


class SoloistRuntimeError(Exception):
    """A safe, user-displayable runtime installation error."""


def _validate_aarch64_elf(binary_path):
    with open(binary_path, "rb") as binary_file:
        header = binary_file.read(64)
    if (
        len(header) < 20
        or header[:4] != b"\x7fELF"
        or header[4] != 2
        or header[5] != 1
        or struct.unpack("<H", header[18:20])[0] != 183
    ):
        raise SoloistRuntimeError("Das Spotify-Binary ist kein Linux-AArch64-Programm")


def _download_archive(archive_path, opener=None):
    open_url = opener or urllib.request.urlopen
    request = urllib.request.Request(
        DOWNLOAD_URL,
        headers={"User-Agent": "Kodi-Soloist-Native"},
    )
    context = ssl.create_default_context()
    total = 0
    try:
        response = open_url(
            request,
            timeout=DOWNLOAD_TIMEOUT_SECONDS,
            context=context,
        )
        with response, open(archive_path, "wb") as archive_file:
            final_url = response.geturl()
            parsed_url = urlparse(final_url)
            if (
                parsed_url.scheme.lower() != "https"
                or parsed_url.hostname != "soloist-builds.spotifycdn.com"
            ):
                raise SoloistRuntimeError(
                    "Der Download endete außerhalb der offiziellen Spotify-Quelle"
                )
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_ARCHIVE_BYTES:
                    raise SoloistRuntimeError(
                        "Das Spotify-Archiv überschreitet die Größenbegrenzung"
                    )
                archive_file.write(chunk)
    except SoloistRuntimeError:
        raise
    except Exception as error:
        raise SoloistRuntimeError("Der Download von Spotify ist fehlgeschlagen") from error
    if total == 0:
        raise SoloistRuntimeError("Spotify hat ein leeres Archiv geliefert")


def _extract_binary(archive_path, candidate_path):
    try:
        with tarfile.open(archive_path, mode="r|gz") as archive:
            binary_count = 0
            seen_names = set()
            total_size = 0
            member_count = 0
            for member in archive:
                member_count += 1
                if member_count > 3:
                    raise SoloistRuntimeError(
                        "Spotify-Archiv enthält eine ungültige Anzahl Dateien"
                    )
                name = member.name
                if (
                    not name
                    or name.startswith("/")
                    or ".." in name.split("/")
                    or "\\" in name
                ):
                    raise SoloistRuntimeError("Spotify-Archiv enthält einen ungültigen Pfad")
                if name in seen_names:
                    raise SoloistRuntimeError("Spotify-Archiv enthält doppelte Einträge")
                seen_names.add(name)
                total_size += member.size
                if (
                    member.size < 0
                    or member.size > MAX_BINARY_BYTES
                    or total_size > MAX_ARCHIVE_BYTES
                ):
                    raise SoloistRuntimeError("Spotify-Archiv überschreitet die Größenbegrenzung")
                if name == "soloist":
                    if not member.isfile():
                        raise SoloistRuntimeError("Spotify-Archiv enthält kein reguläres Binary")
                    binary_count += 1
                    if member.size <= 0 or member.size > MAX_BINARY_BYTES:
                        raise SoloistRuntimeError("Das Spotify-Binary hat eine ungültige Größe")
                    source = archive.extractfile(member)
                    if source is None:
                        raise SoloistRuntimeError("Das Spotify-Binary kann nicht gelesen werden")
                    with source, open(candidate_path, "wb") as candidate:
                        remaining = member.size
                        while remaining:
                            chunk = source.read(min(1024 * 1024, remaining))
                            if not chunk:
                                raise SoloistRuntimeError("Das Spotify-Binary ist unvollständig")
                            candidate.write(chunk)
                            remaining -= len(chunk)
                        if source.read(1):
                            raise SoloistRuntimeError(
                                "Das Spotify-Binary ist größer als im Archiv angegeben"
                            )
                elif name not in ("CHANGELOG.md", "THIRD_PARTY_LICENSES.txt"):
                    raise SoloistRuntimeError("Spotify-Archiv enthält einen unerwarteten Eintrag")
                elif not member.isfile():
                    raise SoloistRuntimeError("Spotify-Archiv enthält einen unerwarteten Dateityp")

            if member_count == 0 or binary_count != 1:
                raise SoloistRuntimeError("Spotify-Archiv enthält nicht genau ein Soloist-Binary")
        os.chmod(candidate_path, 0o700)
    except SoloistRuntimeError:
        raise
    except (OSError, EOFError, tarfile.TarError, zlib.error) as error:
        raise SoloistRuntimeError(
            "Das Spotify-Archiv ist beschädigt oder ungültig ({})".format(
                type(error).__name__
            )
        ) from error


def _check_version(binary_path, runner=None):
    run = runner or subprocess.run
    try:
        result = run(
            [binary_path, "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=VERSION_TIMEOUT_SECONDS,
            check=False,
        )
    except Exception as error:
        raise SoloistRuntimeError(
            "Das Soloist-Binary kann auf diesem Gerät nicht gestartet werden"
        ) from error
    output = result.stdout or ""
    if result.returncode != 0 or "linux/aarch64" not in output.lower():
        raise SoloistRuntimeError("Spotify lieferte kein startfähiges Linux-AArch64-Binary")
    return output.strip()


def install_soloist(data_dir, opener=None, runner=None):
    """Download, validate, and atomically install Soloist under add-on data."""
    root = os.path.join(data_dir, "soloist")
    binary_dir = os.path.join(root, "bin")
    runtime_dir = os.path.join(data_dir, "runtime")
    final_path = os.path.join(binary_dir, "soloist")
    archive_path = None
    candidate_path = None
    try:
        os.makedirs(binary_dir, mode=0o700, exist_ok=True)
        os.makedirs(runtime_dir, mode=0o700, exist_ok=True)
        os.chmod(binary_dir, 0o700)
        os.chmod(runtime_dir, 0o700)
        archive_descriptor, archive_path = tempfile.mkstemp(
            prefix="soloist-", suffix=".tar.gz", dir=runtime_dir
        )
        os.close(archive_descriptor)
        candidate_descriptor, candidate_path = tempfile.mkstemp(
            prefix=".soloist-", dir=binary_dir
        )
        os.close(candidate_descriptor)
        _download_archive(archive_path, opener=opener)
        _extract_binary(archive_path, candidate_path)
        _validate_aarch64_elf(candidate_path)
        version = _check_version(candidate_path, runner=runner)
        os.replace(candidate_path, final_path)
        return final_path, version
    except SoloistRuntimeError:
        raise
    except OSError as error:
        raise SoloistRuntimeError("Kodi-Datenpfad ist nicht beschreibbar") from error
    finally:
        for temporary_path in (archive_path, candidate_path):
            if temporary_path is None:
                continue
            try:
                os.unlink(temporary_path)
            except FileNotFoundError:
                pass
