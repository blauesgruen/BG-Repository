"""Own and supervise the Soloist process started by this Kodi service."""

import os
import re
import queue
import subprocess
import threading
import time

from runtime import soloist_environment


class SoloistProcess:
    def __init__(self, binary_path, data_dir, cache_dir, logger, popen_factory=None):
        self.binary_path = binary_path
        self.data_dir = data_dir
        self.cache_dir = cache_dir
        self.logger = logger
        self.popen_factory = popen_factory or subprocess.Popen
        self.process = None
        self.api_key = None
        self.output_thread = None
        self.verbose_logging = False
        self._output_queue = queue.Queue(maxsize=64)
        self._output_lock = threading.Lock()
        self._output_stats = self._empty_output_stats()

    @staticmethod
    def _empty_output_stats():
        return {"lines": 0, "last": None, "read_error": None, "dropped": 0,
                "logger_errors": 0, "logger_error": None, "eof": False,
                "replacement_characters": 0, "cleanup_error": None}

    def is_running(self):
        return self.process is not None and self.process.poll() is None

    def start(self, device_name, api_key, audio_sink=None):
        if self.is_running():
            return "already_running"
        # Do not replace references while a previous reader still owns its pipe.
        if self.process is not None and self.poll_exit() is None:
            return "start_failed"
        if self.output_thread is not None and self.output_thread.is_alive():
            return "start_failed"
        if not os.path.isfile(self.binary_path) or not os.access(self.binary_path, os.X_OK):
            return "binary_missing"
        if not device_name or not api_key:
            return "configuration_missing"

        os.makedirs(self.data_dir, mode=0o700, exist_ok=True)
        os.makedirs(self.cache_dir, mode=0o700, exist_ok=True)
        os.chmod(self.data_dir, 0o700)
        os.chmod(self.cache_dir, 0o700)
        for filename in ("ws.addr", "ws.port"):
            try:
                os.unlink(os.path.join(self.data_dir, filename))
            except FileNotFoundError:
                pass
        arguments = [
            self.binary_path,
            "--device-name",
            device_name,
            "--api-key",
            api_key,
            "--data-dir",
            self.data_dir,
            "--cache-dir",
            self.cache_dir,
            "--ws",
            "127.0.0.1:0",
        ]
        # Always collect Soloist's detailed output, but only forward the
        # selected audio-renderer/backend markers to Kodi's log.
        arguments.append("--verbose")
        if audio_sink and (not audio_sink.replace("_", "").isalnum()):
            return "invalid_audio_sink"
        self._output_queue = queue.Queue(maxsize=64)
        with self._output_lock:
            self._output_stats = self._empty_output_stats()
        self.api_key = api_key
        self.verbose_logging = True
        # Our own libatomic (LibreELEC 64-bit) lives in <soloist>/lib.
        environment = soloist_environment(
            os.path.dirname(os.path.dirname(self.binary_path)), os.environ)
        if audio_sink:
            environment["PULSE_SINK"] = audio_sink
        try:
            self.process = self.popen_factory(
                arguments,
                cwd=os.path.dirname(self.binary_path),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=1,
                universal_newlines=True,
                encoding="utf-8",
                errors="replace",
                close_fds=True,
                env=environment,
            )
        except OSError as error:
            self.process = None
            self.api_key = None
            self.verbose_logging = False
            self._emit_log(
                "Soloist konnte nicht gestartet werden ({})".format(
                    type(error).__name__
                )
            )
            return "start_failed"

        self.output_thread = threading.Thread(
            target=self._read_output,
            args=(self.process, api_key, True),
            name="soloist-log-reader",
            daemon=True,
        )
        try:
            self.output_thread.start()
        except RuntimeError:
            self.output_thread = None  # Thread.start did not establish a reader.
            with self._output_lock:
                self._output_stats["read_error"] = "ThreadStartError"
            self.stop(timeout=1.0)  # Keep ownership if bounded cleanup fails.
            return "start_failed"
        return "started"

    def _read_output(self, process, api_key, verbose_logging):
        if process.stdout is None:
            return
        try:
            for line in process.stdout:
                with self._output_lock:
                    self._output_stats["lines"] += 1
                    self._output_stats["last"] = time.monotonic()
                    self._output_stats["replacement_characters"] += line.count("\ufffd")
                message = line.rstrip()
                if api_key:
                    message = message.replace(api_key, "[redacted]")
                if len(message) > 2000:
                    message = message[:2000] + "…"
                lowered = message.lower()
                is_error = any(
                    word in lowered for word in ("error", "failed", "failure", "expired")
                )
                audio_markers = (
                    "pulseaudio",
                    "pipewire",
                    "renderer_source",
                    "audiorendererimpl",
                    "timeline attacher",
                    "onpreparetransition",
                    "ontransitiontrigger",
                    "mixer@",
                    "onaudiostarted",
                    "onaudioended",
                    "audiobufferedsinkimpl",
                    "eof at",
                    "format [",
                    "reason_end:",
                    "next_transition:",
                    "open prepared track",
                    "written eos to driver",
                    # Spotify loudness normalization per track (0.3.88).
                    "gaincalculator",
                    "normalization:",
                )
                if is_error or (
                    verbose_logging
                    and any(marker in lowered for marker in audio_markers)
                ):
                    # Draining the child must never depend on Kodi's logger.
                    try:
                        self._output_queue.put_nowait(message)
                    except queue.Full:
                        with self._output_lock:
                            self._output_stats["dropped"] += 1
            with self._output_lock:
                self._output_stats["eof"] = True
        except Exception as error:
            # This thread boundary records only the type, never raw output.
            with self._output_lock:
                self._output_stats["read_error"] = type(error).__name__

    def _emit_log(self, message):
        try:
            self.logger(message)
        except Exception as error:
            with self._output_lock:
                self._output_stats["logger_errors"] += 1
                self._output_stats["logger_error"] = type(error).__name__

    @staticmethod
    def _clean_sdk_line(message):
        """Drop terminal colours, the SDK's own UTC clock and source padding."""
        message = re.sub(r"\x1b\[[0-9;]*[A-Za-z]|\[[0-9;]*m", "", message)
        message = re.sub(r"^\d{2}:\d{2}:\d{2}\.\d{3} ", "", message)
        message = re.sub(r"\[f:(\d+)\s+\]", r"[f:\1]", message)
        return message.strip()

    def forward_output(self, limit=20):
        """Forward bounded, already redacted messages on the service thread."""
        forwarded = 0
        while forwarded < limit:
            try:
                message = self._output_queue.get_nowait()
            except queue.Empty:
                break
            self._emit_log("Soloist: {}".format(self._clean_sdk_line(message)))
            forwarded += 1
        return forwarded

    def output_diagnostics(self):
        """Describe pipe health without contents, arguments, paths or keys."""
        with self._output_lock:
            stats = self._output_stats.copy()
        age = ("nie" if stats["last"] is None else
               "{}ms".format(int(max(0.0, time.monotonic() - stats["last"]) * 1000)))
        alive = bool(self.output_thread and self.output_thread.is_alive())
        return ("SDK-Ausgabe: Prozess_läuft={} reader_alive={} lines={} "
                "last_age={} error={} dropped={} eof={} Ersatzzeichen={} "
                "Loggerfehler={} letzter_Loggerfehler={} Aufräumfehler={}").format(
                    self.is_running(), alive, stats["lines"], age,
                    stats["read_error"] or "keiner", stats["dropped"], stats["eof"],
                    stats["replacement_characters"], stats["logger_errors"],
                    stats["logger_error"] or "keiner", stats["cleanup_error"] or "keiner")

    def _release_exited_process(self):
        # Only close the pipe after the reader is finished; cross-thread close
        # can itself wait forever on TextIOWrapper's active read lock.
        pipe = self.process.stdout
        close = getattr(pipe, "close", None)
        if callable(close):
            try:
                close()
            except (OSError, ValueError) as error:
                with self._output_lock:
                    self._output_stats["cleanup_error"] = type(error).__name__
        self.process = None
        self.api_key = None
        self.output_thread = None
        self.verbose_logging = False

    def poll_exit(self):
        if self.process is None or self.process.poll() is None:
            return None
        # Polling must not wait for pipe EOF from an inherited writer.
        if self.output_thread is not None and self.output_thread.is_alive():
            return None
        return_code = self.process.poll()
        self._release_exited_process()
        self._emit_log("Soloist-Prozess beendet (Exit-Code {}).".format(return_code))
        return return_code

    def stop(self, timeout=5):
        if self.process is None:
            return "not_running"
        timeout = max(0.0, float(timeout))
        process = self.process
        if process.poll() is None:
            try:
                process.terminate()
            except OSError:
                pass
            try:
                process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.kill()
                try:
                    process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    with self._output_lock:
                        self._output_stats["cleanup_error"] = "process_stop_timeout"
                    raise RuntimeError("Soloist process stop timed out") from None
        if self.output_thread is not None and self.output_thread.ident is not None:
            self.output_thread.join(timeout=timeout)
            if self.output_thread.is_alive():
                with self._output_lock:
                    self._output_stats["cleanup_error"] = "reader_stop_timeout"
                raise RuntimeError("Soloist output reader stop timed out")
        return_code = process.poll()
        self._release_exited_process()
        return "stopped:{}".format(return_code)
