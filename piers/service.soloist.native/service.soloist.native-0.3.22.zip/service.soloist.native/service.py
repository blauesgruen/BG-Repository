"""Kodi service entry point and owner of the Soloist child process."""

import json
import math
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from credentials import load_api_key
from audio import AudioSetupError
from audio import PulseRtpAudio
from runtime import install_soloist
from runtime import SoloistRuntimeError
from audio import kodi_music_item
from audio import playback_snapshot
from audio import creator_artists
from musicbrainz import MusicBrainzResolver
from soloist_process import SoloistProcess
from soloist_websocket import SoloistWebSocket


ADDON_ID = "service.soloist.native"
COMMAND_PROPERTY = "service.soloist.native.command"
RESULT_PROPERTY = "service.soloist.native.result"
UPDATE_READY_PROPERTY = "service.soloist.native.update_ready"
WINDOW_ID = 10000
POSITION_DIAGNOSTIC_INTERVAL = 15.0
AUDIO_FLOW_DIAGNOSTIC_INTERVAL = 5.0
STARTUP_DELAY_SECONDS = 5.0
CONNECTION_NOTICE_TIMEOUT = 15.0


def _safe_log(message, api_key=None, level=xbmc.LOGINFO):
    text = str(message)
    if api_key:
        text = text.replace(api_key, "[redacted]")
    xbmc.log("[{}] {}".format(ADDON_ID, text), level)


def _result(window, request_id, code):
    if request_id:
        window.setProperty(
            RESULT_PROPERTY,
            json.dumps({"request_id": request_id, "code": code}),
        )


def _notify(
    addon,
    message_id,
    icon=xbmcgui.NOTIFICATION_INFO,
    display_time=5000,
    sound=True,
):
    if addon.getSettingBool("show_startup_notification"):
        xbmcgui.Dialog().notification(
            addon.getLocalizedString(32000),
            addon.getLocalizedString(message_id),
            icon,
            display_time,
            sound,
        )
        return True
    return False


def _debug_log(addon, message, api_key=None):
    """Write selected, redacted diagnostics when add-on logging is enabled."""
    if addon.getSettingBool("debug_logging"):
        _safe_log("[Diagnose] {}".format(message), api_key, xbmc.LOGINFO)


def _player_debug_log(player_state, message):
    logger = player_state.get("debug_log")
    if callable(logger):
        logger(message)


def _player_can_seek():
    """Return Kodi's seek capability for the music player, or None if unknown."""
    request = {
        "jsonrpc": "2.0",
        "method": "Player.GetProperties",
        "params": {"playerid": 0, "properties": ["canseek"]},
        "id": 1,
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception:
        return None
    if not isinstance(response, dict):
        return None
    result = response.get("result")
    if not isinstance(result, dict) or not isinstance(result.get("canseek"), bool):
        return None
    return result["canseek"]


def _log_position_diagnostic(event, player_state):
    """Log a rate-limited, read-only comparison of Soloist and Kodi clocks."""
    if event.get("type") != "position_sync" or not player_state.get("owned"):
        return
    enabled = player_state.get("debug_logging_enabled")
    if not callable(enabled) or not enabled():
        return
    now = time.monotonic()
    if (
        now - player_state.get("last_position_diagnostic", 0.0)
        < POSITION_DIAGNOSTIC_INTERVAL
    ):
        return
    player = player_state["player"]
    if not player.isPlaying():
        return
    player_state["last_position_diagnostic"] = now
    position = event.get("position")
    if not isinstance(position, dict):
        position = {}
    anchor_ms = position.get("position_ms")
    timestamp_ms = position.get("timestamp_ms")
    soloist_speed = position.get("speed")
    estimated_position_ms = anchor_ms
    if (
        isinstance(anchor_ms, (int, float))
        and isinstance(timestamp_ms, (int, float))
        and isinstance(soloist_speed, (int, float))
        and math.isfinite(anchor_ms)
        and math.isfinite(timestamp_ms)
        and math.isfinite(soloist_speed)
    ):
        elapsed_ms = max(0.0, time.time() * 1000.0 - timestamp_ms)
        estimated_position_ms = int(anchor_ms + elapsed_ms * soloist_speed)
    try:
        kodi_time = player.getTime()
        kodi_total = player.getTotalTime()
        can_seek = _player_can_seek()
        _player_debug_log(
            player_state,
            "Player-Zeitprobe: Soloist-Anker={} ms, geschätzt={} ms (Tempo {}), "
            "Kodi={:.3f}/{:.3f} s, Kodi-suchbar={}".format(
                anchor_ms,
                estimated_position_ms,
                soloist_speed,
                kodi_time,
                kodi_total,
                "unbekannt" if can_seek is None else str(can_seek).lower(),
            )
        )
    except Exception as error:
        _player_debug_log(
            player_state,
            "Player-Zeitprobe fehlgeschlagen ({})".format(type(error).__name__),
        )


def _playback_attempted(event, state, previous_status, previous_active):
    """Identify a new Soloist play/track request without reacting to position ticks."""
    status = state.get("status")
    if status not in ("playing", "buffering") or not state.get("is_active"):
        return False
    if event.get("type") == "track_changed":
        return True
    if (
        event.get("type") in ("playback_changed", "playback_state")
        and previous_status not in ("playing", "buffering")
    ):
        return True
    return (
        event.get("type") == "device_changed"
        and previous_active is False
    )


def _item_identity_key(item):
    if not isinstance(item, dict):
        return None
    decorations = item.get("decorations")
    if not isinstance(decorations, dict):
        return None
    identity = decorations.get("identity")
    if not isinstance(identity, dict):
        return None
    return identity.get("uri") or identity.get("name")


def _diagnostic_track_label(item):
    """Return bounded title/artist text for opt-in playback diagnostics."""
    if not isinstance(item, dict):
        return "Titel=unbekannt Interpret=unbekannt"
    decorations = item.get("decorations")
    if not isinstance(decorations, dict):
        decorations = {}
    identity = decorations.get("identity")
    if not isinstance(identity, dict):
        identity = {}
    title = identity.get("name")
    if isinstance(title, str):
        title = " ".join(title.split())[:120]
    else:
        title = ""
    artists = creator_artists(item)
    artist_names = ", ".join(artist["name"] for artist in artists[:4])
    artist_names = " ".join(artist_names.split())[:120]
    return "Titel={} Interpret={}".format(
        title or "unbekannt", artist_names or "unbekannt"
    )


def _log_audio_flow_diagnostic(audio, player_state):
    """Compare Soloist, Kodi and local PulseAudio path at a low debug rate."""
    enabled = player_state.get("debug_logging_enabled")
    if not callable(enabled) or not enabled():
        return
    playback = player_state.get("playback", {})
    if not isinstance(playback, dict) or playback.get("status") not in (
        "playing", "buffering"
    ):
        return
    now = time.monotonic()
    if now - player_state.get("last_audio_flow_diagnostic", 0.0) < AUDIO_FLOW_DIAGNOSTIC_INTERVAL:
        return
    player_state["last_audio_flow_diagnostic"] = now

    player = player_state["player"]
    kodi_playing = False
    kodi_source = "unbekannt"
    kodi_time = "unbekannt"
    try:
        kodi_playing = player.isPlaying()
        if kodi_playing:
            current_file = player.getPlayingFile()
            if current_file == player_state.get("sdp_path"):
                kodi_source = "soloist"
            elif isinstance(current_file, str) and current_file.startswith("pvr://"):
                kodi_source = "pvr"
            elif current_file:
                kodi_source = "andere"
            kodi_time = "{:.3f}".format(player.getTime())
        else:
            kodi_source = "keine"
    except Exception as error:
        kodi_source = "abfrage-fehler-{}".format(type(error).__name__)

    position = playback.get("position")
    if not isinstance(position, dict):
        position = {}
    audio_snapshot = audio.diagnostic_snapshot()
    track_label = _diagnostic_track_label(playback.get("item"))
    _player_debug_log(
        player_state,
        "Audioflussprobe: {}; Soloist={} aktiv={} Position={}ms Tempo={}; "
        "Kodi-Player={} Quelle={} Zeit={}s; {}.".format(
            track_label,
            playback.get("status"),
            str(playback.get("is_active")).lower(),
            position.get("position_ms"),
            position.get("speed"),
            "läuft" if kodi_playing else "steht",
            kodi_source,
            kodi_time,
            audio_snapshot,
        ),
    )


class SoloistKodiPlayer(xbmc.Player):
    def __init__(self, websocket, player_state):
        super().__init__()
        self.websocket = websocket
        self.player_state = player_state
        self.suppressed_callbacks = set()

    def suppress_next(self, callback_name):
        self.suppressed_callbacks.add(callback_name)

    def onAVStarted(self):
        source_known = True
        try:
            current_file = self.getPlayingFile()
        except Exception as error:
            current_file = None
            source_known = False
            _player_debug_log(
                self.player_state,
                "Kodi-AV-Quelle konnte nicht ermittelt werden ({}).".format(
                    type(error).__name__
                ),
            )
        soloist_file = self.player_state.get("sdp_path")
        if (
            self.player_state["owned"]
            and current_file
            and soloist_file
            and current_file != soloist_file
        ):
            paused = self.websocket.send_command("pause")
            self.player_state["owned"] = False
            self.player_state["pending_info_tag"] = None
            self.player_state["manual_stop"] = paused
            _player_debug_log(
                self.player_state,
                "Fremde Kodi-Quelle gestartet; Soloist-Pause vorgemerkt={}.".format(
                    str(paused).lower()
                ),
            )
            return
        _player_debug_log(
            self.player_state,
            "Kodi-AV-Quelle erkannt: {}.".format(
                "Soloist" if current_file == soloist_file else "andere oder unbekannt"
            ),
        )
        pending_info_tag = self.player_state.pop("pending_info_tag", None)
        if (
            self.player_state["owned"]
            and (current_file == soloist_file or not source_known)
            and pending_info_tag is not None
        ):
            self.updateInfoTag(pending_info_tag)
        elif pending_info_tag is not None:
            self.player_state["pending_info_tag"] = pending_info_tag

    def _user_action(self, callback_name, command, **fields):
        if callback_name in self.suppressed_callbacks:
            self.suppressed_callbacks.discard(callback_name)
            _player_debug_log(
                self.player_state,
                "Kodi-Playercallback {} wurde intern unterdrückt.".format(callback_name)
            )
            return False
        if self.player_state["owned"]:
            queued = self.websocket.send_command(command, **fields)
            _player_debug_log(
                self.player_state,
                "Kodi-Playercallback {} an Soloist vorgemerkt={}.".format(
                    callback_name, str(queued).lower()
                )
            )
            return True
        _player_debug_log(
            self.player_state,
            "Kodi-Playercallback {} ohne Add-on-Playerbesitz.".format(callback_name)
        )
        return False

    def onPlayBackPaused(self):
        self._user_action("pause", "pause")

    def onPlayBackResumed(self):
        self._user_action("resume", "play")

    def onPlayBackStopped(self):
        if "stop" in self.suppressed_callbacks:
            self.suppressed_callbacks.discard("stop")
            return
        if self._user_action("stop", "pause"):
            self.player_state["manual_stop"] = True
        self.player_state["owned"] = False

    def onPlayBackSeek(self, time, seek_offset):
        if self.player_state["owned"]:
            queued = self.websocket.send_command(
                "seek", position_ms=max(0, int(time * 1000))
            )
            _player_debug_log(
                self.player_state,
                "Kodi-Suchaktion bei {} ms an Soloist vorgemerkt={}.".format(
                    int(time * 1000), str(queued).lower()
                )
            )


def _stop_owned_player(player_state):
    if player_state["owned"]:
        player_state["owned"] = False
        player_state["pending_info_tag"] = None
        player_state["player"].suppress_next("stop")
        player_state["player"].stop()


def _stop_owned_player_and_wait(player_state, timeout=3.0):
    was_owned = player_state["owned"]
    _stop_owned_player(player_state)
    if not was_owned:
        return True
    player = player_state["player"]
    deadline = time.monotonic() + max(0.0, float(timeout))
    while time.monotonic() < deadline:
        if not player.isPlaying():
            return True
        xbmc.sleep(100)
    return not player.isPlaying()


def _shutdown_step(name, callback, api_key):
    """Run one shutdown action without skipping the remaining cleanup on failure."""
    _safe_log("Kodi-Shutdown: {} beginnt.".format(name), api_key, xbmc.LOGDEBUG)
    try:
        result = callback()
    except Exception as error:
        _safe_log(
            "Kodi-Shutdown: {} fehlgeschlagen ({}).".format(
                name, type(error).__name__
            ),
            api_key,
            xbmc.LOGERROR,
        )
        return False
    else:
        _safe_log("Kodi-Shutdown: {} abgeschlossen.".format(name), api_key, xbmc.LOGDEBUG)
        return result is not False


def _control_request(websocket, process, control, playback):
    if not process.is_running():
        return "not_running"
    if control == "toggle":
        status = playback.get("status") if isinstance(playback, dict) else None
        command = "pause" if status in ("playing", "buffering") else "play"
    else:
        command = {"previous": "skip_prev", "next": "skip_next"}.get(control)
    if command is None:
        return "invalid_command"
    return "control_queued" if websocket.send_command(command) else "command_failed"


def _start_soloist(addon, data_path, process, audio, websocket, allow_download=False):
    """Start Soloist without reporting success before the process exists."""
    api_key = load_api_key(data_path)
    device_name = addon.getSetting("device_name").strip()
    if not api_key or not device_name:
        return "configuration_missing"

    binary_path = os.path.join(data_path, "soloist", "bin", "soloist")
    if not os.path.isfile(binary_path):
        if not allow_download:
            return "binary_missing"
        try:
            binary_path, version = install_soloist(data_path)
            _safe_log("Spotify Soloist installiert: {}".format(version), api_key)
        except SoloistRuntimeError as error:
            _safe_log(
                "Soloist-Installation fehlgeschlagen: {}".format(error),
                api_key,
                xbmc.LOGERROR,
            )
            return "install_failed"
        process.binary_path = binary_path

    if process.is_running():
        return "already_running"

    audio.diagnostic_relay = addon.getSettingBool("debug_logging")
    try:
        audio.setup()
    except AudioSetupError as error:
        _safe_log(
            "PulseAudio-RTP konnte nicht eingerichtet werden: {}".format(error),
            api_key,
            xbmc.LOGERROR,
        )
        return "audio_setup_failed"

    try:
        code = process.start(
            device_name,
            api_key,
            audio_sink=audio.sink_name,
        )
    except Exception:
        audio.cleanup()
        raise
    if code != "started":
        audio.cleanup()
        if code == "start_failed":
            _safe_log("Soloist-Prozess konnte nicht gestartet werden.", api_key, xbmc.LOGERROR)
        return code

    try:
        websocket.start()
    except Exception:
        process.stop()
        audio.cleanup()
        raise
    if not process.is_running():
        websocket.stop()
        process.poll_exit()
        audio.cleanup()
        return "start_failed"
    _safe_log("Soloist-Prozess läuft; Steuerverbindung wird aufgebaut.", api_key)
    return "started"


def _handle_command(command, addon, data_path, process, window, audio, websocket, player_state):
    request_id = command.get("request_id")
    action = command.get("action")
    if action == "stop":
        code = process.stop()
        websocket.stop()
        _stop_owned_player(player_state)
        player_state["playback"] = {}
        player_state["last_status"] = None
        player_state["manual_stop"] = False
        audio.cleanup()
        player_state["connection_notice_deadline"] = None
        player_state["connection_failure_notified"] = False
        player_state["connection_was_ready"] = False
        _result(window, request_id, code)
        return
    if action == "prepare_update":
        if not request_id:
            _result(window, request_id, "invalid_command")
            return
        player_state["update_request_id"] = request_id
        _result(window, request_id, "stopping_for_update")
        _safe_log("Kodi-Updatevorbereitung angefordert; Dienst fährt kontrolliert herunter.", process.api_key)
        return
    if action == "status":
        if process.is_running():
            code = "ready" if websocket.is_connected() else "running_disconnected"
        elif not load_api_key(data_path) or not addon.getSetting("device_name").strip():
            code = "configuration_missing"
        elif not os.path.isfile(os.path.join(data_path, "soloist", "bin", "soloist")):
            code = "binary_missing"
        else:
            code = "not_running"
        _result(window, request_id, code)
        return
    if action == "control":
        code = _control_request(
            websocket,
            process,
            command.get("control"),
            player_state["playback"],
        )
        _result(window, request_id, code)
        return
    if action != "start":
        _result(window, request_id, "invalid_command")
        return
    code = _start_soloist(
        addon,
        data_path,
        process,
        audio,
        websocket,
        allow_download=bool(command.get("allow_download")),
    )
    if code in ("started", "already_running"):
        player_state["connection_notice_deadline"] = (
            time.monotonic() + CONNECTION_NOTICE_TIMEOUT
        )
        player_state["connection_failure_notified"] = False
        player_state["connection_was_ready"] = websocket.is_connected()
    _result(window, request_id, code)


def _artist_mbids_for_item(resolver, item):
    if resolver is None:
        return {}
    artist_mbids = {}
    for artist in creator_artists(item):
        mbid = resolver.lookup_or_queue(artist["uri"], artist["name"])
        if mbid:
            artist_mbids[artist["uri"]] = mbid
    return artist_mbids


def _apply_musicbrainz_result(result, resolver, audio, player_state):
    if result is None:
        return
    artist_uri, mbid = result
    if not mbid or not player_state.get("owned"):
        return
    item = player_state.get("playback", {}).get("item")
    if not any(artist["uri"] == artist_uri for artist in creator_artists(item)):
        return
    artist_mbids = _artist_mbids_for_item(resolver, item)
    list_item = kodi_music_item(
        {"item": item},
        audio.sdp_path,
        xbmcgui.ListItem,
        artist_mbids_by_uri=artist_mbids,
    )
    if list_item is None:
        return
    player = player_state["player"]
    if player.isPlaying():
        player.updateInfoTag(list_item)
        player_state["pending_info_tag"] = None
    else:
        player_state["pending_info_tag"] = list_item


def _handle_playback_event(
    event, audio, player_state, addon, musicbrainz_resolver=None, websocket=None
):
    player_state["playback"] = playback_snapshot(event, player_state["playback"])
    state = player_state["playback"]
    previous_status = player_state["last_status"]
    previous_active = player_state.get("last_active")
    position = state.get("position")
    if not isinstance(position, dict):
        position = {}
    if (
        state.get("status") != previous_status
        or state.get("is_active") != previous_active
        or event.get("type") in ("track_changed", "device_changed", "auth_state")
    ):
        _player_debug_log(
            player_state,
            "Soloist-Ereignis type={} status={} aktiv={} position_ms={} tempo={}.".format(
                event.get("type"),
                state.get("status"),
                state.get("is_active"),
                position.get("position_ms"),
                position.get("speed"),
            )
        )
    player_state["last_status"] = state.get("status")
    player_state["last_active"] = state.get("is_active")
    if state.get("status") in ("paused", "idle") or state.get("is_active") is False:
        player_state["last_blocked_track_key"] = None
        player_state["last_blocked_notification_at"] = None
    item = state.get("item") or {}
    if player_state["manual_stop"] and state.get("status") in ("playing", "buffering"):
        resumed = (
            previous_status in ("paused", "idle")
            or event.get("type") == "playback_changed"
            or (
                event.get("type") == "device_changed"
                and state.get("is_active") is True
                and previous_active is False
            )
        )
        if not resumed:
            return
        player_state["manual_stop"] = False
    if event.get("type") == "auth_state" and not event.get("logged_in"):
        _stop_owned_player(player_state)
        return

    try:
        _log_position_diagnostic(event, player_state)
    except Exception as error:
        _safe_log(
            "Player-Zeitprobe übersprungen ({})".format(type(error).__name__),
            level=xbmc.LOGDEBUG,
        )

    if (
        state.get("status") in ("playing", "buffering")
        and state.get("is_active")
        and state.get("item")
    ):
        if event.get("type") == "track_changed":
            _player_debug_log(
                player_state,
                "Soloist-Trackwechsel: {} status={} position_ms={} tempo={}.".format(
                    _diagnostic_track_label(state.get("item")),
                    state.get("status"),
                    position.get("position_ms"),
                    position.get("speed"),
                ),
            )
        metadata_event = (
            event
            if event.get("type") in ("playback_state", "track_changed")
            else state
        )
        artist_mbids = _artist_mbids_for_item(musicbrainz_resolver, state.get("item"))
        list_item = kodi_music_item(
            metadata_event,
            audio.sdp_path,
            xbmcgui.ListItem,
            artist_mbids_by_uri=artist_mbids,
        )
        if list_item is None:
            return
        if player_state["owned"]:
            player_is_playing = player_state["player"].isPlaying()
            if player_is_playing:
                player_state["player"].updateInfoTag(list_item)
                player_state["pending_info_tag"] = None
            else:
                player_state["pending_info_tag"] = list_item
            if previous_status == "paused" and not player_state["player"].isPlaying():
                player_state["player"].suppress_next("resume")
                player_state["player"].pause()
        elif not player_state["player"].isPlaying():
            player_state["player"].play(audio.sdp_path, list_item)
            player_state["owned"] = True
        else:
            _safe_log("Kodi spielt bereits; bestehende Wiedergabe bleibt unberührt")
            if _playback_attempted(
                event, state, previous_status, previous_active
            ):
                track_key = _item_identity_key(item)
                last_notification_at = player_state.get(
                    "last_blocked_notification_at"
                )
                no_key_recently_notified = (
                    track_key is None
                    and last_notification_at is not None
                    and time.monotonic() - last_notification_at < 10.0
                )
                same_track_already_notified = (
                    track_key is not None
                    and track_key == player_state.get("last_blocked_track_key")
                )
                if not no_key_recently_notified and not same_track_already_notified:
                    pause_queued = bool(
                        websocket is not None and websocket.send_command("pause")
                    )
                    player_state["last_blocked_track_key"] = track_key
                    player_state["last_blocked_notification_at"] = time.monotonic()
                    notification_shown = _notify(
                        addon,
                        32054,
                        xbmcgui.NOTIFICATION_WARNING,
                        display_time=8000,
                        sound=False,
                    )
                    _player_debug_log(
                        player_state,
                        "Soloist-Start bei belegtem Kodi-Player nicht übernommen; "
                        "Pause an Soloist vorgemerkt={}, Meldung {}.".format(
                            str(pause_queued).lower(),
                            "angezeigt" if notification_shown else "deaktiviert",
                        ),
                    )
    elif state.get("status") == "paused" and player_state["owned"]:
        if previous_status != "paused" and player_state["player"].isPlaying():
            player_state["player"].suppress_next("pause")
            player_state["player"].pause()
    elif (
        (state.get("status") == "idle" or state.get("is_active") is False)
        and player_state["owned"]
    ):
        _stop_owned_player(player_state)


def run_service():
    """Prepare private runtime paths, handle Kodi menu requests, and stop cleanly."""
    addon = xbmcaddon.Addon()
    monitor = xbmc.Monitor()

    data_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    if not xbmcvfs.exists(data_path) and not xbmcvfs.mkdirs(data_path):
        _safe_log("Add-on-Profilverzeichnis konnte nicht angelegt werden", level=xbmc.LOGERROR)
        return

    soloist_root = os.path.join(data_path, "soloist")
    process = SoloistProcess(
        os.path.join(soloist_root, "bin", "soloist"),
        os.path.join(soloist_root, "data"),
        os.path.join(soloist_root, "cache"),
        lambda message: _safe_log(message, process.api_key),
    )
    websocket = SoloistWebSocket(
        os.path.join(soloist_root, "data"),
        lambda message: _safe_log(message, process.api_key),
    )
    musicbrainz_resolver = MusicBrainzResolver(
        os.path.join(data_path, "musicbrainz_artist_cache.json"),
        "Kodi-Soloist-Native/0.3.20 (https://github.com/blauesgruen/service.soloist)",
        lambda message: _safe_log(message, level=xbmc.LOGDEBUG),
    )
    audio = PulseRtpAudio(data_path, lambda message: _safe_log(message, process.api_key))
    window = xbmcgui.Window(WINDOW_ID)
    window.clearProperty(UPDATE_READY_PROPERTY)
    player_state = {
        "player": None,
        "owned": False,
        "sdp_path": audio.sdp_path,
        "manual_stop": False,
        "playback": {},
        "last_status": None,
        "last_active": None,
        "pending_info_tag": None,
        "last_position_diagnostic": 0.0,
        "last_audio_flow_diagnostic": 0.0,
        "last_blocked_track_key": None,
        "last_blocked_notification_at": None,
        "connection_notice_deadline": None,
        "connection_failure_notified": False,
        "connection_was_ready": False,
        "update_request_id": None,
    }
    player_state["player"] = SoloistKodiPlayer(websocket, player_state)
    player_state["debug_logging_enabled"] = lambda: addon.getSettingBool(
        "debug_logging"
    )
    player_state["debug_log"] = lambda message: _debug_log(
        addon, message, process.api_key
    )
    _safe_log("Kodi-Service gestartet; Soloist-Autostart wartet kurz.")

    try:
        startup_deadline = time.monotonic() + STARTUP_DELAY_SECONDS
        while time.monotonic() < startup_deadline:
            if monitor.waitForAbort(min(0.25, startup_deadline - time.monotonic())):
                return
        try:
            startup_result = _start_soloist(addon, data_path, process, audio, websocket)
        except Exception as error:
            startup_result = "start_failed"
            _safe_log(
                "Automatischer Soloist-Start fehlgeschlagen ({})".format(
                    type(error).__name__
                ),
                load_api_key(data_path),
                xbmc.LOGERROR,
            )
        if startup_result in ("started", "already_running"):
            player_state["connection_notice_deadline"] = (
                time.monotonic() + CONNECTION_NOTICE_TIMEOUT
            )
            _safe_log("Automatischer Soloist-Start: {}".format(startup_result))
        else:
            player_state["connection_notice_deadline"] = None
            player_state["connection_failure_notified"] = False
            _notify(addon, {
                "configuration_missing": 32042,
                "binary_missing": 32043,
                "audio_setup_failed": 32035,
                "install_failed": 32023,
                "start_failed": 32024,
            }.get(startup_result, 32024), xbmcgui.NOTIFICATION_ERROR)
            _safe_log("Automatischer Soloist-Start nicht möglich: {}".format(startup_result))
        while not monitor.waitForAbort(0.25):
            exit_code = process.poll_exit()
            if exit_code is not None:
                websocket.stop()
                _stop_owned_player(player_state)
                player_state["playback"] = {}
                player_state["last_status"] = None
                audio.cleanup()
                player_state["connection_notice_deadline"] = None
                _notify(addon, 32044, xbmcgui.NOTIFICATION_ERROR)
            connected = process.is_running() and websocket.is_connected()
            was_connected = player_state.get("connection_was_ready", False)
            if connected and not was_connected:
                _player_debug_log(
                    player_state, "Soloist-WebSocket-Steuerverbindung hergestellt."
                )
                _notify(addon, 32045)
                player_state["connection_failure_notified"] = False
                player_state["connection_notice_deadline"] = None
            elif was_connected and not connected and process.is_running():
                _player_debug_log(
                    player_state, "Soloist-WebSocket-Steuerverbindung getrennt."
                )
                _notify(addon, 32046, xbmcgui.NOTIFICATION_ERROR)
            player_state["connection_was_ready"] = connected
            deadline = player_state.get("connection_notice_deadline")
            if (
                process.is_running()
                and not connected
                and deadline is not None
                and time.monotonic() >= deadline
                and not player_state.get("connection_failure_notified")
            ):
                _notify(addon, 32047, xbmcgui.NOTIFICATION_ERROR)
                player_state["connection_failure_notified"] = True
            raw_command = window.getProperty(COMMAND_PROPERTY)
            if raw_command:
                window.clearProperty(COMMAND_PROPERTY)
                request_id = None
                api_key = None
                try:
                    command = json.loads(raw_command)
                    if not isinstance(command, dict):
                        raise ValueError("command must be an object")
                    request_id = command.get("request_id")
                    _handle_command(
                        command,
                        addon,
                        data_path,
                        process,
                        window,
                        audio,
                        websocket,
                        player_state,
                    )
                    if player_state.get("update_request_id"):
                        break
                except Exception as error:
                    api_key = load_api_key(data_path)
                    _safe_log(
                        "Kodi-Befehl fehlgeschlagen ({})".format(type(error).__name__),
                        api_key,
                        xbmc.LOGERROR,
                    )
                    _result(window, request_id, "command_failed")
            while True:
                event = websocket.get_event()
                if event is None:
                    break
                try:
                    _handle_playback_event(
                        event,
                        audio,
                        player_state,
                        addon,
                        musicbrainz_resolver,
                        websocket,
                    )
                except Exception as error:
                    _safe_log(
                        "Soloist-Ereignis ignoriert ({})".format(type(error).__name__),
                        level=xbmc.LOGERROR,
                    )
            while True:
                result = musicbrainz_resolver.get_result()
                if result is None:
                    break
                try:
                    _apply_musicbrainz_result(
                        result,
                        musicbrainz_resolver,
                        audio,
                        player_state,
                    )
                except Exception as error:
                    _safe_log(
                        "MusicBrainz-Ergebnis ignoriert ({})".format(
                            type(error).__name__
                        ),
                        level=xbmc.LOGERROR,
                    )
            try:
                _log_audio_flow_diagnostic(audio, player_state)
            except Exception as error:
                _player_debug_log(
                    player_state,
                    "Audioflussprobe übersprungen ({}).".format(
                        type(error).__name__
                    ),
                )
    finally:
        shutdown_api_key = process.api_key
        update_request_id = player_state.get("update_request_id")
        _safe_log("Kodi-Shutdown: Wiedergabe wird vor der Bereinigung gestoppt.", shutdown_api_key)
        player_stopped = _shutdown_step(
            "Kodi-Player stoppen",
            lambda: (
                _stop_owned_player_and_wait(player_state)
                if update_request_id
                else _stop_owned_player(player_state)
            ),
            shutdown_api_key,
        )
        soloist_stopped = _shutdown_step(
            "Soloist-Prozess beenden",
            lambda: process.stop(timeout=5.0 if update_request_id else 0.5),
            shutdown_api_key,
        )
        audio_cleaned = _shutdown_step("Audio-Ressourcen bereinigen", audio.cleanup, shutdown_api_key)
        websocket_stopped = _shutdown_step(
            "WebSocket beenden",
            lambda: websocket.stop(timeout=3.0 if update_request_id else 0.25),
            shutdown_api_key,
        )
        resolver_closed = _shutdown_step(
            "MusicBrainz-Resolver schließen",
            musicbrainz_resolver.close,
            shutdown_api_key,
        )
        if update_request_id:
            if all((player_stopped, soloist_stopped, audio_cleaned, websocket_stopped, resolver_closed)):
                window.setProperty(UPDATE_READY_PROPERTY, update_request_id)
                _safe_log("Kodi-Updatevorbereitung abgeschlossen; Wiedergabe beendet.", shutdown_api_key)
            else:
                _safe_log(
                    "Kodi-Updatevorbereitung fehlgeschlagen; Update nicht starten.",
                    shutdown_api_key,
                    xbmc.LOGERROR,
                )
        _safe_log("Kodi-Shutdown erkannt")


if __name__ == "__main__":
    run_service()
