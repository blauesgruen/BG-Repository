"""Resolve Soloist Spotify artists to MusicBrainz IDs without blocking Kodi."""

import json
import os
import queue
import re
import threading
import time
import unicodedata
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


MUSICBRAINZ_BASE_URL = "https://musicbrainz.org/ws/2"
REQUEST_TIMEOUT_SECONDS = 4
MIN_REQUEST_INTERVAL_SECONDS = 1.0
MAX_RESPONSE_BYTES = 512 * 1024
MAX_CACHE_ENTRIES = 1000
POSITIVE_CACHE_SECONDS = 365 * 24 * 60 * 60
NEGATIVE_CACHE_SECONDS = 7 * 24 * 60 * 60
AMBIGUOUS_CACHE_SECONDS = 30 * 24 * 60 * 60
ERROR_CACHE_SECONDS = 15 * 60
SPOTIFY_ARTIST_ID_RE = re.compile(r"^[A-Za-z0-9]{22}$")
MBID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)


class MusicBrainzResolver:
    """Resolve one Spotify artist per worker task and persist safe results."""

    def __init__(self, cache_path, user_agent, logger):
        self.cache_path = cache_path
        self.user_agent = user_agent
        self.logger = logger
        self._lock = threading.Lock()
        self._cache = self._load_cache()
        self._requests = queue.Queue(maxsize=64)
        self._results = queue.Queue(maxsize=64)
        self._pending = set()
        self._stop_event = threading.Event()
        self._thread = None
        self._last_request_at = 0.0

    def lookup_or_queue(self, artist_uri, artist_name):
        """Return a cached ID, or queue a non-blocking lookup for this artist."""
        spotify_id = _spotify_artist_id(artist_uri)
        name = _clean_artist_name(artist_name)
        if not spotify_id or not name:
            return None

        now = time.time()
        with self._lock:
            entry = self._cache.get(spotify_id)
            if entry and entry.get("expires_at", 0) > now:
                if _normalize_name(entry.get("name", "")) == _normalize_name(name):
                    return entry.get("mbid") or None
                self._cache.pop(spotify_id, None)

            if spotify_id not in self._pending:
                try:
                    self._requests.put_nowait((spotify_id, name))
                except queue.Full:
                    return None
                self._pending.add(spotify_id)
                if self._thread is None or not self._thread.is_alive():
                    self._thread = threading.Thread(
                        target=self._run,
                        name="soloist-musicbrainz",
                        daemon=True,
                    )
                    self._thread.start()
        return None

    def get_result(self):
        """Return one completed lookup as (spotify_artist_uri, mbid)."""
        try:
            spotify_id, mbid = self._results.get_nowait()
        except queue.Empty:
            return None
        return "spotify:artist:" + spotify_id, mbid or None

    def close(self):
        self._stop_event.set()
        try:
            self._requests.put_nowait(None)
        except queue.Full:
            pass
        if self._thread is not None:
            self._thread.join(timeout=0.1)

    def _run(self):
        while not self._stop_event.is_set():
            try:
                task = self._requests.get(timeout=0.25)
            except queue.Empty:
                continue
            if task is None:
                return
            spotify_id, name = task
            try:
                status, mbid = self._resolve(spotify_id, name)
            except Exception as error:
                if self._stop_event.is_set():
                    with self._lock:
                        self._pending.discard(spotify_id)
                    return
                status, mbid = "error", ""
                detail = (
                    "HTTP {}".format(error.code)
                    if isinstance(error, HTTPError)
                    else type(error).__name__
                )
                self.logger(
                    "MusicBrainz-Abfrage fehlgeschlagen ({})".format(detail)
                )

            ttl = {
                "found": POSITIVE_CACHE_SECONDS,
                "not_found": NEGATIVE_CACHE_SECONDS,
                "ambiguous": AMBIGUOUS_CACHE_SECONDS,
                "error": ERROR_CACHE_SECONDS,
            }.get(status, ERROR_CACHE_SECONDS)
            with self._lock:
                self._pending.discard(spotify_id)
                self._cache[spotify_id] = {
                    "name": name,
                    "mbid": mbid,
                    "status": status,
                    "expires_at": int(time.time() + ttl),
                }
                self._trim_cache()
                self._save_cache()
            if status == "found":
                self.logger("MusicBrainz-Künstler-ID wurde sicher zugeordnet")
            elif status == "ambiguous":
                self.logger(
                    "MusicBrainz-Künstlerzuordnung ist mehrdeutig; ID bleibt leer"
                )
            elif status == "not_found":
                self.logger("MusicBrainz lieferte keine passende Künstler-ID")
            try:
                self._results.put_nowait((spotify_id, mbid))
            except queue.Full:
                pass

    def _resolve(self, spotify_id, name):
        spotify_url = "https://open.spotify.com/artist/{}".format(spotify_id)
        url_status, url_mbid = self._lookup_spotify_url(spotify_url, name)
        if url_status == "found":
            return "found", url_mbid
        if url_status == "ambiguous":
            return "ambiguous", ""

        name_status, name_mbid = self._lookup_artist_name(name)
        return name_status, name_mbid

    def _lookup_spotify_url(self, spotify_url, expected_name):
        params = urlencode(
            {
                "resource": spotify_url,
                "inc": "artist-rels",
                "fmt": "json",
            }
        )
        data = self._get_json(
            "{}/url?{}".format(MUSICBRAINZ_BASE_URL, params),
            missing_ok=True,
        )
        if data is None:
            return "not_found", ""
        url_entity = data.get("url")
        if isinstance(url_entity, dict):
            relations = url_entity.get("relations")
        else:
            relations = data.get("relations")
        if not isinstance(relations, list):
            return "not_found", ""
        candidates = set()
        expected = _normalize_name(expected_name)
        for relation in relations:
            if (
                not isinstance(relation, dict)
                or relation.get("target-type") != "artist"
            ):
                continue
            artist = relation.get("artist")
            if not isinstance(artist, dict):
                continue
            candidate_name = artist.get("name")
            candidate_id = artist.get("id")
            if (
                _normalize_name(candidate_name) == expected
                and isinstance(candidate_id, str)
                and MBID_RE.fullmatch(candidate_id)
            ):
                candidates.add(candidate_id.lower())
        if len(candidates) == 1:
            return "found", candidates.pop()
        if len(candidates) > 1:
            return "ambiguous", ""
        return "not_found", ""

    def _lookup_artist_name(self, name):
        params = urlencode({"query": name, "fmt": "json", "limit": 100})
        data = self._get_json(
            "{}/artist/?{}".format(MUSICBRAINZ_BASE_URL, params)
        )
        artists = data.get("artists")
        if not isinstance(artists, list):
            return "not_found", ""
        expected = _normalize_name(name)
        candidates = set()
        for artist in artists:
            if not isinstance(artist, dict):
                continue
            candidate_name = artist.get("name")
            candidate_id = artist.get("id")
            if (
                _normalize_name(candidate_name) == expected
                and isinstance(candidate_id, str)
                and MBID_RE.fullmatch(candidate_id)
            ):
                candidates.add(candidate_id.lower())
        if len(artists) >= 100 and len(candidates) == 1:
            return "ambiguous", ""
        if len(candidates) == 1:
            return "found", candidates.pop()
        if len(candidates) > 1:
            return "ambiguous", ""
        return "not_found", ""

    def _get_json(self, url, missing_ok=False):
        self._wait_for_request_slot()
        request = Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": self.user_agent,
            },
        )
        try:
            with urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
                body = response.read(MAX_RESPONSE_BYTES + 1)
        except HTTPError as error:
            if missing_ok and error.code == 404:
                return None
            raise
        if len(body) > MAX_RESPONSE_BYTES:
            raise ValueError("MusicBrainz-Antwort überschreitet die Größenbegrenzung")
        data = json.loads(body.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("MusicBrainz-Antwort hat ein ungültiges Format")
        return data

    def _wait_for_request_slot(self):
        if self._stop_event.is_set():
            raise InterruptedError("MusicBrainz-Abfrage wurde beendet")
        delay = MIN_REQUEST_INTERVAL_SECONDS - (
            time.monotonic() - self._last_request_at
        )
        if delay > 0 and self._stop_event.wait(delay):
            raise InterruptedError("MusicBrainz-Abfrage wurde beendet")
        self._last_request_at = time.monotonic()

    def _load_cache(self):
        try:
            if os.path.getsize(self.cache_path) > 1024 * 1024:
                return {}
            with open(self.cache_path, "r", encoding="utf-8") as cache_file:
                data = json.load(cache_file)
        except (OSError, UnicodeError, ValueError):
            return {}
        if not isinstance(data, dict):
            return {}
        entries = data.get("entries")
        if data.get("version") != 1 or not isinstance(entries, dict):
            return {}
        result = {}
        now = time.time()
        for spotify_id, entry in list(entries.items())[:MAX_CACHE_ENTRIES]:
            if (
                not isinstance(spotify_id, str)
                or not SPOTIFY_ARTIST_ID_RE.fullmatch(spotify_id)
                or not isinstance(entry, dict)
            ):
                continue
            mbid = entry.get("mbid", "")
            if not isinstance(mbid, str) or (mbid and not MBID_RE.fullmatch(mbid)):
                continue
            if not isinstance(entry.get("name"), str):
                continue
            try:
                expires_at = int(entry.get("expires_at", 0))
            except (TypeError, ValueError):
                continue
            if expires_at > now:
                result[spotify_id] = {
                    "name": entry["name"],
                    "mbid": mbid.lower(),
                    "status": entry.get("status", "not_found"),
                    "expires_at": expires_at,
                }
        return result

    def _trim_cache(self):
        if len(self._cache) <= MAX_CACHE_ENTRIES:
            return
        oldest = sorted(
            self._cache,
            key=lambda spotify_id: self._cache[spotify_id].get("expires_at", 0),
        )
        for spotify_id in oldest[: len(self._cache) - MAX_CACHE_ENTRIES]:
            del self._cache[spotify_id]

    def _save_cache(self):
        temporary_path = self.cache_path + ".tmp"
        try:
            os.makedirs(os.path.dirname(self.cache_path), exist_ok=True)
            with open(temporary_path, "w", encoding="utf-8") as cache_file:
                json.dump(
                    {"version": 1, "entries": self._cache},
                    cache_file,
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
                cache_file.flush()
                os.fsync(cache_file.fileno())
            os.replace(temporary_path, self.cache_path)
        except OSError as error:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass
            self.logger(
                "MusicBrainz-Cache konnte nicht gespeichert werden ({})".format(
                    type(error).__name__
                )
            )


def _spotify_artist_id(value):
    if not isinstance(value, str):
        return ""
    parts = value.split(":")
    if len(parts) != 3 or parts[0] != "spotify" or parts[1] != "artist":
        return ""
    return parts[2] if SPOTIFY_ARTIST_ID_RE.fullmatch(parts[2]) else ""


def _clean_artist_name(value):
    if not isinstance(value, str):
        return ""
    return " ".join(value.split())[:256]


def _normalize_name(value):
    if not isinstance(value, str):
        return ""
    normalized = unicodedata.normalize("NFKC", value)
    return " ".join(normalized.casefold().split())
