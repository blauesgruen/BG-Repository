"""Own a standalone Python audio bridge; Kodi retains PulseAudio ownership."""

import json
import os
from pathlib import Path
import select
import subprocess
import threading
import time
from urllib.parse import urlsplit

from audio import AudioSetupError, PAREC_SAMPLE_BYTES, PulseRtpAudio


MAX_RECORD = 65536
COMMAND_TIMEOUT = 2.0


def _system_python():
    # sys.executable belongs to the embedding application and may be kodi.bin.
    for candidate in ("/usr/bin/python3", "/usr/bin/python3.14", "/usr/bin/python"):
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    raise AudioSetupError("Eigenständiger CoreELEC-Python-Interpreter fehlt")


class AudioBridgeProcess:
    """Bounded control IPC only; all audio bytes stay inside the worker."""

    def __init__(self, port, logger, parec_source=None):
        self.logger = logger
        self.port = port
        self.url = None
        self.error = None
        self._ready = threading.Event()
        self._lock = threading.Lock()
        self._request_lock = threading.Lock()
        self._pending = {}
        self._sequence = 0
        self._snapshot = None
        self._closing = False
        executable = _system_python()
        self.interpreter = executable
        try:
            self.process = subprocess.Popen(
                [executable, "-I", "-B", "-u", str(Path(__file__).with_name("audio_worker.py"))]
                + (["--parec-source", parec_source] if parec_source
                   else ["--rtp-port", str(port)]),
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                start_new_session=True,
            )
        except OSError as error:
            raise AudioSetupError("Eigenständiger Audioprozess konnte nicht starten") from error
        try:
            # Small writes <= PIPE_BUF are atomic: never leave a partial JSON line.
            os.set_blocking(self.process.stdin.fileno(), False)
            self._reader = threading.Thread(target=self._read_records, name="soloist-audio-ipc", daemon=True)
            self._logs = threading.Thread(target=self._read_logs, name="soloist-audio-logs", daemon=True)
            self._reader.start()
            self._logs.start()
        except (OSError, RuntimeError) as error:
            self._closing = True
            self._terminate()
            for pipe in (self.process.stdin, self.process.stdout, self.process.stderr):
                pipe.close()
            raise AudioSetupError("Audioprozess-Steuerkanal konnte nicht starten") from error
        if not self._ready.wait(5.0) or self.url is None or self.error:
            reason = self.error or "StartTimeout"
            self.close()
            raise AudioSetupError("Audioprozess nicht bereit ({})".format(reason))

    def _read_records(self):
        try:
            while True:
                line = self.process.stdout.readline(MAX_RECORD + 1)
                if not line:
                    break
                if len(line) > MAX_RECORD or not line.endswith(b"\n"):
                    raise ValueError("oversize worker record")
                record = json.loads(line)
                if not isinstance(record, dict):
                    raise ValueError("invalid worker record")
                kind = record.get("type")
                if kind == "ready":
                    url = record.get("url")
                    parsed = urlsplit(url) if isinstance(url, str) else None
                    if (record.get("protocol") != 1 or record.get("pid") != self.process.pid
                            or record.get("rtp_port") != self.port or parsed is None
                            or parsed.scheme != "tcp" or parsed.hostname != "127.0.0.1"
                            or parsed.username or parsed.password or not parsed.port
                            or parsed.path or parsed.fragment or parsed.query != "timeout=5000000"):
                        raise ValueError("invalid worker readiness")
                    self.url = url
                    self._ready.set()
                elif kind == "snapshot":
                    if (not isinstance(record.get("stats"), dict)
                            or not isinstance(record.get("recovery"), dict)
                            or not isinstance(record.get("buffer"), str)
                            or not isinstance(record.get("at"), (int, float))):
                        raise ValueError("invalid worker snapshot")
                    with self._lock:
                        self._snapshot = record
                elif kind == "reply":
                    with self._lock:
                        pending = self._pending.get(record.get("id"))
                        if pending is not None:
                            pending["reply"] = record
                            pending["event"].set()
                elif kind == "fatal":
                    name = record.get("error", "WorkerFailure")
                    self.error = (name if isinstance(name, str) and name.isascii()
                                  and name.isalpha() and len(name) < 80 else "WorkerFailure")
                    break
                else:
                    raise ValueError("unknown worker record")
        except (OSError, ValueError, RuntimeError) as error:
            self.error = type(error).__name__
        finally:
            if not self._closing:
                self.error = self.error or "WorkerEOF"
            self._ready.set()
            with self._lock:
                for pending in self._pending.values():
                    pending["event"].set()

    def _read_logs(self):
        while True:
            try:
                line = self.process.stderr.readline(4097)
            except OSError:
                return
            if not line:
                return
            self.logger("[Audioprozess] " + line.decode("utf-8", "replace").strip()[:2048])

    def snapshot(self):
        with self._lock:
            snapshot = self._snapshot
        if (snapshot is None or self.error or self.process.poll() is not None
                or time.monotonic() - snapshot["at"] > 2.0):
            raise AudioSetupError("Audioprozess-Telemetrie ist nicht aktuell")
        return snapshot

    def check_health(self):
        if self.error or self.process.poll() is not None:
            raise AudioSetupError("Eigenständiger Audioprozess ist ausgefallen")

    def request(self, operation, **fields):
        with self._request_lock:
            self.check_health()
            self._sequence += 1
            request_id = self._sequence
            data = (json.dumps({"id": request_id, "op": operation, **fields},
                               separators=(",", ":")) + "\n").encode("utf-8")
            if len(data) > 4096:
                raise AudioSetupError("Audioprozess-Steuerbefehl ist zu groß")
            pending = {"event": threading.Event(), "reply": None}
            with self._lock:
                self._pending[request_id] = pending
            try:
                deadline = time.monotonic() + (3.0 if operation == "shutdown" else COMMAND_TIMEOUT)
                while True:
                    try:
                        written = os.write(self.process.stdin.fileno(), data)
                        if written != len(data):
                            raise OSError("incomplete control write")
                        break
                    except BlockingIOError:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise TimeoutError("worker control blocked")
                        select.select([], [self.process.stdin], [], min(remaining, 0.1))
                if not pending["event"].wait(max(0.0, deadline - time.monotonic())):
                    raise TimeoutError("worker acknowledgement missing")
                reply = pending["reply"]
                if reply is None or reply.get("ok") is not True:
                    raise OSError("worker command rejected")
                return reply.get("result")
            except (OSError, ValueError) as error:
                self.error = type(error).__name__
                # Fail closed: a missed pause acknowledgement must never keep
                # an unknown old audio connection playing behind Kodi's stop.
                self._terminate()
                raise AudioSetupError("Audioprozess bestätigt Steuerbefehl nicht") from error
            finally:
                with self._lock:
                    self._pending.pop(request_id, None)

    def _terminate(self):
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=1.0)

    def close(self):
        self._closing = True
        try:
            if self.process.poll() is None and self.url is not None and not self.error:
                self.request("shutdown")
                self.process.wait(timeout=2.0)
        except (AudioSetupError, subprocess.TimeoutExpired):
            pass
        finally:
            self._terminate()
            for pipe in (self.process.stdin, self.process.stdout, self.process.stderr):
                pipe.close()
            for thread in (self._reader, self._logs):
                thread.join(timeout=1.0)


class ProcessPulseRtpAudio(PulseRtpAudio):
    """Parent owns PulseAudio; its child exclusively owns UDP and TCP audio."""

    def __init__(self, data_dir, logger, runner=None):
        super().__init__(data_dir, logger, runner)
        self._bridge = None
        self._initial_stats = dict(self._rtp_stats)

    def _start_transport(self):
        if self._bridge is not None:
            self._bridge.close()
            self._bridge = None
        with self._rtp_lock:
            self._rtp_stats = dict(self._initial_stats)
            self._rtp_reported = dict(self._initial_stats)
        if self.transport == "parec":
            self.sample_bytes = PAREC_SAMPLE_BYTES
            self.parec_source = "{}.monitor".format(self.sink_name)
            self._bridge = AudioBridgeProcess(None, self.logger, self.parec_source)
        else:
            self._bridge = AudioBridgeProcess(self.port, self.logger)
        self.playback_url = self._bridge.url
        self.logger("Isolierter Python-Audioprozess bereit: PID={} Interpreter={}; "
                    "kein Kodi-Import, kein Audio über Steuer-IPC.".format(
                        self._bridge.process.pid, self._bridge.interpreter))

    def _stop_transport(self):
        if self._bridge is not None:
            self._bridge.close()
            self._bridge = None

    def check_health(self):
        if self._bridge is not None:
            self._bridge.check_health()

    def _update_stats(self):
        if self._bridge is None:
            raise AudioSetupError("Audioprozess wurde noch nicht eingerichtet")
        snapshot = self._bridge.snapshot()
        with self._rtp_lock:
            self._rtp_stats.update(snapshot["stats"])
        return snapshot

    def buffer_snapshot(self):
        try:
            snapshot = self._update_stats()
        except AudioSetupError:
            return "Audioprozess-Pufferstatus=unbekannt"
        return "{} WorkerPID={} Snapshot_vor={}ms".format(
            snapshot["buffer"], self._bridge.process.pid,
            int(max(0.0, time.monotonic() - snapshot["at"]) * 1000),
        )

    def recovery_snapshot(self):
        self._update_stats()
        return super().recovery_snapshot()

    def _collect_diagnostic_snapshot(self):
        self._update_stats()
        return super()._collect_diagnostic_snapshot()

    def set_playback_enabled(self, enabled):
        if self._bridge is None:
            raise AudioSetupError("Audioprozess ist nicht bereit")
        result = self._bridge.request("playback", enabled=bool(enabled))
        if result != {"enabled": bool(enabled)}:
            raise AudioSetupError("Audioprozess hat Wiedergabestatus nicht bestätigt")

    def close_tcp_clients(self, reason="Kodi-Player wird beendet"):
        if self._bridge is None:
            return 0
        if self._bridge.error or self._bridge.process.poll() is not None:
            self._bridge._terminate()
            return 0
        result = self._bridge.request("close", reason=reason[:256])
        if not isinstance(result, dict) or not isinstance(result.get("closed"), int):
            raise AudioSetupError("Audioprozess hat Verbindungsende nicht bestätigt")
        return result["closed"]
